# RPG Studio

Editor desktop + engine HTML5 untuk membuat game RPG klasik bergaya turn-based, dengan fitur dan alur kerja yang mirip RPG Maker MV.
Semua grafik (tile, karakter, monster, ikon, animasi) dan audio (SE + BGM) dihasilkan oleh kode, jadi **tidak ada materi berhak cipta**. Hanya untuk penggunaan non-komersial.

## Menjalankan
```
npm install
npm start
```
Butuh Node.js 18+. Editor juga bisa dibuka di browser: buka `editor/index.html` (proyek disimpan di localStorage browser).

## Fitur
- **Editor peta**: 4 layer, palet tile A–E (multi-select), pensil/persegi/elips/isi/penghapus, undo/redo, zoom, grid, tampilan passability, ubah ukuran peta, pohon peta bertingkat.
- **Editor event**: banyak halaman, kondisi (switch, variable, self switch, item, aktor), gerak otonom + route, ~55 perintah (pesan, pilihan, percabangan, loop, variabel, item, party, transfer, gambar, cuaca, tint, battle, shop, nama, dll), common events, quick event (pintu, peti, NPC).
- **Database**: Actors, Classes, Skills, Items, Weapons, Armors, Enemies, Troops, States, Common Events, System (switch, variabel, party awal, musik), Terms, serta Change Maximum.
- **Generator karakter** + impor PNG (sprite sheet 3×4, gambar, audio) lewat Resource Manager.
- **Engine**: menu (item, skill, equip, status, save/load 10 slot), toko, battle side-view turn-based (elemen, state, kritikal, AI musuh), encounter acak, pesan/pilihan/angka, efek layar.
- **Playtest** (F12), **Deploy** ke build HTML5 atau paket desktop.
- Game demo "Legend of Greenvale" sudah termasuk (File → Load Demo Game).

## Fitur baru
- **Combat aksi real-time**: musuh terlihat di peta dan mengejar pemain. Serang dengan tombol Attack (C / J, atau tombol ATK di HP); gaya serangan mengikuti tipe senjata (pedang busur tombak kapak tongkat). Skill cepat: V, ganti skill dengan Q/E. Tempatkan musuh di Event mode: klik kanan → *Enemy (action combat)…*. Bisa jadi bos (bar HP, musik bos, switch/common event saat mati).
- **Mode combat** di Database → System (Action atau Turn-based). Mode turn-based lama tetap ada.
- **Tileset sendiri**: Tools → Tileset Manager (impor PNG, atur layer/passable per tile). Tile muncul di tab F palet.
- **Title screen kustom**: Database → System → Title Screen (gambar latar, gradien, logo, warna, posisi menu).
- **Scenes**: Database → Scenes (cutscene sinematik dengan bar hitam). Mainkan lewat perintah *Play Scene* atau jadikan intro di System → Intro scene.
- **Playtest** selalu mulai dari title screen (Ctrl+F12 = mulai dari sel terpilih).
- **Kontrol sentuh** otomatis di HP: joystick, OK, X, RUN, ATK, SKL.

## Kontrol game
Panah/WASD gerak · Z/Enter OK · X/Esc batal/menu · Shift lari · C/J serang · V skill · Q/E ganti skill · F11 layar penuh.

## Pintasan editor
Ctrl+S simpan · Ctrl+O buka · F5 mode peta · F6 mode event · F9 database · F10 resource manager · F12 playtest · Ctrl+Z/Y undo/redo.

## Struktur
- `main.js`, `preload.js` — Electron
- `editor/` — UI editor (`js/ui, palette, mapview, charedit, eventedit, dbedit, misc, app`)
- `runtime/` — engine game + aset prosedural + demo
- Proyek = folder berisi `project.json`, `img/`, `audio/`

## Membuat file .exe (Windows)
- **Di PC Windows:** klik dua kali `build-exe.bat` → hasil `dist/RPG Studio ... .exe` (portable, tanpa instalasi).
- **Tanpa PC (lewat GitHub):** upload folder ini ke repo GitHub, buka tab *Actions* → *Build Windows EXE* → *Run workflow*. Unduh `.exe` dari bagian *Artifacts*.

## Gerak bebas, pintu, dinding bergerak, boss (update terbaru)
- **Gerak bebas (pixel)**: aktif lewat Database → System → `freeMove`. Karakter boleh berada di antara dua petak; tabrakan memakai hitbox kaki, ada geser halus di sudut.
- **Pintu** (event → "Make this a door"): dibuka dengan OK menghadap pintu, ada animasi (kayu/besi/gerbang/batu), TIDAK memindahkan map. Opsi **Locked** + key item (habis/tidak), atau terbuka lewat switch, menutup sendiri, bisa ditutup lagi. Status tersimpan di save.
- **Dinding/blok bergerak** (event → "Make this a movable wall / block"): mode `ok` (tekan OK), `switch` (ikut switch), `push` (didorong pemain). Arah, jarak, kecepatan, toggle, sekali pakai. Posisi tersimpan.
- **Boss**: tombol "Boss moves & phases…" di panel enemy. Tiap phase punya ambang HP dan skill (slam, charge, fan/shoot, ring, meteor, summon, blink). Ada preset Dark Knight & Dragon.
- **Impor resource tanpa aplikasi desktop**: Tools → Resource Manager (Characters, Pictures, Battlers, Audio) dan tombol *Import PNG…* di pemilih karakter kini jalan di browser juga. File disimpan di dalam `project.json` (`db.assets`), maks 8 MB per file. Gambar musuh kustom: Database → Enemies → Custom image.
