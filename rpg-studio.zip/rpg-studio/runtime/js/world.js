/* Dunia interaktif: gerak bebas (per-piksel), pintu (kunci + animasi), dinding yang bisa bergerak. */
(function(){
'use strict';
const R = window.RPG, T = R.TILE, DX = R.DX, DY = R.DY;
const F = R.Free = {}, D = R.Door = {}, M = R.Mover = {};
const key = (m,e,k) => m+','+e+','+k;

/* ================= GERAK BEBAS ================= */
F.on = () => !!(R.$db&&R.$db.system.freeMove);
F.blocker = function(map,x,y,self){
  for(const e of map.events){ if(e===self||!e.page||e.erased||e.through||e.prio!==1||e.transparent) continue; if(e.x!==x||e.y!==y) continue;
    if(e.img.kind==='none'&&!e.tileId&&!e.mob&&!e.door) continue; return e; }
  return null;
};
F.free = function(sc,p,rx,ry,out){
  const m=sc.map, l=rx+.2, r=rx+.8, t=ry+.55, b=ry+.95;
  const x0=Math.floor(l), x1=Math.floor(r-1e-6), y0=Math.floor(t), y1=Math.floor(b-1e-6);
  for(let y=y0;y<=y1;y++) for(let x=x0;x<=x1;x++){
    if(!m.valid(x,y)) return false; if(p.through) continue;
    if(!m.passable(x,y)) return false;
    const e=F.blocker(m,x,y,null); if(e){ if(out) out.ev=e; return false; }
  }
  return true;
};
F.step = function(sc,p,dx,dy){
  const out={ev:null}; let moved=false; const ox=p.x, oy=p.y;
  const axis=(mx,my)=>{ if(!mx&&!my) return;
    if(F.free(sc,p,p.rx+mx,p.ry+my,out)){ p.rx+=mx; p.ry+=my; moved=true; return; }
    const ev=out.ev; if(ev){ F.bump(sc,p,ev,mx,my); }
    const mag=Math.max(Math.abs(mx),Math.abs(my)); // geser halus di sudut
    for(const s of [1,-1]){ const nx=mx?p.rx+mx:p.rx+s*.34, ny=my?p.ry+my:p.ry+s*.34; if(mx&&F.free(sc,p,p.rx+mx,p.ry+s*.34)){ p.ry+=s*Math.min(mag*.8,.05); moved=true; return; } if(my&&F.free(sc,p,p.rx+s*.34,p.ry+my)){ p.rx+=s*Math.min(mag*.8,.05); moved=true; return; } }
  };
  axis(dx,0); axis(0,dy);
  const nx=Math.round(p.rx), ny=Math.round(p.ry);
  if(nx!==ox||ny!==oy){ const d=nx>ox?6:nx<ox?4:ny>oy?2:8; p.x=nx; p.y=ny; sc.history.unshift({x:ox,y:oy,dir:d}); if(sc.history.length>8) sc.history.pop(); sc.followers.forEach((f,i)=>{ const h=sc.history[i]; if(h){ f.dir=h.dir; f.speed=4+(p.dashing?1:0); f.dashing=false; f.x=h.x; f.y=h.y; f.moving=true; f.walkAnim=true; } }); if(p.onStep) p.onStep(); }
  return moved;
};
F.bump = function(sc,p,ev,mx,my){
  if(ev.mover&&ev.moverCfg.mode==='push'){ const d=Math.abs(mx)>=Math.abs(my)?(mx>0?6:4):(my>0?2:8); M.pushTry(sc,ev,d); return; }
  if(!sc.co&&(ev.trigger===1||ev.trigger===2)&&ev.list&&ev.prio===1) sc.startEvent(ev);
};
F.input = function(sc,I,g){
  const p=sc.player; p.dashing=I.isDown('shift')&&R.$db.system.dashEnabled&&!sc.map.data.disableDash;
  let ax=0, ay=0; const an=I.analog;
  if(an&&(Math.abs(an.x)>.18||Math.abs(an.y)>.18)){ ax=an.x; ay=an.y; } else { ax=(I.down.right?1:0)-(I.down.left?1:0); ay=(I.down.down?1:0)-(I.down.up?1:0); }
  if(ax||ay){ const len=Math.hypot(ax,ay); if(len>1){ ax/=len; ay/=len; } if(!p.dirFix){ if(Math.abs(ax)>Math.abs(ay)+.01) p.dir=ax>0?6:4; else if(Math.abs(ay)>Math.abs(ax)+.01) p.dir=ay>0?2:8; else if(!I.down.left&&!I.down.right&&!an) p.dir=ay>0?2:8; }
    const v=.0625*(p.dashing?1.7:1); const ok=F.step(sc,p,ax*v,ay*v); p.freeWalk=ok; p.dashing=p.dashing&&ok; } else p.freeWalk=false;
  if(I.pressed('ok')&&sc.checkAction()) return;
  if((I.pressed('cancel')||I.pressed('menu'))&&g.flags.menu){ R.Audio.se('OK'); R.SM.push(new R.Scene_Menu()); }
};
/* titik di depan pemain (untuk interaksi) */
F.front = function(p,dist){ const cx=p.rx+.5+DX[p.dir]*(dist||.75), cy=p.ry+.75+DY[p.dir]*(dist||.75)-.25; return {x:Math.floor(cx),y:Math.floor(cy)}; };

/* ================= PINTU ================= */
D.defaults = () => ({style:'wood',locked:false,keyItem:0,consume:true,lockSwitch:0,msgLocked:'It is locked.',msgUnlock:'Unlocked!',autoClose:false,closeDelay:150,closable:false,startOpen:false});
R.initDoor = function(ev){
  const d=ev.data.door; if(!d) return; ev.doorCfg=Object.assign(D.defaults(),d);
  const g=R.$game, mid=ev.map.id, st=g.selfSw||(g.selfSw={});
  ev.door={open:0,dir:0,idle:0,unlocked:!!st[key(mid,ev.id,'U')]};
  if(st[key(mid,ev.id,'D')]||ev.doorCfg.startOpen&&st[key(mid,ev.id,'D')]!==0) ev.door.open=1;
  ev.trigger=-1; ev.list=null; ev.through=ev.door.open>=1;
};
D.locked = ev => { const c=ev.doorCfg, g=R.$game; if(!c.locked||ev.door.unlocked) return false; if(c.lockSwitch&&g.s(c.lockSwitch)){ ev.door.unlocked=true; return false; } return true; };
D.say = function(sc,text,after){ const list=[{c:'text',i:0,face:'',pos:'bottom',bg:'window',text:text}]; sc.inEvent=true; sc.co=new R.Co((function*(){ yield* sc.interp.run(list,{eventId:0,evt:null,common:true}); sc.inEvent=false; if(after) after(); })()); };
D.setOpen = function(ev,open,perm){ const g=R.$game, k=key(ev.map.id,ev.id,'D'); ev.door.dir=open?1:-1; ev.door.idle=0; if(perm!==false) g.selfSw[k]=open?1:0; R.Audio.se('Door',.8); };
D.interact = function(sc,ev){
  const c=ev.doorCfg, d=ev.door, g=R.$game; if(d.dir!==0&&d.open>0&&d.open<1) return true;
  if(d.open>=1){ if(c.closable||c.autoClose){ const p=sc.player; if(Math.hypot(p.rx-ev.x,p.ry-ev.y)>1.05) D.setOpen(ev,false,!c.autoClose); } return true; }
  if(D.locked(ev)){
    const kid=c.keyItem, it=kid&&R.$db.items[kid-1];
    if(kid&&g.numItems('item',kid)>0){ if(c.consume) g.gainItem('item',kid,-1); d.unlocked=true; g.selfSw[key(ev.map.id,ev.id,'U')]=1; R.Audio.se('Chest',.8); D.say(sc,(c.msgUnlock||'Unlocked!')+(it?'  (\\C[6]'+it.name+'\\C[0])':''),()=>D.setOpen(ev,true,!c.autoClose)); return true; }
    R.Audio.se('Buzzer',.6); D.say(sc,(c.msgLocked||'It is locked.')+(it?'\nYou need \\C[6]'+it.name+'\\C[0].':'')); return true;
  }
  D.setOpen(ev,true,!c.autoClose); return true;
};
D.update = function(ev){
  const d=ev.door, c=ev.doorCfg, sc=R.$scene; if(!d) return;
  if(d.dir>0){ d.open=Math.min(1,d.open+1/16); if(d.open>=1) d.dir=0; } else if(d.dir<0){ const p=sc&&sc.player; if(p&&Math.hypot(p.rx-ev.x,p.ry-ev.y)<1){ /* jangan jepit pemain */ } else { d.open=Math.max(0,d.open-1/16); if(d.open<=0) d.dir=0; } }
  if(d.open>=1&&c.autoClose&&d.dir===0&&sc&&sc.player){ const p=sc.player; if(Math.hypot(p.rx-ev.x,p.ry-ev.y)>1.6){ d.idle++; if(d.idle>c.closeDelay) D.setOpen(ev,false,false); } else d.idle=0; }
  ev.through=d.open>=.7;
};
D.draw = function(g,ev,p){
  const c=ev.doorCfg, d=ev.door, t=d.open, x=p.x, y=p.y; g.save(); g.beginPath(); g.rect(x,y,48,48); g.clip();
  // ruang gelap di balik pintu
  const gr=g.createLinearGradient(0,y,0,y+48); gr.addColorStop(0,'#0c0a10'); gr.addColorStop(1,'#1c1722'); g.fillStyle=gr; g.fillRect(x,y,48,48);
  const style=c.style;
  if(style==='gate'){ const lift=t*40; g.beginPath(); g.rect(x,y,48,48); g.clip(); g.fillStyle='#4a4f5a'; g.fillRect(x+2,y,44,6); g.fillStyle='#8e96a6'; for(let i=0;i<6;i++){ g.fillRect(x+5+i*7,y-lift+4,3,44); } g.fillStyle='#6a7282'; g.fillRect(x+2,y-lift+14,44,3); g.fillRect(x+2,y-lift+30,44,3); g.fillStyle='#3a3e48'; g.fillRect(x,y,3,48); g.fillRect(x+45,y,3,48); }
  else if(style==='stone'){ const sl=t*40; g.fillStyle='#7a7a86'; g.fillRect(x+4-sl,y+2,40,44); g.strokeStyle='#4a4a56'; g.lineWidth=2; g.strokeRect(x+4-sl+1,y+3,38,42); g.beginPath(); g.moveTo(x+4-sl,y+24); g.lineTo(x+44-sl,y+24); g.moveTo(x+24-sl,y+2); g.lineTo(x+24-sl,y+46); g.stroke(); }
  else { const w=Math.max(4,40*(1-t*.88)), hx=x+4; g.fillStyle=style==='iron'?'#3a3f48':'#5a3b22'; g.fillRect(x,y,48,48); g.fillStyle='#0c0a10'; g.fillRect(x+4,y+4,40,42);
    if(t<1){ g.fillStyle=style==='iron'?'#6b7380':'#a2713f'; g.fillRect(hx,y+4,w,42); if(style==='iron'){ g.fillStyle='#aab3c2'; for(let i=0;i<5;i++){ const bx=hx+(i+.5)*w/5; g.fillRect(bx-1.2,y+4,2.4,42); } g.fillRect(hx,y+14,w,3); g.fillRect(hx,y+30,w,3); } else { g.strokeStyle='#6e4a28'; g.lineWidth=1.5; for(let i=1;i<4;i++){ g.beginPath(); g.moveTo(hx+i*w/4,y+4); g.lineTo(hx+i*w/4,y+46); g.stroke(); } g.fillStyle='#4a3018'; g.fillRect(hx,y+12,w,3); g.fillRect(hx,y+34,w,3); }
      g.fillStyle='rgba(0,0,0,'+(.45*t)+')'; g.fillRect(hx,y+4,w,42); g.fillStyle='#e6c45a'; g.beginPath(); g.arc(hx+w-6*(1-t*.5),y+26,2.6,0,6.3); g.fill(); }
    g.fillStyle=style==='iron'?'#2c3038':'#3b2614'; g.fillRect(x,y,48,4); }
  g.restore();
  if(D.locked(ev)&&t<.2){ g.save(); g.translate(x+36,y+30); g.fillStyle='#e8c44a'; g.fillRect(-6,0,12,10); g.strokeStyle='#e8c44a'; g.lineWidth=2.4; g.beginPath(); g.arc(0,0,4.5,Math.PI,0); g.stroke(); g.fillStyle='#463508'; g.fillRect(-1,3,2,4); g.restore(); }
};

/* ================= DINDING / BLOK YANG BERGERAK ================= */
M.defaults = () => ({mode:'ok',dir:'right',dist:2,speed:3,switch:0,toggle:false,once:true,se:'Door'});
const DIRS={up:8,down:2,left:4,right:6};
R.initMover = function(ev){
  const cfg=Object.assign(M.defaults(),ev.data.mover); ev.moverCfg=cfg; const g=R.$game, mid=ev.map.id, st=g.selfSw||(g.selfSw={});
  ev.mover={moved:!!st[key(mid,ev.id,'M')],queue:[],pushT:0,sx:ev.data.x,sy:ev.data.y};
  if(cfg.mode==='push'){ const pos=st[key(mid,ev.id,'P')]; if(pos){ const a=String(pos).split(','); ev.setPos(+a[0],+a[1]); } }
  else if(ev.mover.moved){ const d=DIRS[cfg.dir]||6; ev.setPos(ev.data.x+DX[d]*cfg.dist,ev.data.y+DY[d]*cfg.dist); }
};
M.trigger = function(ev,back){ const m=ev.mover, cfg=ev.moverCfg, g=R.$game; if(m.queue.length||ev.moving) return; const d=DIRS[cfg.dir]||6, bd={2:8,8:2,4:6,6:4}[d]; if(back){ if(!m.moved) return; m.queue=Array(cfg.dist).fill(bd); m.moved=false; g.selfSw[key(ev.map.id,ev.id,'M')]=0; } else { if(m.moved&&!cfg.toggle) return; if(m.moved){ m.queue=Array(cfg.dist).fill(bd); m.moved=false; g.selfSw[key(ev.map.id,ev.id,'M')]=0; } else { m.queue=Array(cfg.dist).fill(d); m.moved=true; g.selfSw[key(ev.map.id,ev.id,'M')]=1; } } if(cfg.se&&cfg.se!=='None') R.Audio.se(cfg.se,.7); };
M.activate = function(sc,ev){ if(ev.moverCfg.mode!=='ok') return false; M.trigger(ev,false); return true; };
M.pushTry = function(sc,ev,d){ const m=ev.mover; m.lastBump=R.$game.frames; if(m.queue.length||ev.moving) return; m.pushT++; if(m.pushT<12) return; m.pushT=0; const nx=ev.x+DX[d], ny=ev.y+DY[d], p=sc.player; if(!sc.map.valid(nx,ny)||!sc.map.passable(nx,ny)||sc.map.eventBlockAt(nx,ny,ev)) { R.Audio.se('Buzzer',.3); return; } if(Math.hypot(nx-p.rx,ny-p.ry)<.9) return; m.queue=[d]; R.Audio.se('Step',.9); };
M.update = function(ev,map){
  const m=ev.mover, cfg=ev.moverCfg, sc=R.$scene, g=R.$game; if(!m||!sc) return;
  if(cfg.mode==='switch'&&cfg.switch&&!m.queue.length&&!ev.moving){ const on=g.s(cfg.switch); if(on&&!m.moved) M.trigger(ev,false); else if(!on&&m.moved&&cfg.toggle) M.trigger(ev,true); }
  if(cfg.mode==='push'&&m.pushT>0&&g.frames-(m.lastBump||0)>4) m.pushT=0;
  if(m.queue.length&&!ev.moving){ const d=m.queue[0], p=sc.player, nx=ev.x+DX[d], ny=ev.y+DY[d]; if(Math.hypot(nx-p.rx,ny-p.ry)<.95&&cfg.mode!=='push') return; if(cfg.mode==='push'&&!map.passable(nx,ny)){ m.queue=[]; return; } ev.speed=cfg.speed; ev.dir=ev.dir; if(ev.moveStraight(d,map,true)){ m.queue.shift(); if(cfg.mode==='push'){ g.selfSw[key(map.id,ev.id,'P')]=ev.x+','+ev.y; } } }
};
})();
