/* Bagian 4: ikon 32x32, window skin, efek animasi, audio sintetis (WebAudio) */
(function(){
'use strict';
const R = window.RPG, H = R.H, shade = R.shade;
const {rect,circ,ell,poly,line,rr} = H;

/* ---------- IKON ---------- */
const ICONS = R.ICONS = []; // {name, draw}
function IC(name,fn){ ICONS.push({name:name,draw:fn}); }
const blade=(g,c,x1,y1,x2,y2,w)=>{ line(g,'#5e6068',x1,y1,x2,y2,(w||4)+2); line(g,c,x1,y1,x2,y2,w||4); };
IC('Potion Red',g=>{ rect(g,'#c9ccd4',13,3,6,5); rr(g,'#d9433a',7,10,18,19,8); rr(g,'#ff8a80',10,13,4,9,2); rect(g,'#8a5a30',12,2,8,3); });
IC('Potion Blue',g=>{ rect(g,'#c9ccd4',13,3,6,5); rr(g,'#3a7fe8',7,10,18,19,8); rr(g,'#9cc8ff',10,13,4,9,2); rect(g,'#8a5a30',12,2,8,3); });
IC('Potion Green',g=>{ rect(g,'#c9ccd4',13,3,6,5); rr(g,'#3aa851',7,10,18,19,8); rr(g,'#9cf0a8',10,13,4,9,2); rect(g,'#8a5a30',12,2,8,3); });
IC('Potion Gold',g=>{ rect(g,'#c9ccd4',13,3,6,5); rr(g,'#e8b02a',7,10,18,19,8); rr(g,'#fff0a0',10,13,4,9,2); rect(g,'#8a5a30',12,2,8,3); });
IC('Herb',g=>{ line(g,'#3a8a3a',16,28,16,8,2.5); poly(g,'#4aa851',16,16,6,8,10,20); poly(g,'#4aa851',16,12,26,4,22,16); poly(g,'#6bc86b',16,22,26,16,22,26); });
IC('Antidote',g=>{ rr(g,'#a8f0a8',9,6,14,22,6); rect(g,'#8a5a30',12,3,8,4); line(g,'#3a8a3a',13,14,19,22,2); line(g,'#3a8a3a',19,14,13,22,2); });
IC('Elixir',g=>{ rect(g,'#c9ccd4',13,2,6,6); rr(g,'#b46af0',6,9,20,20,9); circ(g,'#ffe27a',16,19,5); rect(g,'#e8c25a',12,2,8,3); });
IC('Tent',g=>{ poly(g,'#d98b2b',16,4,30,28,2,28); poly(g,'#2a2a30',16,14,22,28,10,28); });
IC('Sword',g=>{ blade(g,'#e4e8f0',6,26,24,8,3); rect(g,'#8a5a30',3,24,8,3); line(g,'#e8c25a',9,19,15,25,3); circ(g,'#e8c25a',4,28,2); });
IC('Long Sword',g=>{ blade(g,'#dfe6f2',5,27,26,6,3); line(g,'#a8353f',8,18,14,24,4); circ(g,'#e8c25a',4,28,2.5); });
IC('Dagger',g=>{ blade(g,'#e4e8f0',10,22,22,10,3); line(g,'#6b4423',8,24,12,20,4); });
IC('Axe',g=>{ line(g,'#8a5a30',8,28,22,6,3); poly(g,'#c9ccd4',16,6,28,10,26,20,18,16); poly(g,'#e4e8f0',18,8,26,11,25,16); });
IC('Spear',g=>{ line(g,'#8a5a30',5,28,22,9,3); poly(g,'#e4e8f0',22,9,28,3,26,12); });
IC('Bow',g=>{ g.strokeStyle='#8a5a30'; g.lineWidth=3; g.beginPath(); g.arc(4,16,14,-1.1,1.1); g.stroke(); line(g,'#ddd',10,5,10,27,1); line(g,'#c9ccd4',6,16,28,16,1.5); poly(g,'#c9ccd4',28,16,23,13,23,19); });
IC('Staff',g=>{ line(g,'#8a5a30',7,28,22,10,3); circ(g,'#e8c25a',24,7,5); circ(g,'#d9433a',24,7,3); });
IC('Rod',g=>{ line(g,'#6b4423',6,27,22,11,3); circ(g,'#6aa8f0',24,8,5); circ(g,'#fff',23,7,1.5); });
IC('Shield',g=>{ poly(g,'#6a7a9a',16,3,28,8,26,20,16,29,6,20,4,8); poly(g,'#8a9ab8',16,5,26,9,24,19,16,26,8,19,6,9); line(g,'#e8c25a',16,6,16,26,2); line(g,'#e8c25a',7,14,25,14,2); });
IC('Wood Shield',g=>{ circ(g,'#8a5a30',16,16,12); circ(g,'#a67c45',16,16,9); circ(g,'#8d909a',16,16,3); line(g,'#6b4423',16,5,16,27,1.5); });
IC('Helmet',g=>{ g.fillStyle='#aab0bc'; g.beginPath(); g.arc(16,16,11,3.14,6.28); g.fill(); rect(g,'#aab0bc',5,16,22,9); rect(g,'#2a2a30',10,17,12,4); rect(g,'#d9433a',15,3,2,6); });
IC('Cap',g=>{ g.fillStyle='#a67c45'; g.beginPath(); g.arc(16,18,11,3.14,6.28); g.fill(); rect(g,'#8a5a30',3,18,26,4); });
IC('Hat',g=>{ ell(g,'#6a3ab0',16,22,14,4); poly(g,'#6a3ab0',9,22,16,3,23,22); rect(g,'#e8c25a',9,19,14,3); });
IC('Armor',g=>{ poly(g,'#aab0bc',8,6,24,6,29,12,26,16,24,14,24,28,8,28,8,14,6,16,3,12); rect(g,'#8d909a',14,6,4,22); rect(g,'#e8c25a',8,22,16,3); });
IC('Robe',g=>{ poly(g,'#6a3ab0',10,5,22,5,28,28,4,28); rect(g,'#e8c25a',10,5,12,3); rect(g,'#e8c25a',12,18,8,2); });
IC('Leather Armor',g=>{ poly(g,'#a8794a',8,6,24,6,29,12,26,16,24,14,24,28,8,28,8,14,6,16,3,12); line(g,'#6b4423',16,8,16,28,2); });
IC('Boots',g=>{ poly(g,'#6b4423',9,4,19,4,19,18,28,22,28,28,9,28); rect(g,'#8a5a30',9,24,19,4); });
IC('Gloves',g=>{ rr(g,'#a8794a',8,12,16,16,5); for(let i=0;i<4;i++) rr(g,'#a8794a',8+i*4,5+(i%2)*2,4,12,2); });
IC('Ring',g=>{ g.strokeStyle='#e8c25a'; g.lineWidth=4; g.beginPath(); g.arc(16,19,8,0,6.3); g.stroke(); poly(g,'#6aa8f0',16,3,21,9,16,13,11,9); });
IC('Amulet',g=>{ g.strokeStyle='#c9ccd4'; g.lineWidth=2; g.beginPath(); g.arc(16,10,9,0.2,2.9); g.stroke(); circ(g,'#e8c25a',16,20,7); circ(g,'#d9433a',16,20,4); });
IC('Key',g=>{ g.strokeStyle='#e8c25a'; g.lineWidth=4; g.beginPath(); g.arc(9,9,5,0,6.3); g.stroke(); line(g,'#e8c25a',13,13,27,27,4); line(g,'#e8c25a',22,22,26,18,3); line(g,'#e8c25a',26,26,30,22,3); });
IC('Scroll',g=>{ rr(g,'#f0e6c8',7,5,18,22,3); rect(g,'#c8b888',5,3,22,4); rect(g,'#c8b888',5,25,22,4); for(let y=10;y<24;y+=4) line(g,'#8a6a40',10,y,22,y,1.5); });
IC('Book',g=>{ rr(g,'#a8353f',6,4,20,24,2); rect(g,'#f0e6c8',9,6,15,20); rect(g,'#e8c25a',11,10,10,2); rect(g,'#e8c25a',11,15,10,2); });
IC('Gem Blue',g=>{ poly(g,'#6aa8f0',16,4,26,12,16,28,6,12); poly(g,'#9cc8ff',16,4,6,12,16,12); poly(g,'#4a88d0',16,12,26,12,16,28); });
IC('Gem Red',g=>{ poly(g,'#e8433f',16,4,26,12,16,28,6,12); poly(g,'#ff8a80',16,4,6,12,16,12); poly(g,'#b8282a',16,12,26,12,16,28); });
IC('Gem Green',g=>{ poly(g,'#3aa851',16,4,26,12,16,28,6,12); poly(g,'#9cf0a8',16,4,6,12,16,12); poly(g,'#2a8a3a',16,12,26,12,16,28); });
IC('Coin',g=>{ circ(g,'#c8981a',16,16,12); circ(g,'#e8c25a',16,16,10); circ(g,'#ffe27a',14,14,4); line(g,'#c8981a',16,9,16,23,2.5); });
IC('Bag',g=>{ poly(g,'#a8794a',10,8,22,8,28,26,4,26); rect(g,'#6b4423',11,5,10,4); line(g,'#6b4423',12,14,20,14,2); });
IC('Meat',g=>{ ell(g,'#a8431f',15,17,11,8); ell(g,'#c0562a',13,15,6,4); rect(g,'#f0e6d0',22,20,8,4); circ(g,'#f0e6d0',29,19,3); circ(g,'#f0e6d0',29,25,3); });
IC('Bread',g=>{ ell(g,'#d9a050',16,18,13,8); ell(g,'#e8bd70',16,15,11,5); for(const x of [10,16,22]) line(g,'#b8782a',x,11,x+2,17,1.5); });
IC('Apple',g=>{ circ(g,'#d9433a',12,18,8); circ(g,'#d9433a',20,18,8); line(g,'#6b4423',16,10,17,4,2); poly(g,'#4aa851',17,6,25,4,21,10); });
IC('Fish',g=>{ ell(g,'#6aa8f0',14,16,11,7); poly(g,'#6aa8f0',24,16,31,8,31,24); circ(g,'#222',8,14,1.5); });
IC('Bomb',g=>{ circ(g,'#3a3a44',15,19,11); circ(g,'#6d6d78',11,15,3); line(g,'#6b4423',20,10,25,5,2); circ(g,'#ffa63a',26,4,3); });
IC('Feather',g=>{ poly(g,'#f4f4f4',6,28,12,12,26,4,22,18,10,26); line(g,'#aaa',6,28,24,6,1.5); });
IC('Fang',g=>{ poly(g,'#f0e6d0',10,6,22,6,16,28); });
IC('Star',g=>{ poly(g,'#ffe27a',16,2,20,12,30,12,22,19,25,29,16,23,7,29,10,19,2,12,12,12); });
IC('Heart',g=>{ circ(g,'#e8433f',11,12,7); circ(g,'#e8433f',21,12,7); poly(g,'#e8433f',4,15,28,15,16,29); });
IC('Skull',g=>{ circ(g,'#e8e4d4',16,13,10); rect(g,'#e8e4d4',10,18,12,8); circ(g,'#222',12,13,3); circ(g,'#222',20,13,3); });
IC('Fire',g=>{ poly(g,'#e8601a',16,2,26,16,24,26,16,30,8,26,6,16); poly(g,'#ffa63a',16,10,22,20,16,28,10,20); poly(g,'#ffe27a',16,18,19,24,16,28,13,24); });
IC('Ice',g=>{ for(let a=0;a<3;a++){ const r=a*1.047; line(g,'#9cd8f8',16-14*Math.cos(r),16-14*Math.sin(r),16+14*Math.cos(r),16+14*Math.sin(r),3);} circ(g,'#e8f8ff',16,16,3); });
IC('Lightning',g=>{ poly(g,'#ffe27a',18,2,6,18,14,18,10,30,26,12,17,12); });
IC('Wind',g=>{ g.strokeStyle='#aee8c8'; g.lineWidth=3; g.lineCap='round'; for(let i=0;i<3;i++){ g.beginPath(); g.moveTo(4,9+i*7); g.bezierCurveTo(16,6+i*7,24,16+i*7,28-i*3,10+i*7); g.stroke(); } });
IC('Heal',g=>{ circ(g,'#4aa851',16,16,13); rect(g,'#fff',13,7,6,18); rect(g,'#fff',7,13,18,6); });
IC('Poison',g=>{ circ(g,'#8a4ae8',16,12,9); rect(g,'#8a4ae8',9,12,14,8); circ(g,'#222',12,12,2.5); circ(g,'#222',20,12,2.5); circ(g,'#8a4ae8',8,26,3); circ(g,'#8a4ae8',24,26,3); });
IC('Shield Icon',g=>{ poly(g,'#6aa8f0',16,2,28,7,26,19,16,30,6,19,4,7); poly(g,'#9cc8ff',16,6,24,9,22,18,16,26,10,18,8,9); });
IC('Magic Circle',g=>{ g.strokeStyle='#b46af0'; g.lineWidth=2; g.beginPath(); g.arc(16,16,13,0,6.3); g.stroke(); g.beginPath(); g.arc(16,16,8,0,6.3); g.stroke(); poly(g,'rgba(180,106,240,.6)',16,5,26,22,6,22); });
IC('Crown',g=>{ poly(g,'#e8c25a',4,24,4,8,11,16,16,4,21,16,28,8,28,24); rect(g,'#c8981a',4,22,24,4); circ(g,'#d9433a',16,16,2); });
IC('Wand',g=>{ line(g,'#2a2a30',6,27,23,10,3); line(g,'#f4f4f4',6,27,10,23,3); poly(g,'#ffe27a',24,3,26,8,31,9,27,12,28,17,24,14,20,17,21,12,17,9,22,8); });
IC('Flag',g=>{ line(g,'#6b4423',8,4,8,29,3); poly(g,'#d9433a',9,5,28,10,9,17); });
IC('Torch',g=>{ line(g,'#8a5a30',16,29,16,14,4); poly(g,'#e8601a',16,2,22,12,10,12); poly(g,'#ffd05a',16,6,19,12,13,12); });
IC('Map',g=>{ poly(g,'#e8d6a8',3,6,11,4,21,7,29,5,29,26,21,28,11,25,3,27); line(g,'#a8353f',9,22,22,12,2); line(g,'#a8353f',20,10,24,14,2); line(g,'#a8353f',24,10,20,14,2); });
R.ICON_COLS = 16;
R.iconSheet = function(){ if(R._iconSheet) return R._iconSheet; const cols=R.ICON_COLS, rows=Math.ceil(ICONS.length/cols); const c=R.mkCanvas(cols*32,rows*32), g=c.getContext('2d'); ICONS.forEach((ic,i)=>{ g.save(); g.translate((i%cols)*32,((i/cols)|0)*32); ic.draw(g); g.restore(); }); R._iconSheet=c; return c; };
R.drawIcon = function(g,idx,x,y,s){ s=s||32; if(!idx||idx<1) return; const i=idx-1; if(i>=ICONS.length) return; const cols=R.ICON_COLS; g.drawImage(R.iconSheet(),(i%cols)*32,((i/cols)|0)*32,32,32,x,y,s,s); };
R.iconByName = n => { const i=ICONS.findIndex(o=>o.name===n); return i<0?0:i+1; };

/* ---------- EFEK ANIMASI (dirender langsung) ---------- */
R.ANIMS = ['Slash','Hit','Fire','Ice','Thunder','Heal','Buff','Dark','Wind','Explosion'];
R.drawAnim = function(g,name,x,y,t){ // t 0..1
  const e = t*t*(3-2*t), a = 1-t;
  g.save(); g.globalAlpha = Math.max(0,Math.min(1,a*1.6));
  switch(name){
    case 'Slash': g.strokeStyle='#fff'; g.lineWidth=6*a+1; g.lineCap='round'; g.beginPath(); g.moveTo(x-40+e*80,y-40+e*10); g.lineTo(x-10+e*80,y+30); g.stroke(); g.strokeStyle='#8ad'; g.lineWidth=2; g.stroke(); break;
    case 'Hit': for(let i=0;i<8;i++){ const an=i*.785, d=10+e*34; line(g,'#ffe27a',x+Math.cos(an)*d*.4,y+Math.sin(an)*d*.4,x+Math.cos(an)*d,y+Math.sin(an)*d,3); } circ(g,'rgba(255,255,255,.7)',x,y,16*a); break;
    case 'Fire': for(let i=0;i<9;i++){ const px=x+Math.sin(i*2.1)*26, py=y+20-e*50-i*2; circ(g,i%2?'#ffa63a':'#e8601a',px,py,10*a+3); } break;
    case 'Ice': for(let i=0;i<6;i++){ const an=i*1.047; const d=e*34; poly(g,'#bfeaff',x+Math.cos(an)*d,y+Math.sin(an)*d-9,x+Math.cos(an)*d+5,y+Math.sin(an)*d,x+Math.cos(an)*d,y+Math.sin(an)*d+9); } break;
    case 'Thunder': g.strokeStyle='#ffe27a'; g.lineWidth=4; g.beginPath(); g.moveTo(x,y-90); let cy=y-90; for(let i=0;i<5;i++){ cy+=(y+10-(y-90))/5; g.lineTo(x+((i%2)?14:-14)*(1-t),cy); } g.stroke(); circ(g,'rgba(255,255,200,.5)',x,y,26*a+4); break;
    case 'Heal': for(let i=0;i<7;i++){ const px=x+Math.sin(i*2.3)*24, py=y+26-e*60+i*3; rect(g,'#9cf0a8',px-1,py-5,3,11); rect(g,'#9cf0a8',px-5,py-1,11,3); } break;
    case 'Buff': g.strokeStyle='#ffe27a'; g.lineWidth=4; g.beginPath(); g.ellipse(x,y+20-e*30,26,8,0,0,6.3); g.stroke(); break;
    case 'Dark': for(let i=0;i<10;i++){ const an=i*.63+e*3; circ(g,'#8a4ae8',x+Math.cos(an)*(36-e*30),y+Math.sin(an)*(36-e*30),6*a+2); } break;
    case 'Wind': g.strokeStyle='#aee8c8'; g.lineWidth=3; for(let i=0;i<4;i++){ g.beginPath(); g.arc(x,y,12+i*8+e*10,i*1.6+e*5,i*1.6+e*5+2); g.stroke(); } break;
    case 'Explosion': circ(g,'#ffa63a',x,y,10+e*40); circ(g,'#ffe27a',x,y,6+e*24); for(let i=0;i<8;i++){ const an=i*.785; circ(g,'#e8601a',x+Math.cos(an)*e*54,y+Math.sin(an)*e*54,6*a+1);} break;
  }
  g.restore();
};

/* ---------- AUDIO sintetis ---------- */
const AU = R.Audio = { ctx:null, bgmTimer:null, bgmName:'', vol:{bgm:.5,se:.7}, muted:false };
AU.init = function(){ if(!AU.ctx){ try{ AU.ctx = new (window.AudioContext||window.webkitAudioContext)(); }catch(e){} } if(AU.ctx&&AU.ctx.state==='suspended') AU.ctx.resume(); };
const NOTE = n => 440*Math.pow(2,(n-69)/12);
AU.tone = function(freq,dur,type,vol,when,slide){ const c=AU.ctx; if(!c||AU.muted||c.state!=='running') return; const t=c.currentTime+(when||0); const o=c.createOscillator(), gn=c.createGain(); o.type=type||'square'; o.frequency.setValueAtTime(freq,t); if(slide) o.frequency.exponentialRampToValueAtTime(Math.max(20,slide),t+dur); gn.gain.setValueAtTime(0,t); gn.gain.linearRampToValueAtTime((vol||.2),t+.01); gn.gain.exponentialRampToValueAtTime(.0001,t+dur); o.connect(gn); gn.connect(c.destination); o.start(t); o.stop(t+dur+.02); };
AU.noise = function(dur,vol,when,hp){ const c=AU.ctx; if(!c||AU.muted||c.state!=='running') return; const t=c.currentTime+(when||0), n=c.sampleRate*dur, b=c.createBuffer(1,n,c.sampleRate), d=b.getChannelData(0); for(let i=0;i<n;i++) d[i]=Math.random()*2-1; const s=c.createBufferSource(); s.buffer=b; const f=c.createBiquadFilter(); f.type='highpass'; f.frequency.value=hp||800; const gn=c.createGain(); gn.gain.setValueAtTime(vol,t); gn.gain.exponentialRampToValueAtTime(.0001,t+dur); s.connect(f); f.connect(gn); gn.connect(c.destination); s.start(t); };
R.SE_LIST = ['Cursor','OK','Cancel','Buzzer','Hit','Crit','Heal','Coin','Door','Level Up','Magic','Step','Chest','Escape','Victory','Encounter'];
AU.se = function(name,v){ AU.init(); if(name&&/^audio\//.test(name)){ if(AU.muted) return; try{ const a=new Audio(name); a.volume=Math.min(1,AU.vol.se*(v===undefined?1:v)); a.play().catch(()=>{}); }catch(e){} return; } const sv=AU.vol.se*(v===undefined?1:v); const T=(f,d,ty,vo,w,sl)=>AU.tone(f,d,ty,vo*sv,w,sl);
  switch(name){
    case 'Cursor': T(880,.05,'square',.15); break;
    case 'OK': T(660,.06,'square',.18); T(990,.09,'square',.18,.06); break;
    case 'Cancel': T(500,.06,'square',.16); T(330,.1,'square',.16,.06); break;
    case 'Buzzer': T(140,.22,'sawtooth',.2); break;
    case 'Hit': AU.noise(.12,.35*sv,0,600); T(180,.12,'square',.2,0,60); break;
    case 'Crit': AU.noise(.2,.5*sv,0,400); T(260,.2,'sawtooth',.25,0,50); T(520,.1,'square',.2,0,200); break;
    case 'Heal': [72,76,79,84].forEach((n,i)=>T(NOTE(n),.16,'sine',.25,i*.08)); break;
    case 'Coin': T(NOTE(88),.06,'square',.15); T(NOTE(95),.2,'square',.15,.06); break;
    case 'Door': AU.noise(.18,.2*sv,0,200); T(120,.18,'triangle',.25,0,70); break;
    case 'Level Up': [72,76,79,84,79,84].forEach((n,i)=>T(NOTE(n),.14,'square',.18,i*.1)); break;
    case 'Magic': for(let i=0;i<6;i++) T(500+i*140,.12,'sine',.18,i*.04,900+i*140); break;
    case 'Step': AU.noise(.04,.08*sv,0,2000); break;
    case 'Chest': [67,71,74,79].forEach((n,i)=>T(NOTE(n),.12,'triangle',.25,i*.07)); break;
    case 'Escape': T(600,.25,'sawtooth',.18,0,150); break;
    case 'Victory': [67,67,67,72,71,74,79].forEach((n,i)=>T(NOTE(n),i===3?.3:.16,'square',.17,[0,.14,.28,.42,.66,.8,.94][i])); break;
    case 'Encounter': T(200,.4,'sawtooth',.2,0,40); AU.noise(.4,.3*sv,0,300); break;
  } };
/* BGM prosedural: tiap track = skala + pola + tempo */
R.BGM_LIST = ['None','Peaceful Village','Adventure Field','Dark Dungeon','Battle!','Boss Battle','Sad Tale','Castle Hall','Victory Fanfare'];
const TRACKS = {
 'Peaceful Village':{bpm:96,scale:[0,2,4,7,9],root:60,wave:'triangle',pat:[0,2,4,2,3,1,2,0,0,2,4,3,2,1,0,-1],bass:[0,0,3,3]},
 'Adventure Field':{bpm:118,scale:[0,2,4,5,7,9,11],root:62,wave:'square',pat:[0,2,4,2,5,4,2,4,3,5,7,5,4,2,1,0],bass:[0,4,5,3]},
 'Dark Dungeon':{bpm:70,scale:[0,2,3,5,7,8,10],root:48,wave:'sawtooth',pat:[0,-1,2,-1,3,-1,2,-1,0,-1,1,-1,-2,-1,0,-1],bass:[0,0,5,4]},
 'Battle!':{bpm:156,scale:[0,2,3,5,7,8,10],root:57,wave:'square',pat:[0,0,3,0,4,0,3,0,5,4,3,4,2,3,1,2],bass:[0,0,0,0,5,5,4,4]},
 'Boss Battle':{bpm:168,scale:[0,1,4,5,7,8,11],root:50,wave:'sawtooth',pat:[0,0,1,0,4,0,1,0,3,2,3,4,5,4,3,2],bass:[0,0,1,1,0,0,4,3]},
 'Sad Tale':{bpm:62,scale:[0,2,3,5,7,8,10],root:57,wave:'sine',pat:[0,-1,2,-1,3,-1,4,-1,3,-1,2,-1,1,-1,0,-1],bass:[0,0,3,4]},
 'Castle Hall':{bpm:84,scale:[0,2,4,5,7,9,11],root:55,wave:'triangle',pat:[0,2,4,7,4,2,0,2,3,5,7,5,3,2,1,0],bass:[0,3,4,0]},
 'Victory Fanfare':{bpm:140,scale:[0,2,4,5,7,9,11],root:64,wave:'square',pat:[0,0,0,2,4,-1,2,4,5,-1,4,2,0,-1,-1,-1],bass:[0,4,0,4]}
};
AU.playBgm = function(name){ if(name===AU.bgmName) return; AU.stopBgm(); AU.bgmName=name||''; if(name&&/^audio\//.test(name)){ try{ const a=new Audio(name); a.loop=true; a.volume=AU.muted?0:AU.vol.bgm; a.play().catch(()=>{}); AU.bgmEl=a; }catch(e){} return; } if(!name||name==='None'||!TRACKS[name]) return; AU.init(); const tr=TRACKS[name]; let step=0; const stepMs=60000/tr.bpm/2;
  const deg=(d,oct)=>{ const L=tr.scale.length; const o=Math.floor(d/L), i=((d%L)+L)%L; return tr.root+tr.scale[i]+12*(o+(oct||0)); };
  AU.bgmTimer=setInterval(()=>{ if(!AU.ctx||AU.muted) return; const p=tr.pat[step%tr.pat.length]; const bv=AU.vol.bgm;
    if(p>-1) AU.tone(NOTE(deg(p+(tr.bpm>140?0:0),0)),stepMs/1000*.9,tr.wave,.12*bv);
    if(step%4===0){ const b=tr.bass[(step/4|0)%tr.bass.length]; AU.tone(NOTE(deg(b,-2)),stepMs/1000*3.6,'triangle',.18*bv); }
    if(tr.bpm>140 && step%2===0) AU.noise(.03,.05*bv,0,5000);
    step++; },stepMs); };
AU.stopBgm = function(){ if(AU.bgmEl){ try{ AU.bgmEl.pause(); }catch(e){} AU.bgmEl=null; } if(AU.bgmTimer) clearInterval(AU.bgmTimer); AU.bgmTimer=null; AU.bgmName=''; };
})();
