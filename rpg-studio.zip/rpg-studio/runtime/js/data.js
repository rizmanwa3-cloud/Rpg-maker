/* Model data proyek + database default */
(function(){
'use strict';
const R = window.RPG;
R.PARAMS = ['mhp','mmp','atk','def','mat','mdf','agi','luk'];
R.PARAM_NAMES = {mhp:'Max HP',mmp:'Max MP',atk:'Attack',def:'Defense',mat:'M.Attack',mdf:'M.Defense',agi:'Agility',luk:'Luck'};
R.ELEMENTS = ['Physical','Fire','Ice','Thunder','Wind','Holy','Dark'];
R.EQUIP_SLOTS = ['Weapon','Shield','Head','Body','Accessory'];
R.SCOPES = ['None','One Enemy','All Enemies','One Ally','All Allies','User','One Dead Ally'];
R.OCCASIONS = ['Always','Battle Only','Menu Only','Never'];
R.SKILL_TYPES = ['Magic','Special','Skill'];
R.RESTRICT = ['None','Attack Enemy','Attack Anyone','Attack Ally','Cannot Move'];
R.deep = o => JSON.parse(JSON.stringify(o));
R.expFor = (cls,lv)=> lv<=1?0: Math.round((cls.expBase||30)*Math.pow(lv-1,1.6)+(cls.expExtra||20)*(lv-1));
R.paramAt = (cls,p,lv)=>{ const a=cls.params[p]||[10,1]; return Math.max(0,Math.round(a[0]+a[1]*(lv-1))); };

R.newEvent = function(id,x,y){ return {id:id,name:'EV'+String(id).padStart(3,'0'),x:x,y:y,pages:[R.newPage()]}; };
R.newPage = function(){ return {cond:{s1:0,s2:0,v:0,vv:0,selfSw:'',item:0,actor:0},img:{kind:'none'},dir:2,pat:1,move:{type:'fixed',speed:3,freq:3,route:[]},opt:{walkAnim:true,stepAnim:false,dirFix:false,through:false},prio:1,trigger:0,list:[{c:'empty',i:0}]}; };
R.newMap = function(id,name,w,h,fillTile){
  const n=w*h, l0=new Array(n).fill(fillTile||0);
  return {id:id,name:name||'MAP'+String(id).padStart(3,'0'),w:w,h:h,bgm:'None',bgs:'',battleBg:'Grass',encounters:[],encounterStep:30,layers:[l0,new Array(n).fill(0),new Array(n).fill(0),new Array(n).fill(0)],events:[],parent:0,disableDash:false,note:'',scroll:'loop-none'};
};
R.arr = (n,fn)=> Array.from({length:n},(_,i)=>fn(i+1));

const P = (mhp,mhpG,mmp,mmpG,atk,atkG,def,defG,mat,matG,mdf,mdfG,agi,agiG,luk,lukG)=>({mhp:[mhp,mhpG],mmp:[mmp,mmpG],atk:[atk,atkG],def:[def,defG],mat:[mat,matG],mdf:[mdf,mdfG],agi:[agi,agiG],luk:[luk,lukG]});

R.defaultDB = function(){
  const db = {};
  const ST = (name,icon,o)=>Object.assign({name:name,icon:R.iconByName(icon),desc:'',restrict:0,priority:50,turns:0,removeBattleEnd:true,removeOnDamage:0,hpRegen:0,mpRegen:0,paramRate:{},msg:'',autoRemove:true,note:''},o||{});
  db.states = [
    ST('Knockout','Skull',{restrict:4,priority:100,removeBattleEnd:false,msg:'%s is knocked out!'}),
    ST('Guard','Shield Icon',{priority:80,turns:1,paramRate:{def:150,mdf:150},msg:'%s is guarding.'}),
    ST('Poison','Poison',{turns:5,hpRegen:-8,removeBattleEnd:false,msg:'%s is poisoned!'}),
    ST('Sleep','Potion Blue',{restrict:4,priority:70,turns:3,removeOnDamage:100,msg:'%s fell asleep!'}),
    ST('Paralysis','Lightning',{restrict:4,priority:75,turns:2,msg:'%s is paralyzed!'}),
    ST('Attack Up','Sword',{turns:4,paramRate:{atk:150},msg:"%s's attack rises!"}),
    ST('Defense Up','Shield',{turns:4,paramRate:{def:150},msg:"%s's defense rises!"}),
    ST('Regen','Heal',{turns:5,hpRegen:12,msg:'%s is regenerating!'}),
    ST('Confusion','Wind',{restrict:2,turns:3,msg:'%s is confused!'}),
    ST('Burn','Fire',{turns:4,hpRegen:-10,msg:'%s is burning!'})
  ];
  db.states.forEach((s,i)=>s.id=i+1);
  const SK = (name,icon,o)=>Object.assign({name:name,icon:R.iconByName(icon),desc:'',mp:0,scope:1,occasion:1,type:'damage',formula:'a.atk * 4 - b.def * 2',element:0,variance:15,hit:100,crit:true,addStates:[],removeStates:[],anim:'Slash',speed:0,repeats:1,msg:'%s uses %s!',stype:2,note:''},o||{});
  db.skills = [
    SK('Attack','Sword',{desc:'Normal attack.',occasion:1,stype:0}),
    SK('Guard','Shield Icon',{desc:'Reduce damage this turn.',scope:5,type:'none',formula:'0',addStates:[{id:2,rate:100}],anim:'Buff',speed:2,stype:0,msg:'%s guards!'}),
    SK('Fire','Fire',{desc:'Fire damage to one enemy.',mp:6,formula:'a.mat * 3 + 20 - b.mdf',element:1,anim:'Fire',type:'damage',stype:1,addStates:[{id:10,rate:15}]}),
    SK('Ice','Ice',{desc:'Ice damage to one enemy.',mp:6,formula:'a.mat * 3 + 20 - b.mdf',element:2,anim:'Ice',stype:1}),
    SK('Thunder','Lightning',{desc:'Thunder damage to one enemy.',mp:8,formula:'a.mat * 3.4 + 24 - b.mdf',element:3,anim:'Thunder',stype:1,addStates:[{id:5,rate:15}]}),
    SK('Flame Storm','Fire',{desc:'Fire damage to all enemies.',mp:18,scope:2,formula:'a.mat * 2.4 + 16 - b.mdf',element:1,anim:'Explosion',stype:1}),
    SK('Heal','Heal',{desc:'Restore HP to one ally.',mp:5,scope:3,occasion:0,type:'heal',formula:'a.mat * 2 + 40',element:5,anim:'Heal',stype:1}),
    SK('Group Heal','Heal',{desc:'Restore HP to all allies.',mp:14,scope:4,occasion:0,type:'heal',formula:'a.mat * 1.4 + 28',element:5,anim:'Heal',stype:1}),
    SK('Power Strike','Axe',{desc:'Strong blow.',mp:4,formula:'a.atk * 6 - b.def * 2',anim:'Slash',stype:2}),
    SK('Poison Sting','Poison',{desc:'Weak hit that may poison.',mp:3,formula:'a.atk * 2 - b.def',addStates:[{id:3,rate:80}],anim:'Hit',stype:2}),
    SK('Lullaby','Magic Circle',{desc:'Put an enemy to sleep.',mp:7,type:'status',formula:'0',addStates:[{id:4,rate:70}],anim:'Dark',stype:1}),
    SK('War Cry','Flag',{desc:'Raise party attack.',mp:8,scope:4,occasion:1,type:'buff',formula:'0',addStates:[{id:6,rate:100}],anim:'Buff',stype:2}),
    SK('Revive','Star',{desc:'Revive a fallen ally.',mp:16,scope:6,occasion:0,type:'revive',formula:'a.mat * 1 + 20',anim:'Heal',stype:1}),
    SK('Double Slash','Dagger',{desc:'Two quick hits.',mp:5,formula:'a.atk * 3 - b.def * 1.5',repeats:2,anim:'Slash',stype:2}),
    SK('Dragon Breath','Fire',{desc:'Fiery breath.',mp:0,scope:2,formula:'a.mat * 2 + 30 - b.mdf',element:1,anim:'Explosion',stype:2,msg:'%s breathes fire!'}),
    SK('Bite','Fang',{desc:'Enemy bite.',mp:0,formula:'a.atk * 4 - b.def * 2',anim:'Hit',stype:0,msg:'%s bites!'})
  ];
  db.skills.forEach((s,i)=>s.id=i+1);
  const IT = (name,icon,price,o)=>Object.assign({name:name,icon:R.iconByName(icon),desc:'',price:price,key:false,consumable:true,scope:3,occasion:0,type:'heal',formula:'',hp:0,mp:0,hpPct:0,mpPct:0,addStates:[],removeStates:[],anim:'Heal',note:''},o||{});
  db.items = [
    IT('Potion','Potion Red',50,{desc:'Restores 100 HP.',hp:100}),
    IT('Hi-Potion','Potion Red',200,{desc:'Restores 400 HP.',hp:400}),
    IT('Magic Water','Potion Blue',100,{desc:'Restores 40 MP.',mp:40}),
    IT('Elixir','Elixir',1000,{desc:'Fully restores HP and MP.',hpPct:100,mpPct:100}),
    IT('Antidote','Antidote',40,{desc:'Cures poison.',removeStates:[3]}),
    IT('Herb','Herb',20,{desc:'Restores 40 HP.',hp:40}),
    IT('Revive Feather','Feather',300,{desc:'Revive a fallen ally with half HP.',scope:6,type:'revive',hpPct:50}),
    IT('Bomb','Bomb',120,{desc:'Deals fire damage to all enemies.',scope:2,occasion:1,type:'damage',formula:'80 + a.mat',anim:'Explosion'}),
    IT('Old Key','Key',0,{desc:'Opens the cave gate.',key:true,consumable:false,scope:0,occasion:3}),
    IT('Hero Crest','Crown',0,{desc:'Proof of the hero.',key:true,consumable:false,scope:0,occasion:3})
  ];
  db.items.forEach((s,i)=>s.id=i+1);
  const WP = (name,icon,price,atk,o)=>Object.assign({name:name,icon:R.iconByName(icon),desc:'',price:price,params:{atk:atk},anim:'Slash',note:''},o||{});
  db.weapons = [
    WP('Wooden Sword','Sword',100,6,{desc:'A practice sword.'}), WP('Iron Sword','Long Sword',400,14), WP('Steel Sword','Long Sword',1200,26),
    WP('Dagger','Dagger',250,9,{params:{atk:9,agi:4}}), WP('Battle Axe','Axe',900,24,{params:{atk:24,agi:-2}}),
    WP('Oak Staff','Staff',150,3,{params:{atk:3,mat:8},desc:'Boosts magic.'}), WP('Crystal Rod','Rod',1100,6,{params:{atk:6,mat:22}}),
    WP('Short Bow','Bow',300,10), WP('Spear','Spear',500,16)
  ];
  db.weapons.forEach((s,i)=>s.id=i+1);
  const AR = (name,icon,price,et,params,o)=>Object.assign({name:name,icon:R.iconByName(icon),desc:'',price:price,etype:et,params:params,note:''},o||{});
  db.armors = [
    AR('Wooden Shield','Wood Shield',120,1,{def:4}), AR('Iron Shield','Shield',500,1,{def:9}),
    AR('Leather Cap','Cap',90,2,{def:2}), AR('Iron Helmet','Helmet',450,2,{def:6}), AR('Wizard Hat','Hat',300,2,{def:1,mdf:6}),
    AR('Cloth Tunic','Robe',100,3,{def:3,mdf:2}), AR('Leather Armor','Leather Armor',350,3,{def:8}), AR('Iron Armor','Armor',1000,3,{def:16}), AR('Mage Robe','Robe',700,3,{def:4,mdf:14,mat:4}),
    AR('Power Ring','Ring',800,4,{atk:6}), AR('Guard Amulet','Amulet',800,4,{def:5,mdf:5}), AR('Swift Boots','Boots',600,4,{agi:10})
  ];
  db.armors.forEach((s,i)=>s.id=i+1);
  const CL = (name,params,skills,o)=>Object.assign({name:name,params:params,expBase:30,expExtra:20,learnings:skills,weaponOk:[1,2,3,4,5,6,7,8,9],armorOk:[1,2,3,4],note:''},o||{});
  db.classes = [
    CL('Knight',P(120,28,15,3,14,3.2,12,2.6,6,1,8,1.6,10,1.2,8,.6),[{lv:1,skill:9},{lv:6,skill:12},{lv:10,skill:14}]),
    CL('Mage',P(78,15,40,8,6,1.1,6,1.2,16,3.4,13,2.4,9,1.2,10,.6),[{lv:1,skill:3},{lv:3,skill:4},{lv:6,skill:5},{lv:10,skill:11},{lv:14,skill:6}]),
    CL('Warrior',P(140,32,8,2,16,3.6,10,2.3,4,.6,6,1,9,1,8,.5),[{lv:1,skill:9},{lv:4,skill:14},{lv:8,skill:12}]),
    CL('Cleric',P(90,18,34,7,8,1.4,8,1.5,14,3,14,2.6,10,1.2,11,.7),[{lv:1,skill:7},{lv:5,skill:8},{lv:9,skill:13},{lv:12,skill:3}]),
    CL('Villager',P(60,8,0,0,6,1,5,1,5,1,5,1,9,1,8,.5),[])
  ];
  db.classes.forEach((s,i)=>s.id=i+1);
  const AC = (name,cls,preset,lv,eq,o)=>Object.assign({name:name,cls:cls,char:preset,level:lv,maxLevel:99,equips:eq,nickname:'',profile:'',intro:'',note:''},o||{});
  db.actors = [
    AC('Aldric',1,'Hero',1,[1,1,3,6,0],{nickname:'Hero',profile:'A young adventurer chosen by fate.'}),
    AC('Mira',2,'Mage',1,[6,0,5,9,0],{nickname:'Mage',profile:'A prodigy of the arcane arts.'}),
    AC('Brann',3,'Warrior',1,[2,2,4,7,0],{nickname:'Warrior',profile:'A veteran fighter with a short temper.'}),
    AC('Lyra',4,'Healer',1,[6,0,3,6,0],{nickname:'Cleric',profile:'A gentle healer from the temple.'})
  ];
  db.actors.forEach((s,i)=>s.id=i+1);
  db.actors[0].equips=[1,1,3,6,0]; db.actors[1].equips=[6,0,5,9,0]; db.actors[2].equips=[2,2,4,7,0]; db.actors[3].equips=[6,0,3,6,0];
  const EN = (name,kind,color,hp,mp,atk,def,mat,mdf,agi,luk,exp,gold,o)=>Object.assign({name:name,kind:kind,color:color||R.MONSTER_DEFAULT_COLORS[kind],mhp:hp,mmp:mp,atk:atk,def:def,mat:mat,mdf:mdf,agi:agi,luk:luk,exp:exp,gold:gold,drops:[],actions:[{skill:1,rating:5,cond:'always'}],elem:{},stateRes:{},note:''},o||{});
  db.enemies = [
    EN('Slime','Slime',null,40,0,10,3,4,3,6,5,8,6,{drops:[{kind:'item',id:6,rate:30}]}),
    EN('Cave Bat','Bat',null,34,0,13,4,5,4,16,6,10,8,{actions:[{skill:1,rating:5,cond:'always'},{skill:10,rating:3,cond:'always'}]}),
    EN('Goblin','Goblin',null,70,0,18,7,4,4,10,6,18,16,{drops:[{kind:'item',id:1,rate:25},{kind:'weapon',id:4,rate:4}]}),
    EN('Skeleton','Skeleton',null,95,0,22,10,6,6,8,5,30,26,{elem:{5:200,2:50},actions:[{skill:1,rating:5,cond:'always'},{skill:9,rating:3,cond:'always'}]}),
    EN('Dire Wolf','Wolf',null,110,0,26,9,4,5,18,8,38,30,{actions:[{skill:16,rating:5,cond:'always'},{skill:1,rating:3,cond:'always'}]}),
    EN('Cave Spider','Spider',null,80,0,19,8,5,6,14,6,28,22,{actions:[{skill:10,rating:5,cond:'always'},{skill:1,rating:4,cond:'always'}]}),
    EN('Ghost','Ghost',null,90,40,10,8,22,14,12,7,42,34,{elem:{0:50,5:200,6:0},actions:[{skill:4,rating:5,cond:'always'},{skill:11,rating:2,cond:'always'}]}),
    EN('Toadstool','Mushroom',null,72,0,16,6,5,5,7,5,20,17,{drops:[{kind:'item',id:5,rate:35}]}),
    EN('Stone Golem','Golem',null,260,0,32,22,6,10,5,3,90,70,{elem:{3:150,1:100},actions:[{skill:9,rating:5,cond:'always'},{skill:1,rating:3,cond:'always'}]}),
    EN('Fire Imp','Imp',null,85,30,15,7,22,10,15,8,40,32,{elem:{2:200,1:0},actions:[{skill:3,rating:5,cond:'always'},{skill:1,rating:3,cond:'always'}]}),
    EN('Dark Knight','Knight',null,420,0,38,20,12,14,12,8,160,120,{actions:[{skill:9,rating:5,cond:'always'},{skill:1,rating:4,cond:'always'}],drops:[{kind:'armor',id:8,rate:30}]}),
    EN('Elder Dragon','Dragon',null,1100,120,46,24,38,24,14,10,600,500,{elem:{2:200,1:50},actions:[{skill:15,rating:5,cond:'hp<50'},{skill:16,rating:5,cond:'always'},{skill:1,rating:3,cond:'always'}],drops:[{kind:'armor',id:10,rate:100}]})
  ];
  db.enemies.forEach((s,i)=>s.id=i+1);
  const TR = (name,list,o)=>Object.assign({name:name,members:list,bg:'Grass',note:''},o||{});
  db.troops = [
    TR('Slime x2',[1,1]),TR('Slimes+Bat',[1,2,1]),TR('Goblin',[3]),TR('Goblin Pack',[3,3,1]),TR('Skeleton',[4]),
    TR('Wolf Pair',[5,5]),TR('Spider Nest',[6,6,2],{bg:'Cave'}),TR('Ghost',[7],{bg:'Cave'}),TR('Mushrooms',[8,8,8]),
    TR('Stone Golem',[9],{bg:'Cave'}),TR('Imps',[10,10],{bg:'Cave'}),TR('Cave Mix',[4,2,6],{bg:'Cave'}),TR('Dark Knight (Boss)',[11],{bg:'Cave'}),TR('Elder Dragon (Boss)',[12],{bg:'Cave'})
  ];
  db.troops.forEach((s,i)=>s.id=i+1);
  db.commonEvents = [{id:1,name:'Inn Rest',trigger:0,switch:0,list:[]},{id:2,name:'Heal Spring',trigger:0,switch:0,list:[]}];
  db.scenes = [{id:1,name:'Intro Scene',cinematic:true,list:[{c:'wait',i:0,frames:30},{c:'empty',i:0}]}];
  db.system = {
    title:'My RPG Game',subtitle:'',startMap:1,startX:15,startY:10,startDir:2,party:[1],currency:'G',
    titleBgm:'Peaceful Village',battleBgm:'Battle!',bossBgm:'Boss Battle',victoryBgm:'Victory Fanfare',gameoverBgm:'Sad Tale',
    screenW:816,screenH:624,windowColor:'#1c2a5c',textSpeed:2,
    switches:R.arr(30,i=>''),variables:R.arr(30,i=>''),
    terms:{newGame:'New Game',continue:'Continue',options:'Options',shutdown:'Quit',item:'Item',skill:'Skill',equip:'Equip',status:'Status',formation:'Formation',save:'Save',gameEnd:'Game End',fight:'Fight',escape:'Escape',attack:'Attack',guard:'Guard',buy:'Buy',sell:'Sell',cancel:'Cancel',level:'Lv',hp:'HP',mp:'MP',exp:'EXP',victory:'%s was victorious!',defeat:'%s was defeated.',gainExp:'%s EXP received!',gainGold:'%s G found!',levelUp:'%s is now level %s!',obtainItem:'%s found!',escapeStart:'%s tries to escape!',escapeFail:'But could not get away!',emerge:'%s appeared!',critical:'Critical hit!',miss:'Attack missed!',evade:'%s evaded!',dmg:'%s takes %s damage!',hpHeal:'%s recovers %s HP!',mpHeal:'%s recovers %s MP!',noDmg:'%s takes no damage!'},
    maxParty:4,encounterEnabled:true,dashEnabled:true,startingItems:[{kind:'item',id:1,n:3},{kind:'item',id:6,n:3}]
  };
  db.system.switches[0]='Boss Defeated'; db.system.switches[1]='Has Old Key'; db.system.switches[2]='Met Elder'; db.system.switches[3]='Ally Joined 2'; db.system.switches[4]='Ally Joined 3'; db.system.switches[5]='Ally Joined 4'; db.system.switches[6]='Golem Defeated';
  db.system.variables[0]='Quest Progress'; db.system.variables[1]='Temp';
  return db;
};
R.newProject = function(){ const db=R.defaultDB(); db.system.battleMode='action'; db.system.freeMove=true; db.maps=[]; db.mapTree=[]; db.version=1; db.created=Date.now(); return db; };
R.titleCfg = function(){ const t=(R.$db&&R.$db.system&&R.$db.system.titleScreen)||{}; return Object.assign({bg:'default',image:'',logo:'',c1:'#0b1030',c2:'#d9805a',showTitle:true,titleColor:'#ffe9a8',glow:'rgba(255,200,120,.8)',subColor:'#ffffff',titleSize:58,titleY:200,menuY:400,hint:true},t); };
R.byId = (list,id)=> list && list[id-1] || null;
})();
