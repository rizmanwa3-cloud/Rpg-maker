/* Scene_Map: jalannya peta, pesan, efek layar, transfer, battle dari event */
(function(){
'use strict';
const R = window.RPG, UI = R.UI, T = R.TILE, DX = R.DX, DY = R.DY;
const W=816,Hh=624;

R.SceneBase = class { constructor(){ this.t=0; this.co=null; } update(){ this.t++; if(this.co) this.co.step(); } draw(g){} };

function sliceVisible(s,n){ let out='',v=0; const re=/\\[CI]\[\d+\]|\\[{}.|!^]|\n|[\s\S]/g; let m; while((m=re.exec(s))){ const tok=m[0]; if(tok.length>1&&tok[0]==='\\'||tok==='\n'){ out+=tok; continue; } if(v>=n) break; out+=tok; v++; } return out; }
function visibleCount(s){ return s.replace(/\\[CI]\[\d+\]|\\[{}.|!^]|\n/g,'').length; }

R.Scene_Map = class extends R.SceneBase {
  constructor(){ super(); this.interp=new R.Interp(this); this.player=null; this.map=null; this.followers=[]; this.history=[]; this.co=null; this.par=new Map(); this.fadeA=0; this.fadeTarget=0; this.msg=null; this.lists={}; this.tint=[0,0,0,0]; this.tintT=null; this.flashT=null; this.shakeFx=null; this.particles=[]; this.mapAnims=[]; this.picMove=null; this.encCount=0; this.battle=null; this.numWin=null; this.scrollTxt=null; this.nameWin=null; this.mapName=null; this.mapNameT=0; this.abortEvents=false; this.transferring=false; this.battleFlash=0; this.curEv=null; this.touchPath=null; this.firstFrame=true; this.inEvent=false; }
  start(fromLoad){ const g=R.$game; this.setupMap(g.mapId,g.px,g.py,g.pdir,true); this.tint=g.tint.slice(); this.setWeather(); this.fadeA=1; this.fadeTarget=0; if(g.bgmName&&g.bgmName!=='None') R.Audio.playBgm(g.bgmName); else this.playMapBgm(); }
  playMapBgm(){ const b=this.map.data.bgm; if(b&&b!=='None'&&b!=='') { R.$game.bgmName=b; R.Audio.playBgm(b); } }
  setupMap(id,x,y,dir,first){ R.Action.reset(); const g=R.$game, db=R.$db; const md=db.maps.find(m=>m&&m.id===id)||db.maps[0]; g.mapId=md.id; this.map=new R.MapRT(md); const p=this.player||new R.Char(); this.player=p; p.isPlayerLike=true; const a=g.party[0]; p.img=a?a.img:{kind:'none'}; p.setPos(x,y); p.dir=dir||2; p.speed=4; p.through=false; p.transparent=g.transparent; p.prio=1; p.dashing=false; p.onStep=()=>this.onPlayerStep(); p.jump=null; p.moving=false; this.map.player=p; this.map.setupCamera(p,W,Hh); this.refreshFollowers(); this.par.clear(); this.encCount=this.newEncCount(); this.mapName=md.displayName||md.name; this.mapNameT=first?0:150; if(md.displayName===''||md.hideName) this.mapNameT=0; this.map.refresh(); }
  newEncCount(){ const n=this.map.data.encounterStep||30; return Math.floor(Math.random()*n)+Math.floor(Math.random()*n)+1; }
  refreshFollowers(){ const g=R.$game; this.followers=[]; if(g.followers){ g.party.slice(1).forEach((a,i)=>{ const f=new R.Char(); f.img=a.img; f.setPos(this.player.x,this.player.y); f.dir=this.player.dir; f.through=true; f.prio=1; f.speed=4; f.isFollower=true; f.actorId=a.id; this.followers.push(f); }); } this.history=[]; }
  afterTeleport(){ for(const f of this.followers){ f.setPos(this.player.x,this.player.y); f.dir=this.player.dir; } this.history=[]; this.map.centerOn(this.player.rx,this.player.ry); }
  getChar(t,ctx){ if(t===-1) return this.player; if(t===0) return ctx&&ctx.evt; return this.map.evById[t]||null; }
  /* ---- langkah pemain ---- */
  onPlayerStep(){ const g=R.$game, p=this.player; g.steps++; g.px=p.x; g.py=p.y; g.pdir=p.dir; if(this.map.damageAt(p.x,p.y)&&g.party.length){ for(const a of g.party.filter(a=>a.isAlive())){ a.gainHp(-Math.max(1,Math.round(a.mhp*.04))); if(a.hp<=0){ a.hp=1; a.states=a.states.filter(s=>s.id!==1); } } this.shakeFx={p:3,s:6,t:0,dur:10}; R.Audio.se('Hit',.5); }
    for(const e of this.map.eventsAt(p.x,p.y)){ if(e.trigger===1&&e.list&&!this.co&&e.prio!==1||e.trigger===1&&e.list&&!this.co&&e.x===p.x&&e.y===p.y){ this.startEvent(e); return; } }
    // encounter
    if(!this.co&&g.flags.encounter&&R.$db.system.encounterEnabled&&!R.Action.isOn()&&(this.map.data.encounters||[]).length&&!p.through){ this.encCount--; if(this.encCount<=0){ this.encCount=this.newEncCount(); this.startRandomBattle(); } } }
  startRandomBattle(){ const en=this.map.data.encounters; const tot=en.reduce((s,e)=>s+(e.weight||1),0); let r=Math.random()*tot, pick=en[0]; for(const e of en){ r-=(e.weight||1); if(r<=0){ pick=e; break; } } const sc=this; this.co=new R.Co((function*(){ sc.inEvent=true; const res=yield* sc.startBattle(pick.troop,{escape:true}); if(res===2) yield* sc.gameOver(); sc.inEvent=false; })()); }
  /* ---- event ---- */
  startEvent(ev,faceIt){ if(!ev||!ev.list||this.co) return; ev.running=true; this.curEv=ev; if(ev.trigger===0||ev.trigger===2||ev.trigger===1){ if(!ev.dirFix&&ev.img.kind!=='none'&&ev.img.kind!=='tile'&&faceIt!==false){ const d={2:8,4:6,6:4,8:2}; const px=this.player.x-ev.x, py=this.player.y-ev.y; if(px!==0||py!==0){ if(Math.abs(px)>Math.abs(py)) ev.dir=px>0?6:4; else ev.dir=py>0?2:8; } } }
    this.inEvent=true; const sc=this; this.co=new R.Co((function*(){ ev.stopRoute&&0; yield* sc.interp.run(ev.list,{evt:ev,eventId:ev.id}); ev.running=false; sc.curEv=null; sc.inEvent=false; sc.map.needRefresh=true; })()); }
  checkAction(){ const p=this.player; const fx=p.x+DX[p.dir], fy=p.y+DY[p.dir]; for(const e of this.map.eventsAt(p.x,p.y)){ if(e.trigger===0&&e.prio!==1&&e.list){ this.startEvent(e); return true; } } for(const e of this.map.eventsAt(fx,fy)){ if(e.trigger===0&&e.list&&e.prio===1){ this.startEvent(e); return true; } } for(const e of this.map.eventsAt(fx,fy)){ if(e.trigger===0&&e.list){ this.startEvent(e); return true; } } const f2x=fx+DX[p.dir], f2y=fy+DY[p.dir]; if(this.map.valid(fx,fy)){ const t=this.map.tilesAt(fx,fy); if(t.some(id=>id&&R.TILES[id-1]&&R.TILES[id-1].counter)){ for(const e of this.map.eventsAt(f2x,f2y)){ if(e.trigger===0&&e.list){ this.startEvent(e); return true; } } } } return false; }
  tryMove(d){ const p=this.player, m=this.map; if(!p.dirFix) p.dir=d; const nx=p.x+DX[d], ny=p.y+DY[d];
    if(p.canPass(p.x,p.y,d,m)){ const ox=p.x, oy=p.y; p.moveStraight(d,m,true); this.history.unshift({x:ox,y:oy,dir:d}); if(this.history.length>8) this.history.pop(); this.followers.forEach((f,i)=>{ const h=this.history[i]; if(h){ f.dir=h.dir; f.speed=p.speed+(p.dashing?1:0); f.dashing=false; f.x=h.x; f.y=h.y; f.moving=true; f.walkAnim=true; } }); p.dashing=R.Input.isDown('shift')&&R.$db.system.dashEnabled&&!m.data.disableDash; if(p.dashing) p.speed=5; else p.speed=4; }
    else { for(const e of m.eventsAt(nx,ny)){ if((e.trigger===1||e.trigger===2)&&e.list&&e.prio===1){ this.startEvent(e); return; } } if(m.valid(nx,ny)&&!this.bumped&&false){} } }
  /* ---- update ---- */
  update(){ super.update(); const g=R.$game, I=R.Input; g.frames++; this.updateFx();
    if(this.battle){ this.battle.update(); return; }
    this.map.update(); this.player.update(this.map); for(const f of this.followers) f.update(this.map); this.map.centerOn(this.player.rx,this.player.ry);
    if(!this.transferring) R.Action.update(this);
    if(this.mapNameT>0) this.mapNameT--;
    // parallel & autorun
    if(!this.transferring){ for(const e of this.map.events){ if(!e.page||e.erased||!e.list) continue; if(e.trigger===4){ let c=this.par.get(e); if(!c||c.list!==e.list){ c={list:e.list,co:new R.Co(this.interp.run(e.list,{evt:e,eventId:e.id,parallel:true}))}; this.par.set(e,c); } c.co.step(); if(c.co.done){ c.co=new R.Co(this.interp.run(e.list,{evt:e,eventId:e.id,parallel:true})); } } } for(const [e,c] of this.par){ if(!e.page||e.trigger!==4||e.erased) this.par.delete(e); } }
    if(this.co){ if(this.co.done){ this.co=null; this.inEvent=false; } else return; }
    if(this.transferring) return;
    if(!this.co){ for(const e of this.map.events){ if(e.page&&!e.erased&&e.trigger===3&&e.list&&!e.running){ this.startEvent(e,false); return; } } }
    if(this.co) return;
    // input
    const p=this.player; if(R.Action.isOn()||this.map.events.some(e=>e.mob)) R.Action.input(this,I); if(!p.isMoving()){ p.dashing=I.isDown('shift')&&R.$db.system.dashEnabled&&!this.map.data.disableDash; let d=I.dir4(); if(!d&&I.mouse.down&&I.mouse.moved===false&&this.touchTarget) d=this.touchDir(); if(d) this.tryMove(d); if(I.pressed('ok')&&!p.isMoving()){ if(this.checkAction()) return; }
      if((I.pressed('cancel')||I.pressed('menu'))&&!p.isMoving()&&g.flags.menu){ R.Audio.se('OK'); R.SM.push(new R.Scene_Menu()); } }
    else if(I.pressed('ok')&&false){} }
  touchDir(){ return 0; }
  /* ---- efek ---- */
  updateFx(){ const g=R.$game; if(this.fadeA!==this.fadeTarget){ const d=1/24; this.fadeA+=Math.sign(this.fadeTarget-this.fadeA)*Math.min(d,Math.abs(this.fadeTarget-this.fadeA)); }
    if(this.tintT){ const t=this.tintT; t.t++; const k=Math.min(1,t.t/t.dur); this.tint=t.from.map((v,i)=>v+(t.to[i]-v)*k); if(k>=1) this.tintT=null; g.tint=this.tint.slice(); }
    if(this.flashT){ this.flashT.t++; if(this.flashT.t>=this.flashT.dur) this.flashT=null; } if(this.shakeFx){ this.shakeFx.t++; if(this.shakeFx.t>=this.shakeFx.dur) this.shakeFx=null; }
    if(this.picMove){ const m=this.picMove, p=g.pictures[m.id]; if(!p){ this.picMove=null; } else { m.t++; const k=Math.min(1,m.t/m.dur); for(const key of ['x','y','scale','opacity']) p[key]=m.from[key]+(m.to[key]-m.from[key])*k; if(k>=1) this.picMove=null; } }
    this.mapAnims.forEach(a=>a.t++); this.mapAnims=this.mapAnims.filter(a=>a.t<a.dur);
    const w=g.weather; if(w.type!=='none'){ const n=w.power*5; while(this.particles.length<n&&Math.random()<.5){ this.particles.push(this.newParticle(w.type)); } for(const p of this.particles){ p.x+=p.vx; p.y+=p.vy; p.life--; if(w.type==='snow') p.x+=Math.sin((p.life+p.s)/12)*.6; } this.particles=this.particles.filter(p=>p.y<Hh+20&&p.x>-30&&p.x<W+30); if(w.type==='storm'&&Math.random()<.004) this.flashT={color:'#ffffff',t:0,dur:12,a:.6}; } else if(this.particles.length) this.particles=[]; }
  newParticle(type){ if(type==='snow') return {x:Math.random()*W,y:-10,vx:-.6,vy:1.5+Math.random()*1.5,life:1000,s:Math.random()*20,type:'snow'}; const sp=type==='storm'?18:13; return {x:Math.random()*(W+200),y:-20,vx:-sp*.3,vy:sp,life:1000,s:0,type:'rain'}; }
  setWeather(){ this.particles=[]; }
  tintTo(to,frames){ this.tintT={from:this.tint.slice(),to:to,t:0,dur:Math.max(1,frames)}; }
  addAnim(ch,name){ this.mapAnims.push({ch:ch,name:name,t:0,dur:30}); }
  *fade(to,frames){ this.fadeTarget=to; while(Math.abs(this.fadeA-to)>.001) yield; }
  *transfer(mapId,x,y,dir,fade){ this.transferring=true; const g=R.$game; if(fade!=='none'){ this.fadeColor=fade==='white'?'#fff':'#000'; yield* this.fade(1,24); } const prevBgm=this.map.data.bgm; this.setupMap(mapId,x,y,dir||this.player.dir); this.afterTeleport(); const nb=this.map.data.bgm; if(nb&&nb!=='None'&&nb!==prevBgm) this.playMapBgm(); else if(nb==='None'&&prevBgm!=='None'){ R.Audio.stopBgm(); } this.transferring=false; yield 6; if(fade!=='none') yield* this.fade(0,24); this.fadeColor='#000'; }
  *startBattle(troopId,opts){ const g=R.$game; this.battleFlash=1; for(let i=0;i<20;i++){ this.battleFlash=i/20; yield; } let res=-1; const prevBgm=R.Audio.bgmName; this.battle=new R.Scene_Battle(troopId,{escape:opts.escape,lose:opts.lose,onEnd:r=>{ res=r; }}); this.battle.start(); while(res<0) yield; this.battle=null; this.battleFlash=0; R.Audio.stopBgm(); if(res!==2||opts.lose){ if(prevBgm&&prevBgm!=='None') R.Audio.playBgm(prevBgm); } this.map.needRefresh=true; this.fadeA=0; return res; }
  *gameOver(){ this.abortEvents=true; R.Audio.stopBgm(); R.SM.goto(new R.Scene_GameOver()); while(true) yield; }
  toTitle(){ this.abortEvents=true; R.Audio.stopBgm(); R.SM.goto(new R.Scene_Title()); }
  *openMenuScene(){ R.SM.push(new R.Scene_Menu()); yield 2; while(R.SM.top()!==this) yield; }
  *openSaveScene(){ R.SM.push(new R.Scene_Save('save')); yield 2; while(R.SM.top()!==this) yield; }
  *openShop(goods,buyOnly){ R.SM.push(new R.Scene_Shop(goods,buyOnly)); yield 2; while(R.SM.top()!==this) yield; }
  /* ---- pesan ---- */
  *showText(c){ const sys=R.$db.system; const full=UI.expand(c.text||''); const lines=full.split('\n'); const pages=[]; for(let i=0;i<lines.length;i+=4) pages.push(lines.slice(i,i+4).join('\n')); if(!pages.length) pages.push('');
    for(const pg of pages){ const face=c.face?(typeof c.face==='string'? R.imgOfName(c.face):c.face):null; this.msg={text:pg,pos:c.pos||'bottom',bg:c.bg||'window',face:face,n:0,total:visibleCount(pg),wait:false,t:0}; const m=this.msg; while(true){ m.t++; const speed=Math.max(1,sys.textSpeed||2); if(m.n<m.total){ m.n+=speed*(R.Input.isDown('ok')?3:1)*.6+.4; if(R.Input.pressed('ok')||R.Input.pressed('cancel')||R.Input.clicked()){ m.n=m.total; R.Input.flush(); } if(Math.floor(m.n)%3===0&&Math.floor(m.n)>0&&!m.snd){ } } else { m.wait=true; if(R.Input.pressed('ok')||R.Input.pressed('cancel')||R.Input.clicked()){ R.Audio.se('Cursor'); break; } } yield; } this.msg=null; R.Input.flush(); yield 1; } }
  *showChoices(c){ const n=(c.opts||[]).length; const maxW=Math.max(...(c.opts||['']).map(o=>UI.measure(R._g,UI.stripCodes(o))))+60; const w=Math.max(160,Math.min(560,maxW)); const h=Math.min(n,6)*40+28; const msgUp=!!this.msg; let x=c.pos==='left'?8:c.pos==='middle'?(W-w)/2:W-w-8; let y=(this.msg&&this.msg.pos==='top')?220: (this.msg? 624-190-h-8 : (Hh-h)/2);
    if(!this.msg&&c.pos!=='middle') y=Hh-h-210;
    const L=new UI.List({x:x,y:Math.max(8,y),w:w,h:h,items:c.opts.map(o=>UI.expand(o)),rowH:40,cancelable:c.cancel!==0,index:0,draw:(g,s,i,r)=>{ UI.rich(g,s,r.x+6,r.y+r.h/2,r.w-12,{wrap:false}); }}); this.lists.choice=L; const had=this.msg; if(had){ had.hold=true; }
    while(true){ const r=L.update(); if(r==='ok'){ delete this.lists.choice; R.Input.flush(); return L.index; } if(r==='cancel'){ delete this.lists.choice; R.Input.flush(); return -1; } yield; } }
  *numInput(c){ const digits=c.digits||3; let arr=new Array(digits).fill(0), idx=0; const cur=Math.max(0,R.$game.v(c.v)); String(cur).padStart(digits,'0').slice(-digits).split('').forEach((ch,i)=>arr[i]=+ch); this.numWin={arr:arr,idx:()=>idx}; const I=R.Input;
    while(true){ if(I.repeat('up')){ arr[idx]=(arr[idx]+1)%10; R.Audio.se('Cursor'); } if(I.repeat('down')){ arr[idx]=(arr[idx]+9)%10; R.Audio.se('Cursor'); } if(I.repeat('right')){ idx=(idx+1)%digits; } if(I.repeat('left')){ idx=(idx+digits-1)%digits; } if(I.pressed('ok')){ R.Audio.se('OK'); break; } yield; } R.$game.setV(c.v,parseInt(arr.join(''),10)); this.numWin=null; I.flush(); }
  *selectKeyItem(c){ const g=R.$game, db=R.$db; const ids=Object.keys(g.items).map(Number).filter(id=>db.items[id-1]&&db.items[id-1].key); if(!ids.length){ g.setV(c.v,0); return; } const L=new UI.List({x:W/2-220,y:60,w:440,h:Math.min(ids.length,7)*38+28,items:ids,rowH:38,cancelable:true,draw:(g2,id,i,r)=>{ const it=db.items[id-1]; R.drawIcon(g2,it.icon,r.x,r.y+3,28); UI.text(g2,it.name,r.x+34,r.y+r.h/2,{maxW:r.w-50}); }}); this.lists.choice=L; while(true){ const r=L.update(); if(r==='ok'){ g.setV(c.v,L.items[L.index]); break; } if(r==='cancel'){ g.setV(c.v,0); break; } yield; } delete this.lists.choice; R.Input.flush(); }
  *scrollText(c){ const lines=UI.expand(c.text||'').split('\n'); this.scrollTxt={lines:lines,y:Hh+10}; const sp=(c.speed||2)*.6; while(this.scrollTxt.y>-lines.length*40-10){ this.scrollTxt.y-=sp*(R.Input.isDown('ok')?3:1); yield; } this.scrollTxt=null; }
  *nameInput(c){ const a=R.$game.actor(c.actor); R.SM.push(new R.Scene_NameInput(a,c.max||8)); yield 2; while(R.SM.top()!==this) yield; }
  /* ---- draw ---- */
  draw(g){ if(this.battle){ g.fillStyle='#000'; g.fillRect(0,0,W,Hh); this.battle.draw(g); return; } R._g=g; const sx=this.shakeFx? Math.sin(this.shakeFx.t*this.shakeFx.s*.4)*this.shakeFx.p*3 : 0;
    this.map.draw(g,W,Hh,this.player,this.followers,sx);
    // anim
    const x0=Math.floor(this.map.dispX), y0=Math.floor(this.map.dispY), ox=-(this.map.dispX-x0)*T+sx, oy=-(this.map.dispY-y0)*T; for(const a of this.mapAnims){ const p=this.map.charScreen(a.ch,ox,oy,x0,y0); R.drawAnim(g,a.name,p.x+24,p.y+10,a.t/a.dur); }
    R.Action.draw(g,this,ox,oy,x0,y0);
    // tint
    const tn=this.tint; if(tn[0]||tn[1]||tn[2]||tn[3]){ g.save(); const neg=[Math.min(0,tn[0]),Math.min(0,tn[1]),Math.min(0,tn[2])]; if(neg[0]||neg[1]||neg[2]){ g.globalCompositeOperation='multiply'; g.fillStyle='rgb('+(255+neg[0])+','+(255+neg[1])+','+(255+neg[2])+')'; g.fillRect(0,0,W,Hh); } const pos=[Math.max(0,tn[0]),Math.max(0,tn[1]),Math.max(0,tn[2])]; if(pos[0]||pos[1]||pos[2]){ g.globalCompositeOperation='lighter'; g.fillStyle='rgb('+pos[0]+','+pos[1]+','+pos[2]+')'; g.fillRect(0,0,W,Hh); } if(tn[3]){ g.globalCompositeOperation='saturation'; g.globalAlpha=Math.min(1,tn[3]/255); g.fillStyle='#808080'; g.fillRect(0,0,W,Hh); } g.restore(); }
    // weather
    if(this.particles.length){ g.save(); const w=R.$game.weather.type; if(w==='storm'){ g.fillStyle='rgba(20,20,50,.28)'; g.fillRect(0,0,W,Hh); } for(const p of this.particles){ if(p.type==='snow'){ g.fillStyle='rgba(255,255,255,.9)'; g.beginPath(); g.arc(p.x,p.y,2.4,0,6.3); g.fill(); } else { g.strokeStyle='rgba(180,200,255,.6)'; g.lineWidth=1.5; g.beginPath(); g.moveTo(p.x,p.y); g.lineTo(p.x+p.vx*1.2,p.y+p.vy*1.2); g.stroke(); } } g.restore(); }
    // pictures
    const pics=R.$game.pictures; for(const id of Object.keys(pics).sort((a,b)=>a-b)){ const p=pics[id]; const im=R.loadImage('img/pictures/'+p.name+'.png'); if(im){ g.save(); g.globalAlpha=p.opacity/255; const sc=p.scale/100; g.drawImage(im,p.x,p.y,im.width*sc,im.height*sc); g.restore(); } }
    if(this.flashT){ const f=this.flashT; g.save(); g.globalAlpha=(f.a||1)*(1-f.t/f.dur); g.fillStyle=f.color; g.fillRect(0,0,W,Hh); g.restore(); }
    if(this.battleFlash>0){ g.fillStyle='rgba(255,255,255,'+this.battleFlash+')'; g.fillRect(0,0,W,Hh); }
    { const t=this.letterbox?1:0; this.lbA=(this.lbA||0)+(t-(this.lbA||0))*.12; if(this.lbA>.01){ const h=Math.round(78*this.lbA); g.fillStyle='#000'; g.fillRect(0,0,W,h); g.fillRect(0,Hh-h,W,h); } }
    if(!this.inScene) R.Action.hud(g,this);
    // nama peta
    if(this.mapNameT>0&&this.mapName){ const a=Math.min(1,this.mapNameT/30,(150-this.mapNameT)/20); g.save(); g.globalAlpha=Math.max(0,a); UI.win(g,W/2-190,16,380,52); UI.text(g,this.mapName,W/2,43,{align:'center',size:24}); g.restore(); }
    if(this.scrollTxt){ g.fillStyle='rgba(0,0,0,.75)'; g.fillRect(0,0,W,Hh); this.scrollTxt.lines.forEach((l,i)=>UI.rich(g,l,40,this.scrollTxt.y+i*40,W-80,{lh:40})); }
    // message
    const m=this.msg; if(m){ const h=180,w=W-16; const y=m.pos==='top'?8:m.pos==='middle'?(Hh-h)/2:Hh-h-8; if(m.bg==='window') UI.win(g,8,y,w,h); else if(m.bg==='dim'){ g.fillStyle='rgba(0,0,0,.5)'; g.fillRect(8,y,w,h); } let tx=28; if(m.face){ const fc=R.faceCanvas(m.face,144); if(fc){ g.drawImage(fc,22,y+18,144,144); tx=190; } } UI.rich(g,sliceVisible(m.text,Math.floor(m.n)),tx,y+36,w-tx-20,{lh:34}); if(m.wait&&!this.lists.choice&&Math.floor(m.t/20)%2) { g.fillStyle='#fff'; g.beginPath(); g.moveTo(W/2-10,y+h-26); g.lineTo(W/2+10,y+h-26); g.lineTo(W/2,y+h-14); g.fill(); } }
    if(this.lists.choice) this.lists.choice.draw(g);
    if(this.numWin){ const nw=this.numWin; const w=nw.arr.length*44+40; UI.win(g,W/2-w/2,Hh-300,w,88); nw.arr.forEach((d,i)=>{ if(i===nw.idx()) UI.cursor(g,W/2-w/2+20+i*44,Hh-292,40,72,this.t); UI.text(g,String(d),W/2-w/2+40+i*44,Hh-256,{align:'center',size:36}); }); }
    if(this.fadeA>0){ g.fillStyle=this.fadeColor||'#000'; g.globalAlpha=this.fadeA; g.fillRect(0,0,W,Hh); g.globalAlpha=1; }
  }
};
})();
