/* Scene title, menu, item, skill, equip, status, formation, save/load, shop, name input, game over */
(function(){
'use strict';
const R = window.RPG, UI = R.UI, H = R.H;
const W=816,Hh=624;
const B = R.SceneBase;
B.prototype.pick = function*(L){ L.active=true; R.Input.flush(); yield; while(true){ const r=L.update(); if(r==='ok') return L.index; if(r==='cancel') return -1; yield; } };
B.prototype.sub = function*(scene){ R.SM.push(scene); yield 2; while(R.SM.top()!==this) yield; R.Input.flush(); };
const bgMenu=(g,t)=>{ const gr=g.createLinearGradient(0,0,0,Hh); gr.addColorStop(0,'#14204a'); gr.addColorStop(1,'#0a0f26'); g.fillStyle=gr; g.fillRect(0,0,W,Hh); g.fillStyle='rgba(120,160,255,.06)'; for(let i=0;i<8;i++){ g.beginPath(); g.arc(100+i*110,100+Math.sin((t||0)/90+i)*30+(i%3)*160,70+i*6,0,6.3); g.fill(); } };
R.bgMenu = bgMenu;

/* ---- penyimpanan ---- */
const Save = R.Save = { mem:{}, key(slot){ return 'rpgs_'+(R.$db.system.title||'game').replace(/\W/g,'_')+'_'+slot; },
  get(slot){ try{ const s=localStorage.getItem(Save.key(slot)); if(s) return JSON.parse(s); }catch(e){} const m=Save.mem[Save.key(slot)]; return m?JSON.parse(m):null; },
  set(slot,obj){ const s=JSON.stringify(obj); try{ localStorage.setItem(Save.key(slot),s); }catch(e){ Save.mem[Save.key(slot)]=s; } },
  any(){ for(let i=1;i<=10;i++) if(Save.get(i)) return true; return false; } };
Save.write = function(slot){ const g=R.$game; g.px=R.$scene.player? R.$scene.player.x:g.px; g.py=R.$scene.player? R.$scene.player.y:g.py; g.pdir=R.$scene.player?R.$scene.player.dir:g.pdir; Save.set(slot,{game:g.save(),time:Date.now(),title:R.$db.system.title,map:g.mapId}); };
R.fmtTime = f=>{ const s=Math.floor(f/60); return String(Math.floor(s/3600)).padStart(2,'0')+':'+String(Math.floor(s/60)%60).padStart(2,'0')+':'+String(s%60).padStart(2,'0'); };

/* ---- helper gambar ---- */
function drawActorCard(g,a,x,y,w,h,opt){ opt=opt||{}; const fc=R.faceCanvas(a.img,96); if(fc){ g.drawImage(fc,x+6,y+6,h-12,h-12); } const tx=x+h; UI.text(g,a.name,tx,y+22,{size:22}); UI.text(g,(R.$db.system.terms.level)+' '+a.level,tx+150,y+22,{size:18,color:'#9cf'}); const cl=R.$db.classes[a.cls-1]; if(cl) UI.text(g,cl.name,tx+210,y+22,{size:16,color:'#cdd',maxW:90}); let sx=tx+Math.min(w-h-100,300); a.states.slice(0,3).forEach(s=>{ R.drawIcon(g,R.$db.states[s.id-1].icon,sx,y+8,24); sx+=26; });
  UI.text(g,'HP',tx,y+50,{size:15,color:'#8cf'}); UI.gauge(g,tx+28,y+44,Math.max(60,w-h-40),12,a.hp/a.mhp,'#e8433f','#f5a33a'); UI.text(g,a.hp+'/'+a.mhp,tx+w-h-6,y+50,{size:15,align:'right'}); if(h>=96){ UI.text(g,'MP',tx,y+72,{size:15,color:'#8cf'}); UI.gauge(g,tx+28,y+66,Math.max(60,w-h-40),12,a.mmp?a.mp/a.mmp:0,'#3a7fe8','#6ad0ff'); UI.text(g,a.mp+'/'+a.mmp,tx+w-h-6,y+72,{size:15,align:'right'}); } }
R.drawActorCard=drawActorCard;
function partyList(x,y,w,h,rowH,cols){ const g=R.$game; return new UI.List({x:x,y:y,w:w,h:h,items:g.party,rowH:rowH,cols:cols||1,draw:(c,a,i,r)=>drawActorCard(c,a,r.x-4,r.y,r.w+8,r.h)}); }
R.partyList=partyList;

/* ---- Title ---- */
R.Scene_Title = class extends B {
  constructor(){ super(); this.stars=Array.from({length:60},()=>({x:Math.random()*W,y:Math.random()*300,s:Math.random()*2+.5,p:Math.random()*6})); }
  start(){ R.Audio.playBgm(R.$db.system.titleBgm); const T=R.$db.system.terms; this.opts=[T.newGame,T.continue,T.options,T.shutdown]; this.L=new UI.List({x:W/2-130,y:R.titleCfg().menuY,w:260,h:4*44+36,items:this.opts,rowH:44,cancelable:false,enabled:(o,i)=>i!==1||Save.any()}); this.co=new R.Co(this.main()); R.Input.flush(); }
  *main(){ while(true){ const i=yield* this.pick(this.L); if(i===0){ R.Audio.stopBgm(); R.$game=new R.Game(); R.$game.setupNew(); R.SM.goto(R.$scene=new R.Scene_Map()); R.$scene.start(); { const is=R.$db.system.introScene; if(is&&R.$db.scenes&&R.$db.scenes[is-1]) R.Action.runScene(is); } return; } if(i===1){ yield* this.sub(new R.Scene_Save('load')); } if(i===2){ yield* this.sub(new R.Scene_Options()); } if(i===3){ try{ window.close(); }catch(e){} } } }
  draw(g){ const cfg=R.titleCfg(); const sys=R.$db.system;
    if(cfg.bg==='image'&&R.loadImage(cfg.image)){ const im=R.loadImage(cfg.image); g.fillStyle='#000'; g.fillRect(0,0,W,Hh); g.drawImage(im,0,0,W,Hh); }
    else if(cfg.bg==='gradient'||cfg.bg==='image'){ const gr=g.createLinearGradient(0,0,0,Hh); gr.addColorStop(0,cfg.c1); gr.addColorStop(1,cfg.c2); g.fillStyle=gr; g.fillRect(0,0,W,Hh); }
    else { const gr=g.createLinearGradient(0,0,0,Hh); gr.addColorStop(0,'#0b1030'); gr.addColorStop(.55,'#3a2a6a'); gr.addColorStop(1,'#d9805a'); g.fillStyle=gr; g.fillRect(0,0,W,Hh); for(const s of this.stars){ g.fillStyle='rgba(255,255,255,'+(.5+.5*Math.sin(this.t/30+s.p))+')'; g.fillRect(s.x,s.y,s.s,s.s); } H.circ(g,'rgba(255,240,200,.9)',620,170,46); H.poly(g,'#1a1438',0,520,150,360,300,520); H.poly(g,'#241a4a',200,540,420,330,640,540); H.poly(g,'#1a1438',500,540,700,380,816,540); g.fillStyle='#0f0c24'; g.fillRect(0,520,W,104); H.poly(g,'#0f0c24',0,520,60,500,130,520,200,490,300,520,816,520,816,624,0,624); }
    const logo=cfg.logo?R.loadImage(cfg.logo):null;
    if(logo){ const sc=Math.min(1,(W-80)/logo.width); g.drawImage(logo,(W-logo.width*sc)/2,cfg.titleY-logo.height*sc/2,logo.width*sc,logo.height*sc); }
    else if(cfg.showTitle){ g.save(); g.shadowColor=cfg.glow; g.shadowBlur=24; UI.text(g,sys.title,W/2,cfg.titleY,{size:cfg.titleSize,align:'center',color:cfg.titleColor}); g.restore(); if(sys.subtitle) UI.text(g,sys.subtitle,W/2,cfg.titleY+cfg.titleSize*.9,{size:Math.max(14,cfg.titleSize*.42),align:'center',color:cfg.subColor}); }
    this.L.draw(g); if(cfg.hint) UI.text(g,'Z / Enter: OK    X / Esc: Cancel    Arrow keys / WASD',W/2,Hh-18,{size:14,align:'center',color:'#bcd',bold:false}); }
};

/* ---- Options ---- */
R.Scene_Options = class extends B {
  start(){ this.items=['BGM Volume','SE Volume','Fullscreen (F11)','Controls (Keybinds)']; this.L=new UI.List({x:W/2-260,y:200,w:520,h:4*44+28,items:this.items,rowH:44,draw:(g,s,i,r)=>{ UI.text(g,s,r.x+6,r.y+r.h/2); if(i<2){ const v=i===0?R.Audio.vol.bgm/.5:R.Audio.vol.se/.7; UI.gauge(g,r.x+230,r.y+14,200,10,v,'#6ad0ff','#3a7fe8'); UI.text(g,Math.round(v*100)+'%',r.x+r.w-8,r.y+r.h/2,{align:'right'}); } }}); this.co=new R.Co(this.main()); }
  *main(){ const I=R.Input; while(true){ const r=this.L.update(); if(r==='cancel'){ R.SM.pop(); return; } const i=this.L.index; if(i<2&&(I.repeat('left')||I.repeat('right'))){ const d=I.repeat('right')?.1:-.1; if(i===0){ R.Audio.vol.bgm=Math.max(0,Math.min(.5,R.Audio.vol.bgm+d*.5)); } else { R.Audio.vol.se=Math.max(0,Math.min(.7,R.Audio.vol.se+d*.7)); R.Audio.se('Cursor'); } } if(i===2&&r==='ok'&&R.onF11) R.onF11(); if(i===3&&r==='ok'){ R.SM.push(new R.Scene_Keys()); yield 2; while(R.SM.top()!==this) yield; R.Input.flush(); } yield; } }
  draw(g){ bgMenu(g,this.t); UI.text(g,'Options',W/2,150,{size:34,align:'center'}); this.L.draw(g); }
};

/* ---- Menu utama ---- */
R.Scene_Menu = class extends B {
  start(){ const T=R.$db.system.terms; this.cmds=[T.item,T.skill,T.equip,T.status,T.formation,T.save,T.gameEnd]; this.L=new UI.List({x:8,y:8,w:230,h:7*44+28,items:this.cmds,rowH:44,enabled:(c,i)=>i!==5||R.$game.flags.save,cancelable:true}); this.P=partyList(246,8,562,Hh-16,120); this.P.active=false; this.mode='cmd'; this.co=new R.Co(this.main()); R.Input.flush(); }
  *main(){ const g=R.$game; while(true){ const i=yield* this.pick(this.L); if(i<0){ R.SM.pop(); return; }
      if(i===0){ yield* this.sub(new R.Scene_Item()); }
      else if(i===5){ yield* this.sub(new R.Scene_Save('save')); }
      else if(i===6){ const E=new UI.List({x:8,y:330,w:230,h:2*44+28,items:['To Title','Cancel'],rowH:44}); this.extra=E; const k=yield* this.pick(E); this.extra=null; if(k===0){ R.Audio.stopBgm(); R.SM.goto(new R.Scene_Title()); return; } }
      else { this.P.active=true; this.L.active=false; let sel; while(true){ sel=yield* this.pick(this.P); if(sel<0) break; const a=g.party[sel]; if(i===1) yield* this.sub(new R.Scene_Skill(a)); else if(i===2) yield* this.sub(new R.Scene_Equip(a,sel)); else if(i===3) yield* this.sub(new R.Scene_Status(a,sel)); else if(i===4){ if(this.fSel===undefined){ this.fSel=sel; } else { const b=this.fSel; this.fSel=undefined; if(b!==sel&&g.party[b]&&g.party[sel]){ const t=g.party[b]; g.party[b]=g.party[sel]; g.party[sel]=t; R.$scene.refreshFollowers(); R.$scene.player.img=g.party[0].img; R.Audio.se('OK'); } } } if(i!==4) break; }
        this.fSel=undefined; this.P.active=false; this.L.active=true; } } }
  draw(g){ bgMenu(g,this.t); this.L.draw(g); this.P.draw(g); if(this.fSel!==undefined){ const r=this.P.itemRect(this.fSel); g.strokeStyle='#ffe27a'; g.lineWidth=3; g.strokeRect(r.x-6,r.y,r.w+8,r.h); } const gd=R.$game; UI.win(g,8,Hh-150,230,142); UI.text(g,'Gold',22,Hh-122,{size:18,color:'#8cf'}); UI.text(g,gd.gold+' '+R.$db.system.currency,226,Hh-92,{align:'right',size:26,color:'#ffe27a'}); UI.text(g,'Time',22,Hh-56,{size:18,color:'#8cf'}); UI.text(g,R.fmtTime(gd.frames),226,Hh-28,{align:'right',size:22}); if(this.extra) this.extra.draw(g); }
};

/* ---- Item ---- */
R.Scene_Item = class extends B {
  start(){ this.cats=['Item','Weapon','Armor','Key Item']; this.C=new UI.List({x:8,y:8,w:W-16,h:60,items:this.cats,cols:4,rowH:40,pad:10}); this.I=new UI.List({x:8,y:76,w:W-16,h:Hh-76-96,items:[],cols:2,rowH:38,draw:(g,e,i,r)=>{ R.drawIcon(g,e.d.icon,r.x,r.y+3,28); UI.text(g,e.d.name,r.x+34,r.y+r.h/2,{maxW:r.w-110}); UI.text(g,'x'+e.n,r.x+r.w-6,r.y+r.h/2,{align:'right',size:20}); },enabled:e=>this.usable(e)}); this.I.active=false; this.co=new R.Co(this.main()); }
  usable(e){ if(!e||e.kind!=='item') return false; return (e.d.occasion===0||e.d.occasion===2) && e.d.scope!==0; }
  items(cat){ const g=R.$game, db=R.$db; const out=[]; const tbl=cat===0||cat===3?g.items:cat===1?g.weapons:g.armors; const lst=cat<=0||cat===3?db.items:cat===1?db.weapons:db.armors; for(const id of Object.keys(tbl).map(Number).sort((a,b)=>a-b)){ const d=lst[id-1]; if(!d) continue; if(cat===0&&d.key) continue; if(cat===3&&!d.key) continue; out.push({kind:cat===1?'weapon':cat===2?'armor':'item',id:id,d:d,n:tbl[id]}); } return out; }
  *main(){ while(true){ const c=yield* this.pick(this.C); if(c<0){ R.SM.pop(); return; } this.cat=c; this.I.set(this.items(c)); this.I.index=0; this.I.top=0; this.C.active=false;
      while(true){ const i=yield* this.pick(this.I); if(i<0) break; const e=this.I.items[i]; if(!this.usable(e)) continue; const d=e.d; const P=partyList(8,76,W-16,Hh-76-96,100,2); P.active=true; this.P=P; let tgs=null; if(d.scope===4||d.scope===2){ tgs=R.$game.party.slice(); /* all */ if(d.scope===2){ this.P=null; continue; } this.allT=true; yield* this.pickAll(P); }
        let k; if(!this.allT){ k=yield* this.pick(P); } else k=0; if(k<0||(k!==0&&false)){ this.P=null; this.allT=false; continue; }
        const used=this.apply(d,e,this.allT?R.$game.party:[R.$game.party[k]]); this.P=null; this.allT=false; if(used){ if(d.consumable) R.$game.gainItem('item',e.id,-1); R.Audio.se('Heal'); this.I.set(this.items(this.cat)); if(!this.I.items.length) break; } else R.Audio.se('Buzzer'); }
      this.C.active=true; } }
  *pickAll(P){ P.active=false; this.hlAll=true; R.Input.flush(); yield; while(true){ if(R.Input.pressed('ok')){ R.Audio.se('OK'); break; } if(R.Input.pressed('cancel')){ break; } yield; } this.hlAll=false; }
  apply(d,e,targets){ let any=false; const user=R.$game.party[0]; for(const t of targets){ if(d.type==='revive'?!t.isDead():(t.isDead())) continue; const r=R.useOn(user,t,d,true,{noEvade:true}); if(!r.fail&&(r.hp!==0||r.mp!==0||r.added.length||r.removed.length||r.revived)) any=true; } return any; }
  draw(g){ bgMenu(g,this.t); this.C.draw(g); if(this.P) this.P.draw(g); else this.I.draw(g); const e=this.I.items[this.I.index]; UI.win(g,8,Hh-88,W-16,80); if(e&&!this.P) UI.text(g,e.d.desc||'',28,Hh-48,{size:20,maxW:W-60}); const gd=R.$game; UI.text(g,'Gold '+gd.gold+' '+R.$db.system.currency,W-24,Hh-48,{align:'right',color:'#ffe27a',size:18}); }
};

/* ---- Skill ---- */
R.Scene_Skill = class extends B {
  constructor(a){ super(); this.a=a; }
  start(){ const a=this.a, db=R.$db; const ids=a.skills.filter(id=>{ const s=db.skills[id-1]; return s&&id!==1&&id!==2; }); this.L=new UI.List({x:8,y:140,w:W-16,h:Hh-140-96,items:ids,cols:2,rowH:38,enabled:id=>{ const s=db.skills[id-1]; return (s.occasion===0||s.occasion===2)&&s.mp<=a.mp&&s.scope!==0; },draw:(g,id,i,r)=>{ const s=db.skills[id-1]; R.drawIcon(g,s.icon,r.x,r.y+3,28); UI.text(g,s.name,r.x+34,r.y+r.h/2,{maxW:r.w-110}); UI.text(g,s.mp+' MP',r.x+r.w-6,r.y+r.h/2,{align:'right',size:18,color:'#9cf'}); }}); this.co=new R.Co(this.main()); }
  *main(){ const db=R.$db, g=R.$game; while(true){ const i=yield* this.pick(this.L); if(i<0){ R.SM.pop(); return; } const s=db.skills[this.L.items[i]-1]; const P=partyList(8,140,W-16,Hh-140-96,100,2); this.P=P; let tg; if(s.scope===4){ yield* this.pickAllOnly(); tg=g.party; } else if(s.scope===5){ tg=[this.a]; } else { const k=yield* this.pick(P); if(k<0){ this.P=null; continue; } tg=[g.party[k]]; } let any=false; for(const t of tg){ if(s.type==='revive'?!t.isDead():t.isDead()) continue; const r=R.useOn(this.a,t,s,false,{noEvade:true}); if(!r.fail) any=true; } this.P=null; if(any){ this.a.gainMp(-s.mp); R.Audio.se('Heal'); } else R.Audio.se('Buzzer'); } }
  *pickAllOnly(){ R.Input.flush(); yield; while(true){ if(R.Input.pressed('ok')){ R.Audio.se('OK'); return; } yield; } }
  draw(g){ bgMenu(g,this.t); UI.win(g,8,8,W-16,124); drawActorCard(g,this.a,12,12,W-24,116); if(this.P) this.P.draw(g); else this.L.draw(g); UI.win(g,8,Hh-88,W-16,80); const id=this.L.items[this.L.index]; if(id&&!this.P) UI.text(g,R.$db.skills[id-1].desc||'',28,Hh-48,{size:20,maxW:W-60}); }
};

/* ---- Equip ---- */
R.Scene_Equip = class extends B {
  constructor(a,i){ super(); this.a=a; }
  start(){ const a=this.a; this.S=new UI.List({x:8,y:140,w:360,h:5*40+24,items:[0,1,2,3,4],rowH:40,draw:(g,s,i,r)=>{ UI.text(g,R.EQUIP_SLOTS[i],r.x+6,r.y+r.h/2,{size:17,color:'#8cf'}); const e=a.equipItem(i); if(e){ R.drawIcon(g,e.icon,r.x+84,r.y+4,28); UI.text(g,e.name,r.x+118,r.y+r.h/2,{maxW:r.w-130}); } else UI.text(g,'-',r.x+90,r.y+r.h/2,{color:'#889'}); }}); this.O=new UI.List({x:376,y:140,w:W-384,h:Hh-140-96,items:[],rowH:38,draw:(g,e,i,r)=>{ if(!e){ UI.text(g,'(Remove)',r.x+6,r.y+r.h/2,{color:'#bcd'}); return; } R.drawIcon(g,e.d.icon,r.x,r.y+3,28); UI.text(g,e.d.name,r.x+34,r.y+r.h/2,{maxW:r.w-80}); UI.text(g,'x'+e.n,r.x+r.w-6,r.y+r.h/2,{align:'right',size:18}); }}); this.O.active=false; this.co=new R.Co(this.main()); }
  cands(slot){ const g=R.$game,db=R.$db; const out=[null]; const tbl=slot===0?g.weapons:g.armors; const lst=slot===0?db.weapons:db.armors; for(const id of Object.keys(tbl).map(Number).sort((a,b)=>a-b)){ const d=lst[id-1]; if(d&&this.a.canEquip(slot,d)) out.push({id:id,d:d,n:tbl[id]}); } return out; }
  *main(){ const g=R.$game; while(true){ const s=yield* this.pick(this.S); if(s<0){ R.SM.pop(); return; } this.S.active=false; this.O.set(this.cands(s)); this.O.index=0; this.O.top=0; this.O.active=true; this.slot=s; const k=yield* this.pick(this.O); this.O.active=false; this.S.active=true; if(k<0){ this.preview=null; continue; } const cur=this.a.equips[s]; const nw=this.O.items[k]; const tbl=s===0?'weapon':'armor'; if(cur) g.gainItem(tbl,cur,1); if(nw){ g.gainItem(tbl,nw.id,-1); this.a.equips[s]=nw.id; } else this.a.equips[s]=0; this.a.hp=Math.min(this.a.hp,this.a.mhp); this.a.mp=Math.min(this.a.mp,this.a.mmp); R.Audio.se('OK'); } }
  draw(g){ bgMenu(g,this.t); UI.win(g,8,8,W-16,124); drawActorCard(g,this.a,12,12,W-24,116); this.S.draw(g); this.O.draw(g); const a=this.a; const sel=this.O.active?this.O.items[this.O.index]:null; const names=['atk','def','mat','mdf','agi','luk']; const y0=140+5*40+34; UI.win(g,8,y0-10,360,Hh-y0-86+10); names.forEach((p,i)=>{ const cur=a[p]; let nv=cur; if(this.O.active){ const old=a.equips[this.slot]; const eo=a.equipItem(this.slot); const ne=sel?sel.d:null; nv=cur-((eo&&eo.params&&eo.params[p])||0)+((ne&&ne.params&&ne.params[p])||0); } const yy=y0+8+i*22; UI.text(g,R.PARAM_NAMES[p],24,yy,{size:16,color:'#8cf'}); UI.text(g,String(cur),190,yy,{size:17,align:'right'}); if(this.O.active){ UI.text(g,'→',212,yy,{size:16}); UI.text(g,String(Math.round(nv)),270,yy,{size:17,align:'right',color:nv>cur?'#7aff9a':nv<cur?'#ff7a7a':'#fff'}); } }); UI.win(g,8,Hh-88,W-16,80); const e=this.O.active&&sel?sel.d:a.equipItem(this.S.index); if(e) UI.text(g,e.desc||'',28,Hh-48,{size:20,maxW:W-60}); }
};

/* ---- Status ---- */
R.Scene_Status = class extends B {
  constructor(a){ super(); this.a=a; }
  start(){ this.co=new R.Co((function*(){ while(true){ if(R.Input.pressed('cancel')||R.Input.clicked()){ R.Audio.se('Cancel'); R.SM.pop(); return; } yield; } })()); }
  draw(g){ bgMenu(g,this.t); const a=this.a, db=R.$db; UI.win(g,8,8,W-16,Hh-16); const fc=R.faceCanvas(a.img,192); if(fc) g.drawImage(fc,28,28,192,192); const sh=R.charSheet(a.img); if(sh){ g.imageSmoothingEnabled=false; g.drawImage(sh,48,0,48,48,60,236,128,128); } UI.text(g,a.name,250,50,{size:32}); UI.text(g,a.nickname||'',250,86,{size:20,color:'#ffe27a'}); UI.text(g,db.classes[a.cls-1].name+'   '+db.system.terms.level+' '+a.level,250,120,{size:22,color:'#9cf'}); UI.text(g,'HP',250,160,{size:18,color:'#8cf'}); UI.gauge(g,290,152,230,14,a.hp/a.mhp,'#e8433f','#f5a33a'); UI.text(g,a.hp+'/'+a.mhp,530,160,{size:18}); UI.text(g,'MP',250,190,{size:18,color:'#8cf'}); UI.gauge(g,290,182,230,14,a.mmp?a.mp/a.mmp:0,'#3a7fe8','#6ad0ff'); UI.text(g,a.mp+'/'+a.mmp,530,190,{size:18}); UI.text(g,'EXP',250,220,{size:18,color:'#8cf'}); UI.gauge(g,290,212,230,10,a.expRate(),'#4aa851','#9cf0a8'); UI.text(g,'Next: '+a.expToNext(),530,220,{size:16});
    ['atk','def','mat','mdf','agi','luk'].forEach((p,i)=>{ const x=250+(i%2)*270, y=264+Math.floor(i/2)*32; UI.text(g,R.PARAM_NAMES[p],x,y,{size:18,color:'#8cf'}); UI.text(g,String(a[p]),x+210,y,{size:20,align:'right'}); });
    UI.text(g,'Equipment',24,392,{size:18,color:'#ffe27a'}); for(let s=0;s<5;s++){ const e=a.equipItem(s); const x=24+(s%2)*380, y=424+Math.floor(s/2)*34; UI.text(g,R.EQUIP_SLOTS[s],x,y,{size:15,color:'#8cf'}); if(e){ R.drawIcon(g,e.icon,x+80,y-14,26); UI.text(g,e.name,x+112,y,{size:18,maxW:240}); } }
    UI.text(g,'Skills',24,528,{size:18,color:'#ffe27a'}); let sx=24, sy=556; for(const id of a.skills){ const s=db.skills[id-1]; if(!s) continue; R.drawIcon(g,s.icon,sx,sy-14,24); UI.text(g,s.name,sx+28,sy,{size:15,maxW:110}); sx+=150; if(sx>W-160){ sx=24; sy+=26; } if(sy>Hh-14) break; }
    UI.text(g,a.data.profile||'',250,Hh-24,{size:15,maxW:540,bold:false,color:'#cdd'}); }
};

/* ---- Save / Load ---- */
R.Scene_Save = class extends B {
  constructor(mode){ super(); this.mode=mode; }
  start(){ const slots=Array.from({length:10},(_,i)=>i+1); this.L=new UI.List({x:8,y:60,w:W-16,h:Hh-68,items:slots,rowH:52,enabled:(s)=>this.mode==='save'?true:!!Save.get(s),draw:(g,s,i,r)=>{ const d=Save.get(s); UI.text(g,'File '+s,r.x+6,r.y+r.h/2,{size:20,color:'#8cf'}); if(d){ const m=d.game; const names=m.party.map(id=>m.actors[id].name).join(', '); const a0=m.actors[m.party[0]]; UI.text(g,names,r.x+100,r.y+16,{size:17,maxW:320}); UI.text(g,'Lv '+(a0?a0.level:'?')+'   '+R.fmtTime(m.frames)+'   '+new Date(d.time).toLocaleString(),r.x+100,r.y+38,{size:14,bold:false,color:'#cdd'}); } else UI.text(g,'(Empty)',r.x+100,r.y+r.h/2,{color:'#889'}); }}); this.co=new R.Co(this.main()); }
  *main(){ while(true){ const i=yield* this.pick(this.L); if(i<0){ R.SM.pop(); return; } const slot=i+1; if(this.mode==='save'){ Save.write(slot); R.Audio.se('Chest'); this.note='Saved to file '+slot; this.noteT=60; }
      else { const d=Save.get(slot); if(!d) continue; R.Audio.stopBgm(); R.$game=new R.Game(); R.$game.load(d.game); R.SM.stack.length=0; R.SM.push(R.$scene=new R.Scene_Map()); R.$scene.start(true); return; } } }
  draw(g){ bgMenu(g,this.t); UI.text(g,this.mode==='save'?R.$db.system.terms.save:R.$db.system.terms.continue,W/2,34,{size:30,align:'center'}); this.L.draw(g); if(this.noteT>0){ this.noteT--; UI.win(g,W/2-150,Hh/2-30,300,60); UI.text(g,this.note,W/2,Hh/2,{align:'center'}); } }
};

/* ---- Shop ---- */
R.Scene_Shop = class extends B {
  constructor(goods,buyOnly){ super(); this.goods=goods; this.buyOnly=buyOnly; }
  start(){ const db=R.$db, T=db.system.terms; this.C=new UI.List({x:8,y:8,w:W-16,h:60,items:this.buyOnly?[T.buy,T.cancel]:[T.buy,T.sell,T.cancel],cols:3,rowH:40,pad:10}); this.mode='cmd'; this.I=new UI.List({x:8,y:76,w:W-16,h:Hh-76-96,items:[],cols:1,rowH:38,draw:(g,e,i,r)=>{ R.drawIcon(g,e.d.icon,r.x,r.y+3,28); UI.text(g,e.d.name,r.x+34,r.y+r.h/2,{maxW:r.w-260}); UI.text(g,'Own '+R.$game.numItems(e.kind,e.id),r.x+r.w-170,r.y+r.h/2,{size:16,align:'right',color:'#bcd'}); UI.text(g,e.price+' '+db.system.currency,r.x+r.w-8,r.y+r.h/2,{align:'right',color:'#ffe27a'}); },enabled:e=>this.mode==='buy'?R.$game.gold>=e.price&&R.$game.numItems(e.kind,e.id)<99:true}); this.co=new R.Co(this.main()); }
  listOf(k){ return k==='item'?R.$db.items:k==='weapon'?R.$db.weapons:R.$db.armors; }
  *main(){ const db=R.$db, g=R.$game; while(true){ const c=yield* this.pick(this.C); const n=this.C.items.length; if(c<0||c===n-1){ R.SM.pop(); return; } this.C.active=false;
      if(c===0){ this.mode='buy'; this.I.set(this.goods.map(x=>{ const d=this.listOf(x.kind)[x.id-1]; return d?{kind:x.kind,id:x.id,d:d,price:x.price||d.price}:null; }).filter(Boolean)); }
      else { this.mode='sell'; const out=[]; for(const kind of ['item','weapon','armor']){ const tbl=g[kind==='item'?'items':kind==='weapon'?'weapons':'armors']; for(const id of Object.keys(tbl).map(Number)){ const d=this.listOf(kind)[id-1]; if(d&&!d.key&&d.price>0) out.push({kind:kind,id:id,d:d,price:Math.floor(d.price/2)}); } } this.I.set(out); }
      this.I.index=0; this.I.top=0;
      while(true){ const i=yield* this.pick(this.I); if(i<0) break; const e=this.I.items[i]; const own=g.numItems(e.kind,e.id); const max=this.mode==='buy'?Math.min(99-own,Math.floor(g.gold/e.price)):own; if(max<=0) continue; let q=1; this.qty={q:1,max:max,e:e}; R.Input.flush(); yield; while(true){ if(R.Input.repeat('up')||R.Input.repeat('right')) this.qty.q=Math.min(max,this.qty.q+(R.Input.repeat('up')?10:1)); if(R.Input.repeat('down')||R.Input.repeat('left')) this.qty.q=Math.max(1,this.qty.q-(R.Input.repeat('down')?10:1)); if(R.Input.pressed('ok')){ q=this.qty.q; break; } if(R.Input.pressed('cancel')){ q=0; break; } yield; } this.qty=null; if(q>0){ if(this.mode==='buy'){ g.gainGold(-e.price*q); g.gainItem(e.kind,e.id,q); } else { g.gainGold(e.price*q); g.gainItem(e.kind,e.id,-q); } R.Audio.se('Coin'); if(this.mode==='sell'){ this.I.set(this.I.items.filter(x=>g.numItems(x.kind,x.id)>0)); if(!this.I.items.length) break; } } }
      this.C.active=true; this.mode='cmd'; this.I.set([]); } }
  draw(g){ bgMenu(g,this.t); this.C.draw(g); this.I.draw(g); const e=this.I.items[this.I.index]; UI.win(g,8,Hh-88,W-16,80); if(e) UI.text(g,e.d.desc||'',28,Hh-48,{size:20,maxW:W-300}); UI.text(g,'Gold '+R.$game.gold+' '+R.$db.system.currency,W-24,Hh-48,{align:'right',color:'#ffe27a',size:22}); if(this.qty){ UI.win(g,W/2-190,Hh/2-70,380,140); UI.text(g,this.qty.e.d.name,W/2,Hh/2-34,{align:'center',maxW:340}); UI.text(g,'◀ '+this.qty.q+' ▶',W/2,Hh/2,{align:'center',size:32}); UI.text(g,'Total: '+this.qty.q*this.qty.e.price+' '+R.$db.system.currency,W/2,Hh/2+44,{align:'center',color:'#ffe27a'}); } }
};

/* ---- Name input ---- */
R.Scene_NameInput = class extends B {
  constructor(a,max){ super(); this.a=a; this.max=max; this.text=a.name; }
  start(){ const rows=['ABCDEFGHIJKLM','NOPQRSTUVWXYZ','abcdefghijklm','nopqrstuvwxyz','0123456789 .-_','!?+*&@#   ←OK']; const chars=[]; rows.forEach(r=>r.split('').forEach(c=>chars.push(c))); this.chars=chars; this.L=new UI.List({x:W/2-300,y:250,w:600,h:6*44+24,items:chars,cols:13,rowH:44,pad:12,draw:(g,c,i,r)=>UI.text(g,c==='←'?'DEL':(i===chars.length-1?'OK':c),r.x+r.w/2,r.y+r.h/2,{align:'center',size:22})}); this.L.index=0; this.co=new R.Co(this.main()); R.Input.keyBuf=[]; }
  *main(){ while(true){ const r=this.L.update(); for(const k of (R.Input.keyBuf||[])){ if(k==='Backspace') this.text=this.text.slice(0,-1); else if(k.length===1&&/[ -~]/.test(k)&&this.text.length<this.max&&!/[zZxX0wWaAsSdDqQeE ]/.test('') ) this.text+=k; } R.Input.keyBuf=[];
      if(r==='ok'){ const c=this.L.items[this.L.index]; if(this.L.index===this.L.items.length-1){ this.a.name=this.text||this.a.name; R.SM.pop(); return; } if(c==='←') this.text=this.text.slice(0,-1); else if(this.text.length<this.max) this.text+=c; } if(r==='cancel'&&this.text.length) this.text=this.text.slice(0,-1); yield; } }
  draw(g){ bgMenu(g,this.t); UI.win(g,W/2-300,40,600,180); const fc=R.faceCanvas(this.a.img,144); if(fc) g.drawImage(fc,W/2-280,60,144,144); UI.text(g,'Enter a name (type or pick)',W/2-110,80,{size:18,color:'#8cf'}); for(let i=0;i<this.max;i++){ g.fillStyle='rgba(255,255,255,.3)'; g.fillRect(W/2-110+i*34,150,30,3); UI.text(g,this.text[i]||'',W/2-95+i*34,134,{size:28,align:'center'}); } this.L.draw(g); }
};

/* ---- Game Over ---- */
R.Scene_GameOver = class extends B {
  start(){ R.Audio.playBgm(R.$db.system.gameoverBgm); this.co=new R.Co((function*(){ yield 90; while(true){ if(R.Input.pressed('ok')||R.Input.clicked()){ R.Audio.stopBgm(); R.SM.goto(new R.Scene_Title()); return; } yield; } })()); }
  draw(g){ g.fillStyle='#000'; g.fillRect(0,0,W,Hh); const a=Math.min(1,this.t/60); g.save(); g.globalAlpha=a; g.shadowColor='#a00'; g.shadowBlur=30; UI.text(g,'GAME OVER',W/2,Hh/2-10,{size:64,align:'center',color:'#e8433f'}); g.restore(); if(this.t>90&&Math.floor(this.t/30)%2) UI.text(g,'Press OK to return to the title',W/2,Hh/2+60,{align:'center',size:18,color:'#bbb'}); }
};
})();
