/* Peta runtime: karakter, event, tabrakan, pergerakan, follower, render */
(function(){
'use strict';
const R = window.RPG, T = R.TILE, UI = R.UI;
const DX={2:0,4:-1,6:1,8:0}, DY={2:1,4:0,6:0,8:-1};
const REV={2:8,4:6,6:4,8:2}, LEFT={2:6,6:8,8:4,4:2}, RIGHT={2:4,4:8,8:6,6:2};
R.DX=DX; R.DY=DY; R.REVDIR=REV;

class Char {
  constructor(){ this.x=0; this.y=0; this.rx=0; this.ry=0; this.dir=2; this.pat=1; this.img={kind:'none'}; this.speed=4; this.freq=3; this.walkAnim=true; this.stepAnim=false; this.dirFix=false; this.through=false; this.transparent=false; this.prio=1; this.moving=false; this.animCount=0; this.waitCount=0; this.route=null; this.routeIdx=0; this.routeRepeat=false; this.routeDone=true; this.jump=null; this.balloon=null; this.flashT=0; this.opacity=255; this.moveType='fixed'; this.moveRoute=[]; this.stopCount=0; this.tileId=0; this.locked=false; this.originalPat=1; this.fx=0; this.fy=0; }
  setPos(x,y){ this.x=x; this.y=y; this.rx=x; this.ry=y; this.moving=false; }
  distPerFrame(){ return Math.pow(2,this.speed)/256 * (this.dashing?1.6:1); }
  isMoving(){ return this.moving||!!this.jump; }
  canPass(x,y,d,map){ const nx=x+DX[d], ny=y+DY[d]; if(!map.valid(nx,ny)) return false; if(this.through) return true; if(!map.passable(nx,ny)) return false; if(map.eventBlockAt(nx,ny,this)) return false; return true; }
  moveStraight(d,map,force){ if(this.moving) return false; if(!this.dirFix) this.dir=d; if(force||this.canPass(this.x,this.y,d,map)){ this.tx=this.x+DX[d]; this.ty=this.y+DY[d]; this.moving=true; this.lastX=this.x; this.lastY=this.y; this.x=this.tx; this.y=this.ty; this.stopCount=0; return true; } return false; }
  update(map){ this.updateMove(); this.updateAnim(); if(!this.moving&&!this.jump) this.updateStop(map); if(this.flashT>0) this.flashT--; if(this.balloon){ this.balloon.t++; if(this.balloon.t>this.balloon.dur) this.balloon=null; } }
  updateMove(){ if(this.jump){ const j=this.jump; j.t++; const p=j.t/j.dur; this.rx=j.sx+(j.dx)*p; this.ry=j.sy+(j.dy)*p; this.jh=Math.sin(p*Math.PI)*(Math.abs(j.dx)+Math.abs(j.dy)+1.2)*T*.28; if(j.t>=j.dur){ this.jump=null; this.jh=0; this.rx=this.x; this.ry=this.y; if(this.onStep) this.onStep(); } return; } if(!this.moving) return; const d=this.distPerFrame(); const ddx=this.x-this.rx, ddy=this.y-this.ry; const dist=Math.abs(ddx)+Math.abs(ddy); if(dist<=d){ this.rx=this.x; this.ry=this.y; this.moving=false; if(this.onStep) this.onStep(); } else { this.rx+=Math.sign(ddx)*Math.min(d,Math.abs(ddx)); this.ry+=Math.sign(ddy)*Math.min(d,Math.abs(ddy)); } }
  updateAnim(){ if(this.img.kind==='none'||this.img.kind==='tile'){ return; } if(this.moving&&this.walkAnim||this.stepAnim){ this.animCount+=1+(this.speed-4)*.2; const per=Math.max(8,16-this.speed*1.5); this.pat=[0,1,2,1][Math.floor(this.animCount/per)%4]; } else { this.animCount=0; this.pat=this.originalPat; } }
  updateStop(map){ this.stopCount++; if(this.waitCount>0){ this.waitCount--; return; } if(this.route){ this.updateRoute(map); return; } }
  forceRoute(route,repeat){ this.route=route.slice(); this.routeIdx=0; this.routeRepeat=!!repeat; this.routeDone=false; }
  stopRoute(){ this.route=null; this.routeDone=true; }
  updateRoute(map){ if(this.routeIdx>=this.route.length){ if(this.routeRepeat&&this.route.length){ this.routeIdx=0; } else { this.route=null; this.routeDone=true; return; } }
    const c=this.route[this.routeIdx]; const op=c[0]; let adv=true; const g=R.$game;
    switch(op){
      case 'move': if(!this.moveStraight(c[1],map)){ if(this.routeSkip) {} else adv=false; if(!adv){ this.waitCount=4; this.routeFail=(this.routeFail||0)+1; if(this.routeFail>30){ this.routeFail=0; adv=true; } } } else this.routeFail=0; break;
      case 'turn': this.dir=c[1]; break;
      case 'moverandom': { const d=[2,4,6,8][Math.floor(Math.random()*4)]; this.moveStraight(d,map); break; }
      case 'toward': { const p=map.player; this.moveStraight(this.dirToward(p),map); break; }
      case 'away': { const p=map.player; this.moveStraight(REV[this.dirToward(p)],map); break; }
      case 'forward': this.moveStraight(this.dir,map); break;
      case 'back': { const od=this.dir; this.moveStraight(REV[this.dir],map); this.dir=od; break; }
      case 'jump': this.doJump(c[1],c[2],map); break;
      case 'wait': this.waitCount=c[1]; break;
      case 'speed': this.speed=c[1]; break; case 'freq': this.freq=c[1]; break;
      case 'through': this.through=!!c[1]; break; case 'dirfix': this.dirFix=!!c[1]; break; case 'transparent': this.transparent=!!c[1]; break; case 'walkanim': this.walkAnim=!!c[1]; break; case 'stepanim': this.stepAnim=!!c[1]; break;
      case 'turnrandom': this.dir=[2,4,6,8][Math.floor(Math.random()*4)]; break;
      case 'turntoward': this.dir=this.dirToward(map.player); break; case 'turnaway': this.dir=REV[this.dirToward(map.player)]; break;
      case 'turnleft': this.dir=LEFT[this.dir]; break; case 'turnright': this.dir=RIGHT[this.dir]; break;
      case 'switch': g.setS(c[1],c[2]); map.needRefresh=true; break;
      case 'script': try{ new Function('$game','$map','self',c[1])(g,map,this); }catch(e){ console.warn(e); } break;
      case 'opacity': this.opacity=c[1]; break;
    }
    if(adv) this.routeIdx++; }
  dirToward(t){ const dx=t.x-this.x, dy=t.y-this.y; if(Math.abs(dx)>Math.abs(dy)) return dx>0?6:4; if(dy!==0) return dy>0?2:8; return this.dir; }
  doJump(dx,dy,map){ if(this.jump||this.moving) return; if(Math.abs(dx)>Math.abs(dy)){ if(dx!==0&&!this.dirFix) this.dir=dx<0?4:6; } else if(dy!==0&&!this.dirFix) this.dir=dy<0?8:2; const nx=this.x+dx, ny=this.y+dy; if(!this.through&&!(dx===0&&dy===0)&&(!map.valid(nx,ny)||!map.passable(nx,ny))){ return; } this.jump={sx:this.x,sy:this.y,dx:dx,dy:dy,t:0,dur:Math.max(12,Math.round(Math.sqrt(dx*dx+dy*dy)*10+12))}; this.x=nx; this.y=ny; }
  isNear(x,y){ return this.x===x&&this.y===y; }
}
R.Char = Char;

class EventRT extends Char {
  constructor(data,map){ super(); this.data=data; this.id=data.id; this.map=map; this.page=null; this.pageIdx=-1; this.erased=false; this.setPos(data.x,data.y); this.running=false; this.starting=false; this.sx=data.x; this.sy=data.y; this.refresh(); if(data.mob&&R.initMob){ R.initMob(this); if(this.mob){ this.trigger=-1; this.list=null; } } }
  condOk(c){ const g=R.$game; if(c.s1&&!g.s(c.s1)) return false; if(c.s2&&!g.s(c.s2)) return false; if(c.v&&g.v(c.v)<c.vv) return false; if(c.selfSw&&!g.selfSw[g.selfKey(this.map.id,this.id,c.selfSw)]) return false; if(c.item&&!g.numItems('item',c.item)) return false; if(c.actor&&!g.party.some(a=>a.id===c.actor)) return false; return true; }
  refresh(){ let idx=-1; if(!this.erased) for(let i=this.data.pages.length-1;i>=0;i--){ if(this.condOk(this.data.pages[i].cond)){ idx=i; break; } } if(idx===this.pageIdx) return; this.pageIdx=idx; this.page=idx>=0?this.data.pages[idx]:null; this.running=false; if(!this.page){ this.img={kind:'none'}; this.list=null; this.trigger=-1; return; } const p=this.page; this.img=p.img.kind==='tile'?{kind:'tile',tile:p.img.tile}:(p.img||{kind:'none'}); if(p.img.kind==='tile') this.tileId=p.img.tile; this.dir=p.dir||2; this.originalPat=p.pat===undefined?1:p.pat; this.pat=this.originalPat; this.moveType=p.move.type; this.speed=p.move.speed; this.freq=p.move.freq; this.moveRoute=p.move.route||[]; this.walkAnim=p.opt.walkAnim; this.stepAnim=p.opt.stepAnim; this.dirFix=p.opt.dirFix; this.through=p.opt.through; this.prio=p.prio; this.trigger=p.trigger; this.list=p.list; this.route=null; this.routeDone=true; if(this.moveType==='custom'&&this.moveRoute.length) this.forceRoute(this.moveRoute,true); }
  updateStop(map){ if(this.locked||this.running){ return; } super.updateStop(map); if(this.route||this.waitCount>0) return; if(!this.page) return; if(this.stopCount<(5-this.freq)*20+10) return; switch(this.moveType){ case 'random': this.moveStraight([2,4,6,8][Math.floor(Math.random()*4)],map); this.stopCount=0; break; case 'approach': if(Math.random()<.8) this.moveStraight(this.dirToward(map.player),map); else this.moveStraight([2,4,6,8][Math.floor(Math.random()*4)],map); this.stopCount=0; break; } }
  update(map){ if(this.mob) R.Action.updateMob(this,map); if(this.locked||this.running){ this.updateMove(); this.updateAnim(); return; } super.update(map); }
  isTriggerIn(a){ return a.includes(this.trigger); }
}
R.EventRT = EventRT;

class MapRT {
  constructor(data){ this.data=data; this.id=data.id; this.w=data.w; this.h=data.h; this.layers=data.layers; this.events=[]; this.evById={}; this.needRefresh=false; this.dispX=0; this.dispY=0; this.parallels=[]; this.anim=0;
    for(const e of data.events){ if(!e) continue; const k=R.$game.erased[this.id+','+e.id]; const ev=new EventRT(e,this); ev.erased=!!k; ev.refresh(); this.events.push(ev); this.evById[e.id]=ev; } }
  valid(x,y){ return x>=0&&y>=0&&x<this.w&&y<this.h; }
  tilesAt(x,y){ const i=y*this.w+x; return [this.layers[0][i],this.layers[1][i],this.layers[2][i],this.layers[3][i]]; }
  passable(x,y){ const t=this.tilesAt(x,y); for(let l=3;l>=0;l--){ const id=t[l]; if(!id) continue; const d=R.TILES[id-1]; if(!d||d.star) continue; return d.pass; } return true; }
  eventBlockAt(x,y,self){ for(const e of this.events){ if(e===self||!e.page||e.erased) continue; if(e.x===x&&e.y===y&&!e.through&&e.prio===1&&!e.transparent&&(e.img.kind!=='none'||e.tileId||true)) { if(e.img.kind==='none'&&!e.tileId) { continue; } return e; } } if(self!==this.player&&this.player&&this.player.x===x&&this.player.y===y&&!this.player.through&&self.prio===1&&!self.isPlayerLike) return this.player; return null; }
  eventsAt(x,y){ return this.events.filter(e=>e.page&&!e.erased&&e.x===x&&e.y===y); }
  isBush(x,y){ const t=this.tilesAt(x,y); return t.some(id=>id&&R.TILES[id-1]&&R.TILES[id-1].bush); }
  damageAt(x,y){ const t=this.tilesAt(x,y); return t.some(id=>id&&R.TILES[id-1]&&R.TILES[id-1].damage); }
  refresh(){ for(const e of this.events) e.refresh(); this.needRefresh=false; }
  update(){ this.anim++; if(this.needRefresh) this.refresh(); for(const e of this.events){ if(e.page&&!e.erased) e.update(this); } }
  /* ---- kamera ---- */
  setupCamera(p,vw,vh){ this.vw=vw/T; this.vh=vh/T; this.centerOn(p.rx,p.ry); }
  centerOn(x,y){ const mw=this.vw, mh=this.vh; this.dispX=this.w<=mw? (this.w-mw)/2 : Math.max(0,Math.min(this.w-mw,x-(mw-1)/2)); this.dispY=this.h<=mh? (this.h-mh)/2 : Math.max(0,Math.min(this.h-mh,y-(mh-1)/2)); }
  /* ---- render ---- */
  draw(g,vw,vh,player,followers,shakeX){ const fr=Math.floor(this.anim/16)%3; const x0=Math.floor(this.dispX), y0=Math.floor(this.dispY); const ox=-(this.dispX-x0)*T+(shakeX||0), oy=-(this.dispY-y0)*T; const cols=Math.ceil(vw/T)+1, rows=Math.ceil(vh/T)+1;
    g.fillStyle='#000'; g.fillRect(0,0,vw,vh);
    const L=this.layers; const getL0=(x,y)=> (x<0||y<0||x>=this.w||y>=this.h)? -1 : L[0][y*this.w+x];
    const drawLayer=(l,pre)=>{ for(let ry=0;ry<rows;ry++) for(let rx=0;rx<cols;rx++){ const x=x0+rx, y=y0+ry; if(x<0||y<0||x>=this.w||y>=this.h) continue; const id=L[l][y*this.w+x]; if(!id) continue; const d=R.TILES[id-1]; if(!d) continue; const hi=(l===3||d.star); if(hi===pre) continue; const cv=R.tileCanvas(id,fr); const dx=Math.round(ox+rx*T), dy=Math.round(oy+ry*T); g.drawImage(cv,dx,dy); if(l===0&&d.edge){ const nb={u:getL0(x,y-1)!==id&&getL0(x,y-1)!==-1,d:getL0(x,y+1)!==id&&getL0(x,y+1)!==-1,l:getL0(x-1,y)!==id&&getL0(x-1,y)!==-1,r:getL0(x+1,y)!==id&&getL0(x+1,y)!==-1}; if(nb.u||nb.d||nb.l||nb.r) R.drawTileEdges(g,d,dx,dy,nb,T); } } };
    for(let l=0;l<3;l++) drawLayer(l,true);
    const chars=[]; for(const e of this.events){ if(!e.page||e.erased||e.transparent&&e.img.kind==='none') continue; if(e.img.kind==='none'&&!e.tileId&&!e.mob) continue; chars.push(e); } for(const f of followers||[]) chars.push(f); if(player&&!player.transparent) chars.push(player);
    chars.sort((a,b)=>{ const pa=a.prio===0?-1:a.prio===2?1:0, pb=b.prio===0?-1:b.prio===2?1:0; if(pa!==pb) return pa-pb; return (a.ry-b.ry)||(a.rx-b.rx); });
    const drawChar=(c)=>{ this.drawChar(g,c,ox-(x0-this.dispX)*0-0,oy,x0,y0,cols,rows); };
    for(const c of chars) if(c.prio!==2) drawChar(c);
    for(let l=0;l<4;l++) drawLayer(l,false);
    for(const c of chars) if(c.prio===2) drawChar(c);
    for(const c of chars) if(c.balloon) this.drawBalloon(g,c,ox,oy,x0,y0);
  }
  charScreen(c,ox,oy,x0,y0){ return {x:Math.round(ox+(c.rx-x0)*T), y:Math.round(oy+(c.ry-y0)*T-(c.jh||0))}; }
  drawChar(g,c,ox,oy,x0,y0){ const p=this.charScreen(c,ox,oy,x0,y0); if(p.x<-T||p.y<-T*2||p.x>1000||p.y>800) return; if(c.flashT>0&&Math.floor(c.flashT/3)%2) return; if(c.mob){ g.save(); g.globalAlpha=(c.fade===undefined?1:c.fade); R.Action.drawMob(g,c,p); g.restore(); return; } g.save(); g.globalAlpha=(c.opacity/255)*(c.fade===undefined?1:c.fade);
    if(c.jump||c.jh){ R.H.ell(g,'rgba(0,0,0,.25)',p.x+24,p.y+(c.jh||0)+42,12,4); }
    const bushed=this.isBush(Math.round(c.rx),Math.round(c.ry));
    if(c.img.kind==='tile'){ const cv=R.tileCanvas(c.tileId,Math.floor(this.anim/16)); if(cv) g.drawImage(cv,p.x,p.y); }
    else { const sh=R.charSheet(c.img); if(sh){ const row={2:0,4:1,6:2,8:3}[c.dir]||0; const big=sh.width>144; if(big){ const cw=sh.width/3, ch=sh.height/4; g.imageSmoothingEnabled=false; g.drawImage(sh,c.pat*cw,row*ch,cw,ch,p.x+24-cw*(T/ch)/2,p.y+T-ch*(T/ch)+0,cw*(T/ch),T); } else { if(bushed){ g.drawImage(sh,c.pat*48,row*48,48,36,p.x,p.y,48,36); g.globalAlpha*=.5; g.drawImage(sh,c.pat*48,row*48+36,48,12,p.x,p.y+36,48,12); } else g.drawImage(sh,c.pat*48,row*48,48,48,p.x,p.y,48,48); } } }
    g.restore(); }
  drawBalloon(g,c,ox,oy,x0,y0){ const p=this.charScreen(c,ox,oy,x0,y0); const b=c.balloon; const fr=Math.min(7,Math.floor(b.t/6)); const bx=p.x+24, by=p.y-14-(b.t<6?(6-b.t):0); R.H.rr(g,'#fff',bx-17,by-30,34,30,8); R.H.poly(g,'#fff',bx-5,by-2,bx+5,by-2,bx,by+7); const cx=bx, cy=by-15; const ic=b.icon; g.save(); g.fillStyle='#333'; g.font='bold 22px sans-serif'; g.textAlign='center'; g.textBaseline='middle'; const sym=['!','?','♪','♥','#','~','…','','★','z'][ic]||'!'; const col=['#d33','#36c','#3a3','#e46','#d33','#58c','#777','#999','#e9b','#68c'][ic]||'#333'; g.fillStyle=col; g.fillText(ic===7?'. . .':sym,cx,cy+1); g.restore(); }
  /* titik di layar (px) ke tile */
  screenToTile(sx,sy){ return {x:Math.floor(sx/T+this.dispX),y:Math.floor(sy/T+this.dispY)}; }
}
R.MapRT = MapRT;
})();
