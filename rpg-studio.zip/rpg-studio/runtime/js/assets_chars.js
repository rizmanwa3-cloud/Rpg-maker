/* Bagian 3: karakter (sprite sheet 3x4), wajah, monster, ikon - semua prosedural & orisinal */
(function(){
'use strict';
const R = window.RPG, H = R.H, shade = R.shade;
const {fill,rect,circ,ell,poly,line,rr} = H;
const mk = R.mkCanvas;

/* ---------- KARAKTER ----------
 spec: {skin, hair, hairStyle(0-5), outfit, outfit2, boots, eyes, acc(0 none,1 hat,2 cape,3 helmet,4 glasses,5 crown,6 hood), body(0 normal,1 robe,2 armor)}
 sheet: 144x192, cell 48x48, baris: 0 bawah,1 kiri,2 kanan,3 atas, kolom: 0,1(diam),2 */
R.CHAR_DEFAULT = {skin:'#f2c9a0',hair:'#4a3020',hairStyle:0,outfit:'#3a6fc4',outfit2:'#e8c25a',boots:'#4a3020',eyes:'#2a2a40',acc:0,body:0};
R.CHAR_PRESETS = [
 {name:'Hero',skin:'#f2c9a0',hair:'#3a5fb8',hairStyle:0,outfit:'#3a6fc4',outfit2:'#e8c25a',boots:'#4a3020',eyes:'#2a3a60',acc:2,body:2},
 {name:'Mage',skin:'#f6d6b4',hair:'#8a4ac4',hairStyle:2,outfit:'#6a3ab0',outfit2:'#e8c25a',boots:'#3a2a4a',eyes:'#4a2a80',acc:1,body:1},
 {name:'Warrior',skin:'#d9a878',hair:'#a8353f',hairStyle:1,outfit:'#8d8d98',outfit2:'#c9ccd4',boots:'#3a3a44',eyes:'#4a2a20',acc:3,body:2},
 {name:'Healer',skin:'#f2c9a0',hair:'#f0d080',hairStyle:3,outfit:'#f4f4f4',outfit2:'#4aa851',boots:'#8a6a40',eyes:'#2a6a4a',acc:0,body:1},
 {name:'Rogue',skin:'#c8946a',hair:'#2a2a30',hairStyle:4,outfit:'#3a3a48',outfit2:'#a8353f',boots:'#2a2a30',eyes:'#6a2a2a',acc:6,body:0},
 {name:'Villager M',skin:'#f2c9a0',hair:'#6b4423',hairStyle:1,outfit:'#a8794a',outfit2:'#e8dcc4',boots:'#5c3a1a',eyes:'#2a2a40',acc:0,body:0},
 {name:'Villager F',skin:'#f6d6b4',hair:'#c0562a',hairStyle:5,outfit:'#d9433a',outfit2:'#f4f4f4',boots:'#6b4423',eyes:'#2a4a40',acc:0,body:1},
 {name:'Elder',skin:'#e8c8a8',hair:'#e8e8ee',hairStyle:2,outfit:'#6a7a8a',outfit2:'#c9ccd4',boots:'#4a3a2c',eyes:'#3a3a3a',acc:4,body:1},
 {name:'Guard',skin:'#d9a878',hair:'#4a3a2c',hairStyle:1,outfit:'#b8433a',outfit2:'#c9ccd4',boots:'#3a3a44',eyes:'#2a2a40',acc:3,body:2},
 {name:'King',skin:'#f2c9a0',hair:'#e8e8ee',hairStyle:2,outfit:'#a8353f',outfit2:'#e8c25a',boots:'#4a3a2c',eyes:'#2a2a40',acc:5,body:1},
 {name:'Merchant',skin:'#e0b088',hair:'#2a2a30',hairStyle:0,outfit:'#3a8a4a',outfit2:'#e8c25a',boots:'#5c3a1a',eyes:'#2a2a40',acc:1,body:0},
 {name:'Child',skin:'#f6d6b4',hair:'#e8b83a',hairStyle:5,outfit:'#4aa8c8',outfit2:'#f4f4f4',boots:'#8a5a30',eyes:'#2a2a40',acc:0,body:0}
];

function drawChar(g,s,dir,frame){
  // origin (0,0) = pojok sel 48x48
  const step = frame===0? -1 : frame===2? 1 : 0;
  const bob = step!==0 ? 1 : 0;
  const lx = 17, rx = 26;
  H.shadow(g,24,44,11,3.5);
  const legA = step*3;
  // kaki
  const legC = s.body===1? s.outfit : shade(s.outfit,-.25);
  if(dir===1||dir===2){
    rect(g,s.boots,21+legA,36,6,8); rect(g,s.boots,21-legA,36,6,8);
    rect(g,legC,22+legA,30,5,7); rect(g,legC,22-legA,30,5,7);
  } else {
    rect(g,legC,lx,30,6,8+(step===-1?-2:0)); rect(g,legC,rx,30,6,8+(step===1?-2:0));
    rect(g,s.boots,lx-1,37+(step===-1?-2:0),7,7); rect(g,s.boots,rx-1,37+(step===1?-2:0),7,7);
  }
  // jubah belakang (cape)
  if(s.acc===2 && dir===3){ poly(g,shade(s.outfit2,-.15),12,18-bob,36,18-bob,38,42,10,42); }
  // badan
  const by = 18+bob;
  if(s.body===1){ poly(g,s.outfit,15,by,33,by,37,41,11,41); rect(g,s.outfit2,15,by+10,18,3); poly(g,shade(s.outfit,-.2),24,by,33,by,37,41,24,41); }
  else if(s.body===2){ rr(g,s.outfit,14,by,20,16,3); rect(g,s.outfit2,14,by+1,20,3); rect(g,shade(s.outfit,-.25),14,by+12,20,4); rect(g,s.outfit2,22,by+4,4,9); circ(g,s.outfit2,13,by+3,4.5); circ(g,s.outfit2,35,by+3,4.5); }
  else { rr(g,s.outfit,15,by,18,15,3); rect(g,s.outfit2,15,by+11,18,3); rect(g,shade(s.outfit,.2),18,by+2,3,8); }
  // lengan
  const armY = by+3;
  if(dir===1||dir===2){ rr(g,shade(s.outfit,-.15),21,armY+(step*1),6,11,3); circ(g,s.skin,24,armY+12+step,3); }
  else { const a=step; rr(g,s.outfit,10,armY-a,5,11,2.5); rr(g,s.outfit,33,armY+a,5,11,2.5); circ(g,s.skin,12.5,armY+11-a,2.8); circ(g,s.skin,35.5,armY+11+a,2.8); }
  if(s.acc===2 && dir!==3){ rect(g,s.outfit2,13,by,22,2); }
  // kepala
  const hy = 4+bob;
  circ(g,s.skin,24,hy+10,10);
  // rambut belakang
  const hs = s.hairStyle;
  if(dir===3){ circ(g,s.hair,24,hy+10,10.5); if(hs===2||hs===5||hs===3) rect(g,s.hair,13,hy+10,22,hs===5?14:10); }
  else {
    // rambut belakang untuk gaya panjang
    if(hs===2||hs===3||hs===5){ rect(g,s.hair,13.5,hy+8,21,hs===2?13:12); }
    // wajah
    if(dir===0){ circ(g,s.eyes,19.5,hy+11,1.8); circ(g,s.eyes,28.5,hy+11,1.8); circ(g,'#fff',19,hy+10.3,.7); circ(g,'#fff',28,hy+10.3,.7); rect(g,'rgba(200,90,90,.5)',17,hy+14,3,1.5); rect(g,'rgba(200,90,90,.5)',28,hy+14,3,1.5); line(g,'#a8503a',22.5,hy+16,25.5,hy+16,1); }
    else { const ex = dir===1? 18 : 30; circ(g,s.eyes,ex,hy+11,1.8); circ(g,'#fff',ex+(dir===1?-.4:.4),hy+10.3,.7); rect(g,s.skin,dir===1?13:34,hy+10,1,1);  }
    // poni
    if(hs===0){ poly(g,s.hair,13,hy+8,15,hy,33,hy,35,hy+8,30,hy+4,24,hy+7,18,hy+4); }
    else if(hs===1){ poly(g,s.hair,13,hy+7,16,hy-1,32,hy-1,35,hy+7,26,hy+3,18,hy+3); circ(g,s.hair,24,hy+1,9); }
    else if(hs===2){ poly(g,s.hair,13,hy+10,14,hy-1,34,hy-1,35,hy+10,31,hy+3,17,hy+3); }
    else if(hs===3){ poly(g,s.hair,13,hy+10,14,hy,34,hy,35,hy+10,28,hy+3,24,hy+7,20,hy+3); }
    else if(hs===4){ poly(g,s.hair,12,hy+6,18,hy-3,32,hy-1,36,hy+6,28,hy+2,20,hy+3); poly(g,s.hair,34,hy+2,40,hy+8,34,hy+7); }
    else if(hs===5){ poly(g,s.hair,13,hy+9,15,hy,33,hy,35,hy+9,30,hy+3,18,hy+3); circ(g,s.hair,11,hy+4,3.5); circ(g,s.hair,37,hy+4,3.5); }
  }
  if(dir===1||dir===2){ // rambut samping
    const hx = dir===1? 13 : 24; if(hs!==4){ rr(g,s.hair,hx,hy-1,11,15,4); }
    poly(g,s.hair,13,hy+7,16,hy-1,32,hy-1,35,hy+7,26,hy+2,18,hy+2);
  }
  // aksesoris
  const A = s.acc;
  if(A===1){ ell(g,s.outfit2,24,hy+3,15,4); poly(g,s.outfit,16,hy+3,24,hy-12,32,hy+3); rect(g,s.outfit2,16,hy+1,16,2.5); }
  if(A===3){ circ(g,'#aab0bc',24,hy+8,11); rect(g,s.skin,17,hy+9,14,8); rect(g,'#2a2a30',22,hy+8,4,9); rect(g,'#d9433a',23,hy-8,2,8); }
  if(A===4 && dir!==3){ g.strokeStyle='#4a3a2c'; g.lineWidth=1.3; g.strokeRect(16,hy+8.5,7,5); g.strokeRect(25,hy+8.5,7,5); line(g,'#4a3a2c',23,hy+11,25,hy+11,1.3); }
  if(A===5){ poly(g,'#e8c25a',15,hy+1,15,hy-7,20,hy-2,24,hy-9,28,hy-2,33,hy-7,33,hy+1); circ(g,'#d9433a',24,hy-3,1.8); }
  if(A===6){ circ(g,shade(s.outfit,-.3),24,hy+8,12); if(dir!==3){ circ(g,s.skin,24,hy+12,8); circ(g,s.eyes,20,hy+12,1.5); circ(g,s.eyes,28,hy+12,1.5);} }
}
R.drawCharCell = drawChar;

R.makeCharSheet = function(spec){
  const s = Object.assign({},R.CHAR_DEFAULT,spec||{});
  const c = mk(144,192), g = c.getContext('2d');
  const dirOrder = [0,1,2,3];
  for(let row=0;row<4;row++) for(let col=0;col<3;col++){
    g.save(); g.translate(col*48,row*48); drawChar(g,s,dirOrder[row],col); g.restore();
  }
  return c;
};
R.makeFace = function(spec,size){
  const s = Object.assign({},R.CHAR_DEFAULT,spec||{}); size=size||96;
  const c = mk(size,size), g = c.getContext('2d');
  const gr = g.createLinearGradient(0,0,0,size); gr.addColorStop(0,shade(s.outfit,.55)); gr.addColorStop(1,shade(s.outfit,-.2));
  g.fillStyle=gr; g.fillRect(0,0,size,size);
  const k = size/30;
  g.save(); g.scale(k,k); g.translate(-9,-0.5); g.beginPath(); g.rect(9,0.5,30,30); g.clip(); drawChar(g,s,0,1); g.restore();
  return c;
};

/* ---------- MONSTER (battler 160x160) ---------- */
const MON = R.MONSTER_KINDS = {};
function M(name,fn){ MON[name]=fn; }
function eyes(g,x,y,d,c){ circ(g,'#fff',x-d,y,5); circ(g,'#fff',x+d,y,5); circ(g,c||'#a8201a',x-d,y,2.6); circ(g,c||'#a8201a',x+d,y,2.6); }
M('Slime',(g,c)=>{ H.ell(g,'rgba(0,0,0,.25)',80,138,46,9); g.fillStyle=c; g.beginPath(); g.moveTo(26,132); g.bezierCurveTo(20,70,60,36,80,36); g.bezierCurveTo(100,36,140,70,134,132); g.closePath(); g.fill(); g.fillStyle='rgba(255,255,255,.35)'; g.beginPath(); g.ellipse(62,64,12,7,-.6,0,6.3); g.fill(); eyes(g,80,92,16,'#222'); line(g,'#222',72,108,88,108,3); });
M('Bat',(g,c)=>{ H.ell(g,'rgba(0,0,0,.2)',80,140,26,6); poly(g,shade(c,-.2),80,70,14,40,30,80,44,70,58,96); poly(g,shade(c,-.2),80,70,146,40,130,80,116,70,102,96); H.ell(g,c,80,84,22,26); poly(g,c,64,64,60,40,76,58); poly(g,c,96,64,100,40,84,58); eyes(g,80,80,9,'#e8d03a'); poly(g,'#fff',74,96,77,104,80,96); poly(g,'#fff',80,96,83,104,86,96); });
M('Goblin',(g,c)=>{ H.ell(g,'rgba(0,0,0,.25)',80,144,34,7); rect(g,'#6b4423',58,88,44,42); rect(g,shade(c,-.2),50,118,22,24); rect(g,shade(c,-.2),88,118,22,24); circ(g,c,80,64,26); poly(g,c,56,60,30,48,56,74); poly(g,c,104,60,130,48,104,74); eyes(g,80,60,11,'#d9a01a'); poly(g,'#fff',68,80,72,90,76,80); poly(g,'#fff',84,80,88,90,92,80); line(g,'#6b4423',112,70,132,120,7); circ(g,'#8a8a94',112,66,10); });
M('Skeleton',(g,c)=>{ H.ell(g,'rgba(0,0,0,.25)',80,144,30,6); const b='#ece8d8'; rr(g,b,66,24,28,30,10); circ(g,'#1a1a22',74,40,6); circ(g,'#1a1a22',86,40,6); rect(g,b,70,52,20,8); for(let i=0;i<4;i++) line(g,'#1a1a22',72+i*5,52,72+i*5,60,1.5); rect(g,b,76,60,8,50); for(let y=68;y<104;y+=9) rr(g,b,56,y,48,5,2); rect(g,b,60,110,8,32); rect(g,b,92,110,8,32); line(g,b,56,70,34,104,6); line(g,b,104,70,128,48,6); line(g,'#c9ccd4',128,20,128,64,6); });
M('Wolf',(g,c)=>{ H.ell(g,'rgba(0,0,0,.25)',80,144,50,7); H.ell(g,c,76,100,44,26); rect(g,shade(c,-.15),40,110,10,30); rect(g,shade(c,-.15),60,114,10,28); rect(g,shade(c,-.15),92,114,10,28); rect(g,shade(c,-.15),108,110,10,30); poly(g,c,30,92,12,60,40,80); circ(g,c,112,76,22); poly(g,c,98,62,98,36,112,56); poly(g,c,122,58,130,36,132,66); poly(g,shade(c,-.2),120,80,146,86,122,96); eyes(g,114,72,5,'#e8c03a'); circ(g,'#222',144,86,3); });
M('Spider',(g,c)=>{ H.ell(g,'rgba(0,0,0,.2)',80,144,44,6); for(let i=0;i<4;i++){ const y=64+i*12; line(g,shade(c,-.1),64,y,18,y-24+i*10,5); line(g,shade(c,-.1),96,y,142,y-24+i*10,5); } H.ell(g,c,80,96,28,32); H.ell(g,shade(c,.1),80,62,18,16); circ(g,'#d9433a',72,58,4); circ(g,'#d9433a',88,58,4); circ(g,'#d9433a',80,66,3); poly(g,'#e8d03a',80,86,74,108,86,108); });
M('Ghost',(g,c)=>{ g.globalAlpha=.88; g.fillStyle=c; g.beginPath(); g.moveTo(40,130); g.lineTo(40,64); g.bezierCurveTo(40,20,120,20,120,64); g.lineTo(120,130); for(let i=0;i<4;i++) g.quadraticCurveTo(114-i*20,112,100-i*20,130); g.fill(); g.globalAlpha=1; circ(g,'#222',68,64,8); circ(g,'#222',92,64,8); H.ell(g,'#222',80,88,8,12); });
M('Mushroom',(g,c)=>{ H.ell(g,'rgba(0,0,0,.25)',80,144,36,6); rr(g,'#f0e6d0',58,76,44,60,16); H.ell(g,c,80,64,58,40); circ(g,'#fff',54,52,8); circ(g,'#fff',100,56,9); circ(g,'#fff',78,38,6); circ(g,'#222',68,100,4); circ(g,'#222',92,100,4); line(g,'#222',72,114,88,114,3); });
M('Golem',(g,c)=>{ H.ell(g,'rgba(0,0,0,.3)',80,146,52,8); rr(g,shade(c,-.1),48,70,64,60,8); rr(g,c,52,74,56,40,6); rr(g,c,58,28,44,40,8); rr(g,shade(c,-.15),14,70,30,48,8); rr(g,shade(c,-.15),116,70,30,48,8); rr(g,shade(c,-.2),52,128,22,18,4); rr(g,shade(c,-.2),86,128,22,18,4); rect(g,'#d9a01a',64,44,12,8); rect(g,'#d9a01a',84,44,12,8); line(g,shade(c,-.4),70,80,84,100,3); line(g,shade(c,-.4),90,76,78,92,3); });
M('Dragon',(g,c)=>{ H.ell(g,'rgba(0,0,0,.3)',80,148,60,8); poly(g,shade(c,-.25),70,70,6,20,22,66,34,50,46,86); poly(g,shade(c,-.25),90,70,154,20,138,66,126,50,114,86); H.ell(g,c,80,100,38,40); H.ell(g,shade(c,.3),80,108,20,28); rect(g,shade(c,-.1),50,128,18,20); rect(g,shade(c,-.1),92,128,18,20); poly(g,c,60,96,20,130,24,140,60,120); rr(g,c,66,22,28,38,14); poly(g,c,66,34,52,8,72,28); poly(g,c,94,34,108,8,88,28); eyes(g,80,40,8,'#ffd03a'); poly(g,'#fff',72,58,75,66,78,58); poly(g,'#fff',82,58,85,66,88,58); circ(g,'#222',76,50,1.8); circ(g,'#222',84,50,1.8); });
M('Imp',(g,c)=>{ H.ell(g,'rgba(0,0,0,.25)',80,144,26,6); poly(g,shade(c,-.2),64,70,30,44,44,86,58,84); poly(g,shade(c,-.2),96,70,130,44,116,86,102,84); H.ell(g,c,80,96,20,30); circ(g,c,80,56,20); poly(g,c,64,44,56,22,72,38); poly(g,c,96,44,104,22,88,38); eyes(g,80,54,8,'#e8d03a'); line(g,'#222',72,68,88,68,3); line(g,c,98,110,126,124,4); poly(g,c,126,124,136,114,134,132); });
M('Knight',(g,c)=>{ H.ell(g,'rgba(0,0,0,.3)',80,146,34,7); rr(g,c,56,62,48,56,8); rect(g,shade(c,-.25),56,100,48,8); rr(g,shade(c,-.1),54,118,22,26,4); rr(g,shade(c,-.1),84,118,22,26,4); circ(g,c,50,70,11); circ(g,c,110,70,11); rr(g,c,62,20,36,40,12); rect(g,'#222',68,36,24,4); rect(g,'#d9433a',78,6,4,16); line(g,'#c9ccd4',122,16,122,110,6); rect(g,'#6b4423',112,96,22,5); rr(g,'#a8353f',24,66,28,40,8); });
M('Snake',(g,c)=>{ H.ell(g,'rgba(0,0,0,.2)',80,144,50,6); g.strokeStyle=c; g.lineWidth=18; g.lineCap='round'; g.beginPath(); g.moveTo(24,130); g.bezierCurveTo(70,150,60,100,100,110); g.bezierCurveTo(140,120,130,70,96,64); g.stroke(); circ(g,c,96,56,16); eyes(g,96,52,6,'#e8d03a'); line(g,'#d9433a',104,66,122,64,2); });
M('Scorpion',(g,c)=>{ H.ell(g,'rgba(0,0,0,.2)',80,144,46,6); H.ell(g,c,72,108,34,18); for(let i=0;i<3;i++){ line(g,shade(c,-.2),52+i*16,116,44+i*16,138,4); } g.strokeStyle=c; g.lineWidth=9; g.lineCap='round'; g.beginPath(); g.moveTo(100,104); g.bezierCurveTo(144,100,140,50,112,44); g.stroke(); poly(g,'#d9433a',112,44,122,34,118,54); line(g,c,44,98,22,84,7); circ(g,c,20,82,9); line(g,c,44,110,18,114,7); circ(g,c,16,114,9); eyes(g,48,100,6,'#111'); });
M('Fire Elemental',(g,c)=>{ for(let i=0;i<3;i++){ const col=['#e8601a','#ffa63a','#ffe27a'][i], s=1-i*.25; poly(g,col,80,12+i*20,80+50*s,120,80-50*s,120); circ(g,col,80,118,48*s); poly(g,col,52,70,40,30,66,60); poly(g,col,108,70,120,30,94,60);} eyes(g,80,92,13,'#222'); line(g,'#222',70,112,90,112,4); });
M('Treant',(g,c)=>{ H.ell(g,'rgba(0,0,0,.3)',80,148,44,7); rect(g,'#6b4423',60,64,40,78); rect(g,'#553419',60,64,10,78); poly(g,'#6b4423',60,134,42,148,66,148); poly(g,'#6b4423',100,134,118,148,94,148); line(g,'#6b4423',60,80,22,60,9); line(g,'#6b4423',100,80,138,60,9); circ(g,c,80,36,34); circ(g,shade(c,.2),64,28,16); circ(g,c,40,52,18); circ(g,c,120,52,18); circ(g,'#e8d03a',72,86,5); circ(g,'#e8d03a',88,86,5); line(g,'#2a1a0a',70,106,90,106,4); });

R.makeMonster = function(kind,color){
  if(typeof kind==='string'&&/^img\//.test(kind)){ /* gambar kustom (battler impor) */
    const c=document.createElement('canvas'); c.width=c.height=160; const im=R.loadImage(kind);
    if(im){ const k=Math.min(160/im.width,160/im.height); const w=im.width*k,h=im.height*k; c.getContext('2d').drawImage(im,(160-w)/2,160-h,w,h); }
    else { R.__monRetry=R.__monRetry||{}; }
    return c; }
  return R.makeMonster0(kind,color); };
R.makeMonster0 = function(kind,color){
  const fn = MON[kind] || MON.Slime;
  const c = mk(160,160), g = c.getContext('2d'); fn(g,color||'#6ab04c'); return c;
};
R.MONSTER_DEFAULT_COLORS = {Slime:'#5ab34a',Bat:'#6a4a8a',Goblin:'#7aa83a',Skeleton:'#ece8d8',Wolf:'#7a7a88',Spider:'#4a3a4a',Ghost:'#d8e4f4',Mushroom:'#c0462f',Golem:'#8a8478',Dragon:'#b8383a',Imp:'#c0462f',Knight:'#8d909a',Snake:'#5a9a4a',Scorpion:'#b88a3a','Fire Elemental':'#e8601a',Treant:'#3a8a3a'};
})();
