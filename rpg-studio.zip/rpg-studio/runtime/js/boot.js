/* Boot: scene manager, loop utama, pemuatan proyek */
(function(){
'use strict';
const R = window.RPG, W=816, Hh=624;
R.SM = {
  stack:[],
  top(){ return this.stack[this.stack.length-1]; },
  push(s){ this.stack.push(s); R.Input.flush(); if(s.start) s.start(); },
  pop(){ this.stack.pop(); R.Input.flush(); },
  goto(s){ this.stack.length=0; this.stack.push(s); R.Input.flush(); if(s.start) s.start(); if(s instanceof R.Scene_Map) R.$scene=s; },
  update(){ const t=this.top(); if(t) t.update(); },
  draw(g){ const t=this.top(); if(!t) return; if(t.overlay&&this.stack.length>1) { this.stack[this.stack.length-2].draw(g); } t.draw(g); }
};
R.boot = function(opts){
  opts=opts||{};
  let lsDb=null; try{ if(/[?&]play=[12]/.test(location.search)){ const t=localStorage.getItem('rpgstudio.play'); if(t){ lsDb=JSON.parse(t); if(/[?&]play=2/.test(location.search)) opts=Object.assign({},opts,{testPlay:true,startMap:lsDb.system.startMap,startX:lsDb.system.startX,startY:lsDb.system.startY}); } } }catch(e){}
  const db = lsDb || window.PROJECT || (R.buildDemo? R.buildDemo() : null);
  if(!db){ document.body.innerHTML='<p style="color:#fff;padding:20px">No project data found (data/project.js).</p>'; return; }
  R.$db = db; if(R.registerCustomTiles) R.registerCustomTiles(db); R.assetBase = opts.assetBase||'';
  const sys=db.system; document.title=sys.title||'RPG';
  const cv=document.getElementById('screen'); cv.width=W; cv.height=Hh; const g=cv.getContext('2d'); R._g=g;
  const fit=()=>{ const s=Math.min(window.innerWidth/W,window.innerHeight/Hh); cv.style.width=Math.floor(W*s)+'px'; cv.style.height=Math.floor(Hh*s)+'px'; };
  window.addEventListener('resize',fit); fit();
  R.Input.bind(window);
  const toLocal=e=>{ const r=cv.getBoundingClientRect(); return {x:(e.clientX-r.left)*W/r.width,y:(e.clientY-r.top)*Hh/r.height}; };
  cv.addEventListener('mousemove',e=>{ const p=toLocal(e); R.Input.mouse.x=p.x; R.Input.mouse.y=p.y; R.Input.mouse.moved=true; });
  cv.addEventListener('mousedown',e=>{ const p=toLocal(e); R.Input.mouse.x=p.x; R.Input.mouse.y=p.y; R.Input.mouse.click=true; R.Input.mouse.down=true; R.Audio.init(); if(e.button===2){ R.Input.trig.cancel=true; } });
  cv.addEventListener('mouseup',()=>{ R.Input.mouse.down=false; });
  cv.addEventListener('contextmenu',e=>e.preventDefault());
  cv.addEventListener('touchstart',e=>{ const t=e.touches[0]; const p=toLocal(t); R.Input.mouse.x=p.x; R.Input.mouse.y=p.y; R.Input.mouse.click=true; R.Audio.init(); },{passive:true});
  window.addEventListener('keydown',()=>R.Audio.init());
  R.onF11=()=>{ try{ if(document.fullscreenElement) document.exitFullscreen(); else document.documentElement.requestFullscreen(); }catch(e){} };
  R.$game = new R.Game();
  const startScene = opts.testPlay ? null : new R.Scene_Title();
  if(opts.testPlay){ R.$game.setupNew(); if(opts.startMap){ R.$game.mapId=opts.startMap; R.$game.px=opts.startX; R.$game.py=opts.startY; } const sc=new R.Scene_Map(); R.SM.goto(sc); R.$scene=sc; sc.start(); }
  else R.SM.goto(startScene);
  let last=performance.now(), acc=0; const STEP=1000/60;
  function frame(now){ acc+=Math.min(100,now-last); last=now; let n=0; while(acc>=STEP&&n<5){ R.Input.update(); try{ R.SM.update(); }catch(e){ console.error(e); } acc-=STEP; n++; } if(acc>STEP*5) acc=0; try{ R.SM.draw(g); }catch(e){ console.error(e); } requestAnimationFrame(frame); }
  requestAnimationFrame(frame);
  R.running=true;
};
})();
