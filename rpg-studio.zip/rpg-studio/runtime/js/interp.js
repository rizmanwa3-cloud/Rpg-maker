/* Interpreter perintah event (generator) */
(function(){
'use strict';
const R = window.RPG;
const cmpOp = (a,op,b)=>{ switch(op){ case '==':return a===b; case '>=':return a>=b; case '<=':return a<=b; case '>':return a>a?false:a>b; case '<':return a<b; case '!=':return a!==b; } return false; };

R.Interp = class {
  constructor(sm){ this.sm=sm; this.depth=0; }
  findEnd(list,from,codes,indent){ for(let i=from;i<list.length;i++){ const c=list[i]; if(c.i===indent&&codes.includes(c.c)) return i; if(c.i<indent) break; } return list.length; }
  *run(list,ctx){ if(!list) return; ctx=ctx||{}; ctx.labels=ctx.labels||null; if(this.depth>12) return; this.depth++; try{ let i=0; const g=R.$game, sm=this.sm;
    while(i<list.length){ const c=list[i]; if(this.sm.abortEvents){ break; }
      switch(c.c){
        case 'empty': case 'comment': case 'label': case 'endif': case 'endchoices': case 'endloop': case 'endbattle': break;
        case 'text': yield* sm.showText(c,ctx); break;
        case 'scrolltext': yield* sm.scrollText(c); break;
        case 'choices': { const n=(c.opts||[]).length; let idx=yield* sm.showChoices(c); if(idx<0){ idx=(c.cancel===1)? -2 : (c.cancel>=2? Math.min(n-1,c.cancel-2) : 0); } let j=i+1; let found=-1; for(;j<list.length;j++){ const d=list[j]; if(d.i===c.i&&d.c==='when'&&d.idx===idx){ found=j; break; } if(d.i===c.i&&d.c==='endchoices') break; } i = found>=0? found : this.findEnd(list,i+1,['endchoices'],c.i); break; }
        case 'when': i=this.findEnd(list,i+1,['endchoices'],c.i); break;
        case 'numinput': yield* sm.numInput(c); break;
        case 'selitem': yield* sm.selectKeyItem(c); break;
        case 'if': { const ok=this.cond(c,ctx); if(!ok){ const j=this.findEnd(list,i+1,['else','endif'],c.i); i=j; } break; }
        case 'else': i=this.findEnd(list,i+1,['endif'],c.i); break;
        case 'loop': break;
        case 'endloop': { let j=i-1; while(j>=0&&!(list[j].c==='loop'&&list[j].i===c.i)) j--; i=j; yield 1; break; }
        case 'break': { let j=i+1; while(j<list.length&&!(list[j].c==='endloop'&&list[j].i<c.i)) j++; i=j; break; }
        case 'exit': return;
        case 'goto': { const j=list.findIndex(d=>d.c==='label'&&d.name===c.name); if(j>=0) i=j; break; }
        case 'playscene': yield* R.Action.sceneGen(sm,c.scene); break;
        case 'common': { const ce=R.$db.commonEvents[c.id-1]; if(ce) yield* this.run(ce.list,{eventId:0,evt:null,common:true}); break; }
        case 'wait': yield c.frames; break;
        case 'setswitch': for(let k=c.a;k<=Math.max(c.a,c.a2||c.a);k++){ g.setS(k,c.val==='toggle'?!g.s(k):c.val==='on'); } sm.map.needRefresh=true; break;
        case 'setvar': this.setVar(c); sm.map.needRefresh=true; break;
        case 'setself': if(ctx.evt){ const k=g.selfKey(sm.map.id,ctx.evt.id,c.key); g.selfSw[k]=c.val==='toggle'?!g.selfSw[k]:c.val==='on'; sm.map.needRefresh=true; } break;
        case 'gold': g.gainGold(c.op==='+'?c.v:-c.v); break;
        case 'item': g.gainItem(c.kind,c.id,c.op==='+'?c.n:-c.n); sm.map.needRefresh=true; break;
        case 'partymember': if(c.op==='add') g.addParty(c.actor,c.init); else g.removeParty(c.actor); sm.refreshFollowers(); sm.map.needRefresh=true; break;
        case 'hp': for(const a of this.targets(c.target)){ if(a.isDead()&&c.op==='+') continue; a.gainHp(c.op==='+'?c.v:-c.v); if(c.op==='-'&&!c.death&&a.hp<=0){ a.states=a.states.filter(s=>s.id!==1); a.hp=1; } } break;
        case 'mp': for(const a of this.targets(c.target)) a.gainMp(c.op==='+'?c.v:-c.v); break;
        case 'state': for(const a of this.targets(c.target)){ if(c.op==='add') a.addState(c.state); else a.removeState(c.state); } break;
        case 'recover': for(const a of this.targets(c.target)) a.recoverAll(); break;
        case 'exp': for(const a of this.targets(c.target)){ const res=a.gainExp(c.op==='+'?c.v:-c.v); if(c.show) for(const l of res){ R.Audio.se('Level Up'); yield* sm.showText({face:a.img,pos:'bottom',bg:'window',text:R.$db.system.terms.levelUp.replace('%s',a.name).replace('%s',l.level)},ctx); } } break;
        case 'level': for(const a of this.targets(c.target)) a.changeLevel(a.level+(c.op==='+'?c.v:-c.v)); break;
        case 'skill': { const a=g.actor(c.target); if(c.op==='learn'){ if(!a.skills.includes(c.skill)) a.skills.push(c.skill); } else a.skills=a.skills.filter(s=>s!==c.skill); break; }
        case 'name': g.actor(c.actor).name=c.name; break;
        case 'class': { const a=g.actor(c.actor); a.cls=c.cls; a.learnForLevel(); a.hp=Math.min(a.hp,a.mhp); a.mp=Math.min(a.mp,a.mmp); break; }
        case 'actorimage': { const a=g.actor(c.actor); a.img=c.img; sm.refreshFollowers(); break; }
        case 'nameinput': yield* sm.nameInput(c); break;
        case 'transfer': { let m=c.map,x=c.x,y=c.y; if(c.mode==='variables'){ m=g.v(c.map); x=g.v(c.x); y=g.v(c.y); } yield* sm.transfer(m,x,y,c.dir,c.fade); if(ctx.evt) ctx.moved=true; break; }
        case 'setevtloc': { const ch=sm.getChar(c.event,ctx); if(!ch) break; if(c.mode==='exchange'){ const o=sm.map.evById[c.x]; if(o){ const ox=o.x,oy=o.y; o.setPos(ch.x,ch.y); ch.setPos(ox,oy); } } else { let x=c.x,y=c.y; if(c.mode==='variables'){ x=g.v(c.x); y=g.v(c.y); } ch.setPos(x,y); if(c.dir) ch.dir=c.dir; if(ch===sm.player) sm.afterTeleport(); } break; }
        case 'moveroute': { const ch=sm.getChar(c.target,ctx); if(ch){ ch.forceRoute(c.route||[],c.repeat); if(c.wait&&!c.repeat){ while(!ch.routeDone&&!sm.abortEvents) yield; } } break; }
        case 'transparent': g.transparent=c.val==='on'; sm.player.transparent=g.transparent; break;
        case 'followers': g.followers=c.val==='on'; sm.refreshFollowers(); break;
        case 'erase': if(ctx.evt){ ctx.evt.erased=true; g.erased[sm.map.id+','+ctx.evt.id]=1; ctx.evt.refresh(); ctx.erased=true; return; } break;
        case 'fadeout': yield* sm.fade(1,24); break;
        case 'fadein': yield* sm.fade(0,24); break;
        case 'tint': sm.tintTo([c.r,c.g,c.b,c.gray],c.frames); if(c.wait) yield c.frames; break;
        case 'flash': sm.flashT={color:c.color,t:0,dur:c.frames}; if(c.wait) yield c.frames; break;
        case 'shake': sm.shakeFx={p:c.power,s:c.speed,t:0,dur:c.frames}; if(c.wait) yield c.frames; break;
        case 'weather': g.weather={type:c.type,power:c.power}; sm.setWeather(); break;
        case 'showpic': g.pictures[c.id]={name:c.name,x:c.x,y:c.y,scale:c.scale,opacity:c.opacity}; break;
        case 'movepic': { const p=g.pictures[c.id]; if(p){ sm.picMove={id:c.id,from:Object.assign({},p),to:{x:c.x,y:c.y,scale:c.scale,opacity:c.opacity},t:0,dur:c.frames}; if(c.wait) yield c.frames; } break; }
        case 'erasepic': delete g.pictures[c.id]; break;
        case 'animation': { const ch=sm.getChar(c.target,ctx); if(ch){ sm.addAnim(ch,c.anim); if(c.wait) yield 26; } break; }
        case 'balloon': { const ch=sm.getChar(c.target,ctx); const ix=['Exclamation','Question','Music','Heart','Anger','Sweat','Frustration','Silence','Light bulb','Zzz'].indexOf(c.icon); if(ch){ ch.balloon={icon:Math.max(0,ix),t:0,dur:48}; if(c.wait) yield 48; } break; }
        case 'playbgm': R.Audio.vol.bgm=(c.vol===undefined?100:c.vol)/100*.5; g.bgmName=c.name; R.Audio.playBgm(c.name); break;
        case 'fadebgm': R.Audio.stopBgm(); break;
        case 'stopbgm': R.Audio.stopBgm(); break;
        case 'playse': R.Audio.se(c.name,(c.vol===undefined?100:c.vol)/100); break;
        case 'battle': { let id=c.id; if(c.kind==='variable') id=g.v(c.id); else if(c.kind==='random'){ const en=sm.map.data.encounters||[]; if(en.length) id=en[Math.floor(Math.random()*en.length)].troop; }
          const res=yield* sm.startBattle(id,{escape:c.escape,lose:c.lose}); let want=res===0?'ifwin':res===1?'ifescape':'iflose'; let j=i+1,found=-1; for(;j<list.length;j++){ const d=list[j]; if(d.i===c.i&&d.c===want){ found=j; break; } if(d.i===c.i&&d.c==='endbattle') break; } if(res===2&&!c.lose&&found<0){ yield* sm.gameOver(); return; } i=found>=0?found:this.findEnd(list,i+1,['endbattle'],c.i); break; }
        case 'ifwin': case 'ifescape': case 'iflose': i=this.findEnd(list,i+1,['endbattle'],c.i); break;
        case 'shop': yield* sm.openShop(c.goods||[],c.buyOnly); break;
        case 'menu': yield* sm.openMenuScene(); break;
        case 'save': yield* sm.openSaveScene(); break;
        case 'gameover': yield* sm.gameOver(); return;
        case 'title': sm.toTitle(); return;
        case 'sysopt': g.flags[c.key]=(c.val==='on'); break;
        case 'script': try{ const fn=new Function('$game','$v','$s','$map','$player','$event','R','sm','return (function*(){'+c.s+'\n})();'); const it=fn(g,n=>g.v(n),n=>g.s(n),sm.map,sm.player,ctx.evt,R,sm); if(it&&it.next) yield* it; }catch(e){ console.warn('script error',e); } break;
      }
      i++; }
  } finally { this.depth--; } }
  targets(t){ const g=R.$game; return t?[g.actor(t)]:g.party.slice(); }
  cond(c,ctx){ const g=R.$game, sm=this.sm; switch(c.kind){
    case 'switch': return g.s(c.a)===(c.b==='on'||c.b===true);
    case 'variable': { const v=g.v(c.a), b=c.cmp==='variable'?g.v(c.b):Number(c.b); return cmpOp(v,c.op||'==',b); }
    case 'selfswitch': if(!ctx.evt) return false; return !!g.selfSw[g.selfKey(sm.map.id,ctx.evt.id,c.a)]===(c.b==='on');
    case 'gold': return cmpOp(g.gold,c.op||'>=',Number(c.b));
    case 'item': case 'weapon': case 'armor': return g.numItems(c.kind,c.a)>0;
    case 'actor': return g.party.some(a=>a.id===+c.a);
    case 'direction': return sm.player.dir===+c.a;
    case 'button': return R.Input.isDown(c.a==='ok'||c.a==='cancel'||c.a==='shift'||c.a==='up'||c.a==='down'||c.a==='left'||c.a==='right'?c.a:'ok');
    case 'script': try{ return !!new Function('$game','$v','$s','$map','$player','$event','R','return ('+c.a+');')(g,n=>g.v(n),n=>g.s(n),sm.map,sm.player,ctx.evt,R); }catch(e){ return false; }
  } return false; }
  setVar(c){ const g=R.$game, sm=this.sm; for(let k=c.a;k<=Math.max(c.a,c.a2||c.a);k++){ let val=0; switch(c.src){ case 'constant': val=Number(c.v)||0; break; case 'variable': val=g.v(c.v); break; case 'random': val=(+c.v)+Math.floor(Math.random()*((+c.v2)-(+c.v)+1)); break; case 'item count': val=g.numItems('item',c.v); break; case 'gold': val=g.gold; break; case 'steps': val=g.steps; break; case 'playtime': val=Math.floor(g.frames/60); break; case 'map id': val=sm.map.id; break; case 'party size': val=g.party.length; break; case 'player x': val=sm.player.x; break; case 'player y': val=sm.player.y; break; case 'script': try{ val=Number(new Function('$game','$v','$s','$map','$player','R','return ('+c.v+');')(g,n=>g.v(n),n=>g.s(n),sm.map,sm.player,R))||0; }catch(e){ val=0; } }
    const cur=g.v(k); let nv=val; switch(c.op){ case '+=': nv=cur+val; break; case '-=': nv=cur-val; break; case '*=': nv=cur*val; break; case '/=': nv=val?Math.floor(cur/val):cur; break; case '%=': nv=val?cur%val:cur; break; } g.setV(k,nv); } }
};
})();
