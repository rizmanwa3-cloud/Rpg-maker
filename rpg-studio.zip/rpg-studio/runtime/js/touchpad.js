/* Kontrol sentuh: joystick virtual + tombol OK / Batal / Lari. Muncul otomatis di perangkat layar sentuh. */
(function(){
'use strict';
const R=window.RPG;
const isTouch=('ontouchstart' in window)||navigator.maxTouchPoints>0||/[?&]touch=1/.test(location.search);
if(!isTouch||/[?&]touch=0/.test(location.search)) return;
const Inp=R.Input;
function setAct(a,on){ if(on&&!Inp.down[a]){ Inp.trig[a]=true; Inp.rep[a]=0; } Inp.down[a]=on; if(on&&R.Audio&&R.Audio.init) R.Audio.init(); }
const css=document.createElement('style');
css.textContent=`
#tp{position:fixed;inset:0;pointer-events:none;z-index:50;touch-action:none;-webkit-user-select:none;user-select:none}
#tp .pad{position:absolute;left:max(18px,env(safe-area-inset-left));bottom:max(22px,env(safe-area-inset-bottom));width:150px;height:150px;border-radius:50%;background:rgba(255,255,255,.10);border:2px solid rgba(255,255,255,.28);pointer-events:auto;touch-action:none}
#tp .knob{position:absolute;left:50%;top:50%;width:64px;height:64px;margin:-32px 0 0 -32px;border-radius:50%;background:rgba(255,255,255,.35);border:2px solid rgba(255,255,255,.6)}
#tp .btn{position:absolute;width:68px;height:68px;border-radius:50%;background:rgba(255,255,255,.14);border:2px solid rgba(255,255,255,.35);color:#fff;font:700 20px sans-serif;display:flex;align-items:center;justify-content:center;pointer-events:auto;touch-action:none}
#tp .btn.on{background:rgba(120,170,255,.55)}
#tp .a{right:max(22px,env(safe-area-inset-right));bottom:max(70px,env(safe-area-inset-bottom))}
#tp .b{right:max(104px,env(safe-area-inset-right));bottom:max(28px,env(safe-area-inset-bottom))}
#tp .act{display:none}#tp .atk{right:max(104px,env(safe-area-inset-right));bottom:max(110px,env(safe-area-inset-bottom));width:80px;height:80px;background:rgba(255,120,100,.25);border-color:rgba(255,160,140,.6)}#tp .skl{right:max(190px,env(safe-area-inset-right));bottom:max(60px,env(safe-area-inset-bottom));width:56px;height:56px;font-size:14px}#tp .sw{right:max(190px,env(safe-area-inset-right));bottom:max(126px,env(safe-area-inset-bottom));width:40px;height:40px;font-size:14px}
#tp .d{right:max(22px,env(safe-area-inset-right));bottom:max(152px,env(safe-area-inset-bottom));width:52px;height:52px;font-size:14px}
`;
document.head.append(css);
const root=document.createElement('div'); root.id='tp';
root.innerHTML='<div class="pad"><div class="knob"></div></div><div class="btn a" data-a="ok">OK</div><div class="btn b" data-a="cancel">X</div><div class="btn d" data-a="shift">RUN</div><div class="btn act atk" data-a="attack">ATK</div><div class="btn act skl" data-a="skill">SKL</div><div class="btn act sw" data-a="pgdn">&#9654;</div>';
document.body.append(root);
const pad=root.querySelector('.pad'), knob=root.querySelector('.knob');
let padId=null;
function dirFrom(e){ const r=pad.getBoundingClientRect(); const cx=r.left+r.width/2, cy=r.top+r.height/2; let dx=e.clientX-cx, dy=e.clientY-cy; const max=r.width/2; const len=Math.hypot(dx,dy); if(len>max){ dx*=max/len; dy*=max/len; } knob.style.transform='translate('+dx+'px,'+dy+'px)'; Inp.analog={x:dx/max,y:dy/max}; const dz=max*.28; const ax=Math.abs(dx), ay=Math.abs(dy); let h=0,v=0; if(Math.max(ax,ay)>dz){ if(ax>ay) h=dx>0?1:-1; else v=dy>0?1:-1; } setAct('left',h<0); setAct('right',h>0); setAct('up',v<0); setAct('down',v>0); }
function release(){ Inp.analog=null; padId=null; knob.style.transform=''; ['left','right','up','down'].forEach(a=>setAct(a,false)); }
pad.addEventListener('pointerdown',e=>{ e.preventDefault(); padId=e.pointerId; try{ pad.setPointerCapture(e.pointerId); }catch(x){} dirFrom(e); });
pad.addEventListener('pointermove',e=>{ if(e.pointerId===padId) dirFrom(e); });
['pointerup','pointercancel','lostpointercapture'].forEach(t=>pad.addEventListener(t,e=>{ if(e.pointerId===padId) release(); }));
root.querySelectorAll('.btn').forEach(b=>{ const a=b.dataset.a, acts=a==='cancel'?['cancel','menu']:[a]; let id=null; b.addEventListener('pointerdown',e=>{ e.preventDefault(); id=e.pointerId; try{ b.setPointerCapture(id); }catch(x){} b.classList.add('on'); acts.forEach(x=>setAct(x,true)); }); ['pointerup','pointercancel'].forEach(t=>b.addEventListener(t,e=>{ if(e.pointerId!==id) return; id=null; b.classList.remove('on'); acts.forEach(x=>setAct(x,false)); })); });
R.applyTouchLayout=function(){ const c=R.uiCfg&&R.uiCfg(); const t=c&&c.touch, k0=(c&&c.touchScale)||1; root.querySelectorAll('.btn,.pad').forEach(el=>{ const k=el.dataset.a||'pad'; const p=t&&t[k]; if(p){ el.style.right='auto'; el.style.bottom='auto'; el.style.left=(p.x*100)+'%'; el.style.top=(p.y*100)+'%'; el.style.transform='translate(-50%,-50%) scale('+k0+')'; } else { el.style.left=el.style.top=el.style.right=el.style.bottom=el.style.transform=''; } }); };
if(R.uiCfg) R.applyTouchLayout();
window.addEventListener('blur',release);
setInterval(()=>{ const on=R.Action&&R.Action.isOn&&R.Action.isOn(); root.querySelectorAll('.act').forEach(b=>{ b.style.display=on?'flex':'none'; }); },500);
document.addEventListener('contextmenu',e=>e.preventDefault());
})();
