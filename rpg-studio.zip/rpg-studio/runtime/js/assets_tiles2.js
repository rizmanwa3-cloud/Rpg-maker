/* Bagian 2: tile Interior (C), Town (D), Dungeon (E) */
(function(){
'use strict';
const R = window.RPG, H = R.H, D = R.D_TILE, shade = R.shade;
const {fill,rect,circ,ell,poly,line,rr,shadow} = H;

// ----- INTERIOR (C)
const I = (name,o,fn)=>D(name,'C',Object.assign({layer:2,pass:false},o||{}),fn);
I('Wall Wood',{layer:1},(g)=>{ fill(g,'#8a5a30'); for(let i=0;i<4;i++){ rect(g,'#9c6b38',i*12+1,0,10,48); line(g,'#5c3a1a',i*12,0,i*12,48,1.5);} rect(g,'#5c3a1a',0,40,48,8); rect(g,'#b88348',0,0,48,3); });
I('Wall Plaster',{layer:1},(g)=>{ fill(g,'#e8dcc4'); rect(g,'#d6c8aa',0,38,48,10); rect(g,'#b8a888',0,36,48,3); for(let i=0;i<6;i++) rect(g,'#ddd0b6',6+i*8,8,2,4); });
I('Wall Stone',{layer:1},(g)=>{ fill(g,'#7d7d88'); for(let y=0;y<4;y++) for(let x=-1;x<3;x++){ rr(g,(x+y)%2?'#8c8c97':'#74747f',x*24+(y%2?12:0)+1,y*12+1,22,10,2);} rect(g,'#5e5e68',0,0,48,3); });
I('Wall Top',{layer:1},(g)=>{ fill(g,'#4a3a2c'); rect(g,'#5e4a38',0,0,48,6); rect(g,'#382a1e',0,42,48,6); });
I('Table',{},(g)=>{ shadow(g,24,43,20,4); rect(g,'#6b4423',6,30,5,14); rect(g,'#6b4423',37,30,5,14); rr(g,'#a67c45',2,18,44,16,3); rect(g,'#c49a60',2,18,44,4); });
I('Round Table',{},(g)=>{ shadow(g,24,43,18,4); rect(g,'#6b4423',21,28,6,15); ell(g,'#a67c45',24,26,20,11); ell(g,'#c49a60',24,24,20,10); });
I('Chair',{},(g)=>{ shadow(g,24,43,11,3); rect(g,'#7d5226',14,6,20,22); rect(g,'#9c6b38',16,8,16,16); rect(g,'#a67c45',12,26,24,6); rect(g,'#6b4423',13,32,4,11); rect(g,'#6b4423',31,32,4,11); });
I('Bed',{},(g)=>{ shadow(g,24,44,18,4); rr(g,'#6b4423',6,2,36,44,4); rr(g,'#f4f4f4',9,5,30,12,3); rr(g,'#4a7fe8',9,18,30,26,3); rect(g,'#3b66c4',9,18,30,5); });
I('Bookshelf',{},(g,r)=>{ rect(g,'#6b4423',2,2,44,44); rect(g,'#4a2f17',5,5,38,38); for(let s=0;s<3;s++){ rect(g,'#6b4423',5,5+s*13+11,38,3); let x=6; while(x<40){ const w=3+((x*7)%4); rect(g,['#c4443a','#3a6fc4','#4aa851','#e8c25a','#8a4ac4'][(x+s)%5],x,5+s*13+2,w,9); x+=w+1; } } });
I('Cabinet',{},(g)=>{ shadow(g,24,44,20,3); rr(g,'#8a5a30',4,6,40,38,3); rect(g,'#6b4423',22,8,2,34); circ(g,'#e8c25a',19,26,2); circ(g,'#e8c25a',29,26,2); rect(g,'#a67c45',4,6,40,4); });
I('Fireplace',{},(g,r,f)=>{ rect(g,'#6d6d75',2,4,44,42); rect(g,'#2a2a30',10,16,28,30); rect(g,'#8d8d96',0,4,48,8); poly(g,'#e8601a',24,18+f,34,44,14,44); poly(g,'#ffa63a',24,26,30,44,18,44); },{anim:true});
I('Window',{layer:1},(g)=>{ fill(g,'#e8dcc4'); rect(g,'#5c3a1a',8,6,32,32); rect(g,'#9bd0f0',11,9,26,26); line(g,'#5c3a1a',24,9,24,35,2.5); line(g,'#5c3a1a',11,22,37,22,2.5); rect(g,'rgba(255,255,255,.4)',13,11,8,5); });
I('Door',{layer:1,pass:true},(g)=>{ fill(g,'#e8dcc4'); rr(g,'#5c3a1a',8,2,32,46,3); rr(g,'#8a5a30',11,5,26,43,2); circ(g,'#e8c25a',32,28,2.5); line(g,'#6b4423',24,6,24,46,1.5); });
I('Rug',{layer:1,pass:true},(g)=>{ rr(g,'#a8353f',3,6,42,36,5); rr(g,'#e8c25a',7,10,34,28,3); rr(g,'#a8353f',10,13,28,22,3); poly(g,'#e8c25a',24,17,31,24,24,31,17,24); });
I('Barrel',{},(g)=>{ shadow(g,24,43,14,4); rr(g,'#8a5a30',10,8,28,34,8); line(g,'#4a3a2c',10,16,38,16,3); line(g,'#4a3a2c',10,32,38,32,3); ell(g,'#a67c45',24,9,14,4); });
I('Crate',{},(g)=>{ shadow(g,24,43,16,4); rect(g,'#a67c45',6,10,36,32); rect(g,'#7d5226',6,10,36,3); rect(g,'#7d5226',6,39,36,3); rect(g,'#7d5226',6,10,3,32); rect(g,'#7d5226',39,10,3,32); line(g,'#7d5226',6,10,42,42,3); });
I('Chest Closed',{},(g)=>{ shadow(g,24,42,16,4); rr(g,'#7d5226',6,22,36,20,3); rr(g,'#9c6b38',6,14,36,12,6); rect(g,'#e8c25a',6,24,36,3); rect(g,'#e8c25a',21,22,6,9); circ(g,'#3a2a1a',24,28,1.5); });
I('Chest Open',{},(g)=>{ shadow(g,24,42,16,4); rr(g,'#7d5226',6,24,36,18,3); rr(g,'#9c6b38',8,6,32,10,4); rect(g,'#5c3a1a',8,16,32,8); rect(g,'#e8c25a',6,26,36,3); rect(g,'#ffe27a',14,24,20,4); });
I('Pot',{},(g)=>{ shadow(g,24,43,11,3); rr(g,'#b0603a',12,16,24,26,9); rect(g,'#8a4528',12,14,24,5); rect(g,'#d98b5a',16,22,4,12); });
I('Plant Pot',{},(g)=>{ shadow(g,24,43,11,3); poly(g,'#b0603a',14,30,34,30,31,44,17,44); rect(g,'#8a4528',13,28,22,4); for(let a=-2;a<=2;a++) line(g,'#3f9a3a',24,28,24+a*7,8+Math.abs(a)*4,3); });
I('Lamp',{},(g)=>{ shadow(g,24,43,8,3); rect(g,'#4a3a2c',22,14,4,28); poly(g,'#e8c25a',14,16,34,16,29,4,19,4); circ(g,'rgba(255,230,140,.35)',24,12,14); });
I('Stairs Up',{pass:true},(g)=>{ fill(g,'#6d6d75'); for(let i=0;i<5;i++){ rect(g,shade('#8d8d96',i*.05),4,6+i*8,40,7); rect(g,'#4a4a52',4,12+i*8,40,2);} });
I('Stairs Down',{pass:true},(g)=>{ fill(g,'#2f2f38'); for(let i=0;i<5;i++){ rect(g,shade('#5e5e68',-i*.1),4+i*2,6+i*8,40-i*4,7);} });
I('Kitchen Stove',{},(g)=>{ shadow(g,24,44,18,3); rr(g,'#4a4a52',4,6,40,38,3); rect(g,'#2a2a30',8,10,32,14); circ(g,'#d9433a',16,17,4); circ(g,'#d9433a',32,17,4); rect(g,'#6d6d75',10,28,28,12); circ(g,'#e8c25a',24,34,2); });
I('Mirror',{layer:1},(g)=>{ fill(g,'#e8dcc4'); rr(g,'#b88348',10,4,28,40,8); rr(g,'#b9e2f5',13,7,22,34,6); line(g,'rgba(255,255,255,.8)',17,12,25,20,2); });
I('Painting',{layer:1},(g)=>{ fill(g,'#e8dcc4'); rect(g,'#7d5226',6,8,36,28); rect(g,'#7ab8e8',9,11,30,22); poly(g,'#4a9a4a',9,33,22,20,34,33); poly(g,'#6bb85b',20,33,32,24,39,33); circ(g,'#ffe27a',32,17,3); });
I('Curtain',{layer:1},(g)=>{ fill(g,'#e8dcc4'); rect(g,'#a8353f',2,2,18,40); rect(g,'#a8353f',28,2,18,40); for(let i=0;i<3;i++){ line(g,'#7d2530',6+i*5,4,6+i*5,40,1.5); line(g,'#7d2530',32+i*5,4,32+i*5,40,1.5);} rect(g,'#e8c25a',0,0,48,4); });

// ----- TOWN (D)
const Tn = (name,o,fn)=>D(name,'D',Object.assign({layer:2,pass:false},o||{}),fn);
const roof=(c)=>(g)=>{ fill(g,c); for(let y=0;y<4;y++){ rect(g,shade(c,y%2?-.08:.08),0,y*12,48,11); for(let x=0;x<48;x+=8) line(g,shade(c,-.3),x+(y%2?4:0),y*12,x+(y%2?4:0),y*12+11,1.5);} rect(g,shade(c,-.3),0,44,48,4); };
Tn('Roof Red',{layer:1},roof('#b8433a')); Tn('Roof Blue',{layer:1},roof('#3a5fb8')); Tn('Roof Brown',{layer:1},roof('#8a5a30')); Tn('Roof Gray',{layer:1},roof('#6d6d78')); Tn('Roof Green',{layer:1},roof('#3a8a4a'));
Tn('Wall House',{layer:1},(g)=>{ fill(g,'#e8d6a8'); for(let y=0;y<4;y++) line(g,'#c8b686',0,y*12+11,48,y*12+11,1.5); rect(g,'#b8a478',0,0,48,3); });
Tn('Wall Brick',{layer:1},(g)=>{ fill(g,'#a85a3a'); for(let y=0;y<4;y++) for(let x=-1;x<3;x++){ rr(g,(x+y)%2?'#b8664a':'#9c4e30',x*24+(y%2?12:0)+1,y*12+1,22,10,1);} });
Tn('Wall White',{layer:1},(g)=>{ fill(g,'#f0ece0'); rect(g,'#d8d2c0',0,40,48,8); rect(g,'#6b4423',0,0,4,48); rect(g,'#6b4423',44,0,4,48); line(g,'#6b4423',4,20,44,20,3); });
Tn('House Door',{layer:1,pass:true},(g)=>{ fill(g,'#e8d6a8'); rr(g,'#5c3a1a',8,2,32,46,3); rr(g,'#7d5226',11,5,26,43,2); circ(g,'#e8c25a',33,28,2.5); rect(g,'#b88348',8,2,32,3); });
Tn('House Window',{layer:1},(g)=>{ fill(g,'#e8d6a8'); rect(g,'#6b4423',8,8,32,28); rect(g,'#9bd0f0',11,11,26,22); line(g,'#6b4423',24,11,24,33,2.5); line(g,'#6b4423',11,22,37,22,2.5); rect(g,'#8a5a30',6,36,36,4); circ(g,'#e86a8a',14,34,3); circ(g,'#f5d23a',24,34,3); });
Tn('Shop Awning',{layer:1},(g)=>{ fill(g,'#e8d6a8'); for(let i=0;i<6;i++){ rect(g,i%2?'#f4f4f4':'#d9433a',i*8,6,8,22); poly(g,i%2?'#f4f4f4':'#d9433a',i*8,28,i*8+8,28,i*8+4,34);} rect(g,'#6b4423',0,2,48,5); });
Tn('Inn Sign',{layer:1},(g)=>{ fill(g,'#e8d6a8'); line(g,'#4a3a2c',6,10,40,10,3); rr(g,'#8a5a30',12,12,28,22,3); circ(g,'#f4f4f4',26,23,6); rect(g,'#f4f4f4',20,27,12,3); circ(g,'#8a5a30',26,23,3); });
Tn('Weapon Shop Sign',{layer:1},(g)=>{ fill(g,'#e8d6a8'); line(g,'#4a3a2c',6,10,42,10,3); rr(g,'#8a5a30',10,12,28,26,3); line(g,'#c9ccd4',16,32,32,16,3); line(g,'#c9ccd4',32,32,16,16,3); rect(g,'#6b4423',13,30,6,3); rect(g,'#6b4423',29,30,6,3); });
Tn('Item Shop Sign',{layer:1},(g)=>{ fill(g,'#e8d6a8'); line(g,'#4a3a2c',6,10,42,10,3); rr(g,'#8a5a30',10,12,28,26,3); rr(g,'#d9433a',18,22,12,14,5); rect(g,'#c9ccd4',21,17,6,6); });
Tn('Chimney',{},(g)=>{ rect(g,'#7a4a3a',16,10,16,36); rect(g,'#5c3a2c',14,6,20,6); circ(g,'rgba(200,200,210,.6)',24,0,6); });
Tn('Street Lamp',{},(g)=>{ shadow(g,24,44,9,3); rect(g,'#3a3a44',22,12,4,32); rect(g,'#3a3a44',17,40,14,4); rr(g,'#e8c25a',17,2,14,14,3); rect(g,'#3a3a44',15,0,18,3); circ(g,'rgba(255,230,140,.3)',24,9,16); });
Tn('Market Stall',{},(g)=>{ shadow(g,24,44,20,3); rect(g,'#6b4423',4,12,4,32); rect(g,'#6b4423',40,12,4,32); for(let i=0;i<6;i++) rect(g,i%2?'#f4f4f4':'#3a8a4a',4+i*7,4,7,12); rect(g,'#a67c45',4,30,40,8); circ(g,'#d9433a',12,28,3.5); circ(g,'#e8c25a',24,28,3.5); circ(g,'#4aa851',36,28,3.5); });
Tn('Fountain',{},(g,r,f)=>{ shadow(g,24,44,20,5); ell(g,'#8d8d96',24,34,21,10); ell(g,'#5a95e0',24,32,17,7); rect(g,'#aaaab4',21,12,6,22); ell(g,'#aaaab4',24,14,9,3); for(let i=0;i<3;i++) line(g,'rgba(190,225,255,.9)',24,12,24+(i-1)*(8+f*2),22+f,2); },{anim:true});
Tn('Statue',{},(g)=>{ shadow(g,24,44,14,4); rect(g,'#8d8d96',10,36,28,8); rect(g,'#aaaab4',16,14,16,24); circ(g,'#b4b4be',24,10,7); line(g,'#aaaab4',32,18,40,6,3); poly(g,'#c9ccd4',40,0,44,8,36,8); });
Tn('Bench',{},(g)=>{ shadow(g,24,43,19,3); rect(g,'#6b4423',6,30,4,12); rect(g,'#6b4423',38,30,4,12); rr(g,'#a67c45',3,22,42,9,2); rr(g,'#8a5a30',3,12,42,8,2); });
Tn('Mailbox',{},(g)=>{ shadow(g,24,43,9,3); rect(g,'#6b4423',22,24,4,19); rr(g,'#3a5fb8',12,8,24,18,7); rect(g,'#2a4590',12,20,24,3); rect(g,'#d9433a',34,6,3,12); });
Tn('Wooden Gate',{},(g)=>{ rect(g,'#6b4423',0,6,8,38); rect(g,'#6b4423',40,6,8,38); rect(g,'#8a5a30',8,12,32,5); rect(g,'#8a5a30',8,28,32,5); line(g,'#7d5226',8,12,40,33,3); },{});
Tn('Stone Bridge',{layer:1,pass:true},(g)=>{ fill(g,'#9c9ca6'); for(let i=0;i<6;i++) line(g,'#7d7d88',i*8,0,i*8,48,2); rect(g,'#6d6d78',0,0,48,5); rect(g,'#6d6d78',0,43,48,5); });
Tn('Wood Bridge',{layer:1,pass:true},(g)=>{ fill(g,'#a67c45'); for(let i=0;i<6;i++){ line(g,'#6b4423',0,i*8,48,i*8,2);} rect(g,'#6b4423',0,0,48,4); rect(g,'#6b4423',0,44,48,4); });
Tn('Castle Wall',{layer:1},(g)=>{ fill(g,'#8d8d98'); for(let y=0;y<4;y++) for(let x=-1;x<3;x++) rr(g,(x+y)%2?'#9c9ca8':'#7f7f8a',x*24+(y%2?12:0)+1,y*12+1,22,10,1); for(let x=0;x<48;x+=16) rect(g,'#6d6d78',x,0,8,6); });
Tn('Castle Gate',{layer:1,pass:true},(g)=>{ fill(g,'#8d8d98'); rect(g,'#3a2a1a',6,10,36,38); ell(g,'#3a2a1a',24,12,18,12); for(let x=10;x<42;x+=6) line(g,'#2a2a30',x,6,x,48,2.5); for(let y=14;y<48;y+=10) line(g,'#2a2a30',6,y,42,y,2.5); });
Tn('Tower Top',{layer:1},(g)=>{ fill(g,'#8d8d98'); poly(g,'#3a5fb8',24,0,44,28,4,28); rect(g,'#6d6d78',4,28,40,4); rect(g,'#2a2a30',19,34,10,14); });
Tn('Banner',{layer:1},(g)=>{ fill(g,'#8d8d98'); rect(g,'#4a3a2c',8,4,32,3); poly(g,'#a8353f',10,7,38,7,38,36,24,44,10,36); poly(g,'#e8c25a',24,14,29,24,24,34,19,24); });

// ----- DUNGEON (E)
const Dg = (name,o,fn)=>D(name,'E',Object.assign({layer:2,pass:false},o||{}),fn);
Dg('Dungeon Wall',{layer:1},(g)=>{ fill(g,'#3a3a48'); for(let y=0;y<4;y++) for(let x=-1;x<3;x++) rr(g,(x+y)%2?'#464656':'#32323f',x*24+(y%2?12:0)+1,y*12+1,22,10,2); rect(g,'#24242e',0,44,48,4); });
Dg('Cave Wall',{layer:1},(g,r)=>{ fill(g,'#3d2f26'); for(let i=0;i<8;i++) ell(g,i%2?'#4a3a2f':'#33271f',r()*44+2,r()*44+2,9,7); rect(g,'#26191a',0,44,48,4); });
Dg('Ice Wall',{layer:1},(g)=>{ fill(g,'#8fc8e4'); poly(g,'#b9e2f5',0,0,20,0,8,30); poly(g,'#a3d4ec',22,0,48,0,48,26,30,36); poly(g,'rgba(255,255,255,.5)',4,0,10,0,4,12); rect(g,'#6aa8c8',0,44,48,4); });
Dg('Spikes',{pass:true,damage:true,layer:1},(g)=>{ for(let x=4;x<48;x+=10) for(let y=8;y<48;y+=14){ poly(g,'#c9ccd4',x,y+10,x+4,y-4,x+8,y+10); poly(g,'#8d909a',x+4,y-4,x+8,y+10,x+4,y+10);} });
Dg('Trap Plate',{pass:true,layer:1},(g)=>{ rr(g,'#6d6d78',6,6,36,36,3); rr(g,'#8d8d98',9,9,30,30,2); circ(g,'#a8353f',24,24,5); });
Dg('Pillar',{},(g)=>{ shadow(g,24,44,15,4); rect(g,'#9c9ca8',12,8,24,34); rect(g,'#7f7f8a',12,8,6,34); rect(g,'#b4b4c0',8,2,32,8); rect(g,'#b4b4c0',8,40,32,6); });
Dg('Skull Pile',{layer:1,pass:true},(g)=>{ for(const [x,y] of [[14,30],[30,32],[22,22]]){ circ(g,'#e8e4d4',x,y,7); rect(g,'#e8e4d4',x-4,y+4,8,5); circ(g,'#2a2a30',x-3,y,2); circ(g,'#2a2a30',x+3,y,2);} });
Dg('Torch Wall',{layer:1,anim:true},(g,r,f)=>{ fill(g,'#3a3a48'); rect(g,'#6b4423',22,18,4,24); rect(g,'#3a3a44',19,16,10,5); poly(g,'#e8601a',24,2+f,31,16,17,16); poly(g,'#ffd05a',24,8+f,28,16,20,16); circ(g,'rgba(255,200,100,.2)',24,14,20); });
Dg('Coffin',{},(g)=>{ shadow(g,24,44,15,4); poly(g,'#4a3a2c',16,2,32,2,38,14,32,46,16,46,10,14); poly(g,'#6b4a34',18,5,30,5,34,14,30,42,18,42,14,14); line(g,'#c9ccd4',24,12,24,30,2); line(g,'#c9ccd4',19,17,29,17,2); });
Dg('Altar',{},(g)=>{ shadow(g,24,44,19,4); rect(g,'#6d6d78',6,24,36,20); rect(g,'#8d8d98',4,18,40,8); circ(g,'#a8353f',24,10,6); rect(g,'#e8c25a',22,12,4,8); });
Dg('Crystal',{},(g)=>{ shadow(g,24,44,12,3); poly(g,'#6aa8f0',24,2,34,24,28,44,20,44,14,24); poly(g,'#9cc8ff',24,2,14,24,20,44,24,24); poly(g,'rgba(255,255,255,.6)',22,10,20,22,24,18); },{});
Dg('Portal',{pass:true,layer:1,anim:true},(g,r,f)=>{ for(let i=0;i<4;i++){ g.strokeStyle=['#8a4ae8','#b46af0','#d99aff','#fff'][i]; g.lineWidth=3; g.beginPath(); g.ellipse(24,24,18-i*4,20-i*4,f*.5+i,0,5.3); g.stroke(); } circ(g,'rgba(200,150,255,.4)',24,24,8); });
Dg('Iron Bars',{layer:1},(g)=>{ fill(g,'#2a2a35'); for(let x=6;x<48;x+=9) rect(g,'#8d909a',x,0,4,48); rect(g,'#6d707a',0,10,48,4); rect(g,'#6d707a',0,34,48,4); });
Dg('Dungeon Door',{layer:1,pass:true},(g)=>{ fill(g,'#3a3a48'); rr(g,'#4a4a56',6,4,36,44,3); for(const y of [12,24,36]) rect(g,'#2a2a35',6,y,36,3); circ(g,'#c9a23a',34,28,3); });
Dg('Treasure Gold',{layer:1,pass:true},(g)=>{ shadow(g,24,40,15,4); for(const [x,y] of [[16,34],[30,34],[23,28],[19,38],[33,38],[26,36]]){ ell(g,'#e8c25a',x,y,6,3); ell(g,'#ffe27a',x-1,y-1,3,1.5);} });
Dg('Web',{layer:1,pass:true},(g)=>{ g.strokeStyle='rgba(235,235,235,.85)'; g.lineWidth=1; for(let a=0;a<4;a++) line(g,'rgba(235,235,235,.85)',0,0,48,a*14); for(let a=1;a<4;a++){ g.beginPath(); g.arc(0,0,a*14,0,1.57); g.stroke(); } });
})();
