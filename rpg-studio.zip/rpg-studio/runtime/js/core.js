/* Core: cache tile/karakter, UI, input, objek battler & state game */
(function(){
'use strict';
const R = window.RPG, T = R.TILE, H = R.H;

/* ---------- gambar & cache ---------- */
const imgCache = {};
R.assetUrl = function(path){ const A=R.$db&&R.$db.assets; return (A&&A[path])||path; };
R.loadImage = function(path){ if(!path) return null; path=R.assetUrl(path); if(imgCache[path]) return imgCache[path].ok? imgCache[path].img : null; const img=new Image(); imgCache[path]={img:img,ok:false}; img.onload=()=>{ imgCache[path].ok=true; if(R.onImageLoad) R.onImageLoad(); }; img.onerror=()=>{ imgCache[path].err=true; }; img.src=(/^(data:|blob:|https?:|file:)/.test(path)?'':(R.assetBase||''))+path; return null; };
const sheetCache = {};
/* Sprite per-arah: tiap arah (bawah/kiri/kanan/atas) berupa gambar terpisah -> disusun jadi sheet 3x4 */
const DIRN=['down','left','right','up'];
function dirSheet(img){ const D=img.dirs||{}, has=d=>D[d]&&D[d].some(Boolean), fr={};
  for(const d of DIRN){ let src=has(d)?{arr:D[d],flip:false}:null; if(!src&&img.mirror!==false){ const o=d==='left'?'right':d==='right'?'left':null; if(o&&has(o)) src={arr:D[o],flip:true}; } if(!src){ const any=['down','up','left','right'].find(has); src=any?{arr:D[any],flip:false}:null; } fr[d]=src; }
  if(!DIRN.some(d=>fr[d])) return null;
  const L={}; let ok=true; for(const d of DIRN){ if(!fr[d]) continue; for(const pth of fr[d].arr){ if(!pth||L[pth]) continue; const im=R.loadImage(pth); if(!im) ok=false; else L[pth]=im; } }
  if(!ok) return null;
  const key='d:'+JSON.stringify([fr,img.bob]); if(sheetCache[key]) return sheetCache[key];
  const first=Object.values(L)[0]; let cw=first.naturalWidth||first.width, ch=first.naturalHeight||first.height; if(cw*3<=144){ cw=48; ch=48; }
  const c=R.mkCanvas(cw*3,ch*4), g=c.getContext('2d'); const bob=Math.max(1,Math.round(ch*.04));
  DIRN.forEach((d,row)=>{ const s=fr[d]; if(!s) return; const a=s.arr, idle=a[0]||a[1]||a[2], wa=a[1]||'', wb=a[2]||''; const plain=!wa&&!wb;
    const cols=[[wa||idle,0],[idle,0],[wb||wa||idle,0]]; if(plain&&img.bob!==false){ cols[0][1]=-bob; cols[2][1]=-bob; }
    cols.forEach(([pth,dy],col)=>{ const im=L[pth]; if(!im) return; const iw=im.naturalWidth||im.width, ih=im.naturalHeight||im.height, k=Math.min(cw/iw,ch/ih), w=iw*k, h=ih*k, x=col*cw+(cw-w)/2, y=row*ch+ch-h+dy; g.imageSmoothingEnabled=k<1;
      if(s.flip){ g.save(); g.translate(col*cw+cw/2,0); g.scale(-1,1); g.drawImage(im,-cw/2+(cw-w)/2,y,w,h); g.restore(); } else g.drawImage(im,x,y,w,h); }); });
  return (sheetCache[key]=c); }
R.charSheet = function(img){
  if(!img||img.kind==='none') return null;
  if(img.kind==='dirs') return dirSheet(img);
  if(img.kind==='file'){ const i=R.loadImage(img.file); return i; }
  if(img.kind==='tile') return null;
  let key, spec;
  if(img.kind==='preset'){ key='p:'+img.name; spec=R.CHAR_PRESETS.find(p=>p.name===img.name)||R.CHAR_PRESETS[0]; }
  else { spec=img.spec||{}; key='c:'+JSON.stringify(spec); }
  return sheetCache[key] || (sheetCache[key]=R.makeCharSheet(spec));
};
const faceCache = {};
R.faceCanvas = function(img,size){ if(!img||(img.kind!=='preset'&&img.kind!=='custom')) return null; const spec=img.kind==='preset'? (R.CHAR_PRESETS.find(p=>p.name===img.name)||R.CHAR_PRESETS[0]) : img.spec; const key=JSON.stringify(spec)+size; return faceCache[key]||(faceCache[key]=R.makeFace(spec,size||96)); };
R.imgOfName = n => R.CHAR_PRESETS.some(p=>p.name===n)? {kind:'preset',name:n} : null;
const tileCache = {};
R.tileCanvas = function(id,frame){
  const d=R.TILES[id-1]; if(!d) return null; const f=d.anim? (frame%3):0; const key=id+':'+f; if(tileCache[key]) return tileCache[key];
  const c=R.mkCanvas(T,T), g=c.getContext('2d'); const ok=d.draw(g,R.rngf(id*77+3),f); if(ok===false) return c; return (tileCache[key]=c);
};
R.clearTileCache = function(){ for(const k of Object.keys(tileCache)) delete tileCache[k]; };
/* ---- tile kustom (tileset impor, disimpan sebagai data URL di project) ---- */
R.registerCustomTiles = function(db){
  if(R.BUILTIN_COUNT===undefined) R.BUILTIN_COUNT=R.TILES.length;
  for(const d of R.TILES.splice(R.BUILTIN_COUNT)) delete R.TILE_BY_NAME[d.name];
  R.clearTileCache();
  const ti=R.TILE_TABS.findIndex(t=>t[0]==='F'); if(ti>=0) R.TILE_TABS.splice(ti,1);
  const list=(db&&db.customTiles)||[]; if(!list.length&&!(db&&db.tilesets&&db.tilesets.length)) return;
  R.TILE_TABS.push(['F','Custom']);
  list.forEach((t,i)=>{
    const set=db.tilesets[t.set];
    const d=R.D_TILE('Custom '+(i+1)+(t.name?': '+t.name:''),'F',{layer:t.layer|0,pass:t.pass!==false,star:!!t.star,bush:!!t.bush,counter:!!t.counter,damage:!!t.damage,shadow:t.castShadow===undefined?undefined:!!t.castShadow,removed:!!t.removed},function(g){
      if(t.removed||!set) return true; const im=R.loadImage(set.data); if(!im) return false; const sz=set.size||48; g.imageSmoothingEnabled=false; g.drawImage(im,t.x*sz,t.y*sz,sz,sz,0,0,48,48); return true; });
  });
};
/* tepi autotile: sisi yang berbeda tetangga */
R.drawTileEdges = function(g,d,x,y,nb,size){ // nb: {u,d,l,r} true bila tetangga berbeda
  if(!d.edge) return; const s=size/T, w=Math.max(2,5*s); g.fillStyle=d.edge; const a=d.anim?0.85:0.55; g.globalAlpha=a;
  if(nb.u) g.fillRect(x,y,size,w); if(nb.d) g.fillRect(x,y+size-w,size,w); if(nb.l) g.fillRect(x,y,w,size); if(nb.r) g.fillRect(x+size-w,y,w,size);
  g.globalAlpha=1;
};
R.passTile = function(id){ const d=R.TILES[id-1]; return !d || d.pass; };

/* ---------- Input ---------- */
const Inp = R.Input = { down:{}, trig:{}, rep:{}, mouse:{x:0,y:0,click:false,moved:false,down:false}, text:'' };
const MAP = {ok:['z','Z','Enter',' '],cancel:['x','X','Escape','0'],shift:['Shift'],up:['ArrowUp','w','W'],down:['ArrowDown','s','S'],left:['ArrowLeft','a','A'],right:['ArrowRight','d','D'],pgup:['q','Q','PageUp'],pgdn:['e','E','PageDown'],menu:['Escape','x','X','0'],attack:['c','C','j','J'],skill:['v','V','k','K']};
const KEYCODE = {}; Inp.DEFAULT_MAP=JSON.parse(JSON.stringify(MAP)); Inp.MAP=MAP;
Inp.setMap=function(m){ for(const k of Object.keys(MAP)) delete MAP[k]; for(const k of Object.keys(KEYCODE)) delete KEYCODE[k]; Object.keys(m).forEach(a=>{ MAP[a]=m[a].slice(); }); Object.keys(MAP).forEach(a=>MAP[a].forEach(k=>{ (KEYCODE[k]=KEYCODE[k]||[]).push(a); })); };
Object.keys(MAP).forEach(a=>MAP[a].forEach(k=>{ (KEYCODE[k]=KEYCODE[k]||[]).push(a); }));
Inp.bind = function(win){
  win.addEventListener('keydown',e=>{ const acts=KEYCODE[e.key]; if(acts){ acts.forEach(a=>{ if(!Inp.down[a]){ Inp.trig[a]=true; Inp.rep[a]=0; } Inp.down[a]=true; }); if(e.key===' '||e.key.startsWith('Arrow')) e.preventDefault(); } if(e.key.length===1||e.key==='Backspace') Inp.keyBuf=(Inp.keyBuf||[]).concat([e.key]); if(e.key==='F9'&&R.onF9) R.onF9(); if(e.key==='F12'&&R.onF12) R.onF12(); if(e.key==='F11'&&R.onF11){ R.onF11(); e.preventDefault(); } });
  win.addEventListener('keyup',e=>{ const acts=KEYCODE[e.key]; if(acts) acts.forEach(a=>{ Inp.down[a]=false; }); });
  win.addEventListener('blur',()=>{ Inp.down={}; });
};
Inp.update = function(){ Inp._t=Inp.trig; Inp.trig={}; Inp._r={}; ['up','down','left','right','pgup','pgdn'].forEach(a=>{ if(Inp.down[a]){ Inp.rep[a]=(Inp.rep[a]||0)+1; if(Inp.rep[a]===1||(Inp.rep[a]>22&&Inp.rep[a]%5===0)) Inp._r[a]=true; } else Inp.rep[a]=0; if(Inp._t[a]) Inp._r[a]=true; }); Inp._mc=Inp.mouse.click; Inp.mouse.click=false; Inp._moved=Inp.mouse.moved; Inp.mouse.moved=false; };
Inp.pressed = a => !!Inp._t && !!Inp._t[a];
Inp.repeat = a => !!Inp._r && !!Inp._r[a];
Inp.isDown = a => !!Inp.down[a];
Inp.dir4 = function(){ if(Inp.down.down) return 2; if(Inp.down.left) return 4; if(Inp.down.right) return 6; if(Inp.down.up) return 8; return 0; };
Inp.clicked = () => !!Inp._mc;
Inp.flush = function(){ Inp._t={}; Inp._mc=false; };

/* ---------- UI ---------- */
const COLORS = ['#ffffff','#7ab8ff','#ff7a7a','#7aff9a','#7affea','#d09aff','#ffe27a','#a0a0b0','#ffa0d0','#ffb060','#60ffb0','#c0c0ff','#ff9a50','#60d0ff','#b0ff60','#808090'];
R.COLORS = COLORS;
const UI = R.UI = { W:816, H:624, font:'"Segoe UI",Roboto,Arial,sans-serif', fs:22, lh:34 };
UI.skinColor = '#1c2a5c';
UI.win = function(g,x,y,w,h,o){ o=o||{}; g.save(); const base=o.color||UI.skinColor; const gr=g.createLinearGradient(0,y,0,y+h); gr.addColorStop(0,R.shade(base,.18)); gr.addColorStop(1,R.shade(base,-.25)); g.globalAlpha=o.alpha===undefined?.93:o.alpha; H.rr(g,gr,x,y,w,h,10); g.globalAlpha=1; g.strokeStyle='rgba(255,255,255,.85)'; g.lineWidth=2.5; g.beginPath(); g.roundRect?g.roundRect(x+1.5,y+1.5,w-3,h-3,9):g.rect(x+1.5,y+1.5,w-3,h-3); g.stroke(); g.strokeStyle='rgba(120,150,255,.55)'; g.lineWidth=1.5; g.beginPath(); g.roundRect?g.roundRect(x+5,y+5,w-10,h-10,6):g.rect(x+5,y+5,w-10,h-10); g.stroke(); g.restore(); };
UI.text = function(g,s,x,y,o){ o=o||{}; g.save(); g.font=(o.bold===false?'':'bold ')+(o.size||UI.fs)+'px '+UI.font; g.textBaseline='middle'; g.textAlign=o.align||'left'; const c=o.color||'#fff'; g.lineJoin='round'; g.lineWidth=4; g.strokeStyle='rgba(0,0,20,.85)'; if(o.maxW){ g.strokeText(s,x,y,o.maxW); g.fillStyle=c; g.fillText(s,x,y,o.maxW);} else { g.strokeText(s,x,y); g.fillStyle=c; g.fillText(s,x,y);} g.restore(); };
UI.measure = function(g,s,size){ g.save(); g.font='bold '+(size||UI.fs)+'px '+UI.font; const w=g.measureText(s).width; g.restore(); return w; };
UI.gauge = function(g,x,y,w,h,rate,c1,c2){ rate=Math.max(0,Math.min(1,rate)); H.rr(g,'rgba(0,0,0,.6)',x,y,w,h,h/2); if(rate>0){ const gr=g.createLinearGradient(x,0,x+w,0); gr.addColorStop(0,c1); gr.addColorStop(1,c2); H.rr(g,gr,x+1,y+1,Math.max(h-2,(w-2)*rate),h-2,(h-2)/2); } };
UI.expand = function(s,game){ if(!s) return ''; game=game||R.$game; let r=String(s); for(let k=0;k<3;k++){ r=r.replace(/\\V\[(\d+)\]/gi,(m,n)=>game?game.v(+n):0); } r=r.replace(/\\N\[(\d+)\]/gi,(m,n)=>{ const a=game&&game.actors?game.actors[+n]:null; return a? a.name : ''; }); r=r.replace(/\\P\[(\d+)\]/gi,(m,n)=>{ const a=game&&game.party?game.party[+n-1]:null; return a?a.name:''; }); r=r.replace(/\\G/g,R.$db?R.$db.system.currency:'G'); r=r.replace(/\\\\/g,'\\'); return r; };
/* gambar teks kaya: dukung \C[n] \I[n] \{ \} ; mengembalikan jumlah baris */
UI.rich = function(g,s,x,y,w,o){ o=o||{}; const lh=o.lh||UI.lh; const text=UI.expand(s); let cx=x, cy=y, color=o.color||'#fff', size=o.size||UI.fs, lines=1; const parts=text.split(/(\\C\[\d+\]|\\I\[\d+\]|\\\{|\\\}|\\\.|\\\||\\!|\\\^|\n)/);
  for(const p of parts){ if(!p) continue; let m;
    if(p==='\n'){ cx=x; cy+=lh; lines++; continue; }
    if((m=/^\\C\[(\d+)\]$/.exec(p))){ color=COLORS[+m[1]%COLORS.length]; continue; }
    if((m=/^\\I\[(\d+)\]$/.exec(p))){ R.drawIcon(g,+m[1],cx,cy-16,28); cx+=32; continue; }
    if(p==='\\{'){ size+=4; continue; } if(p==='\\}'){ size=Math.max(14,size-4); continue; } if(/^\\[.|!^]$/.test(p)) continue;
    if(o.wrap===false){ UI.text(g,p,cx,cy,{color:color,size:size}); cx+=UI.measure(g,p,size); continue; }
    // wrap per kata
    const words=p.split(/(\s+|(?<=[　-鿿]))/);
    for(const wd of words){ if(!wd) continue; const ww=UI.measure(g,wd,size); if(cx+ww>x+w && cx>x){ cx=x; cy+=lh; lines++; if(/^\s+$/.test(wd)) continue; } UI.text(g,wd,cx,cy,{color:color,size:size}); cx+=ww; }
  }
  return lines; };
UI.stripCodes = s => UI.expand(s).replace(/\\[CI]\[\d+\]|\\[{}.|!^]/g,'');
UI.cursor = function(g,x,y,w,h,t){ const a=.55+.25*Math.sin((t||0)/8); g.save(); g.globalAlpha=a; H.rr(g,'rgba(120,170,255,.55)',x,y,w,h,6); g.strokeStyle='rgba(200,225,255,.95)'; g.lineWidth=2; g.strokeRect(x+1,y+1,w-2,h-2); g.restore(); };

/* daftar pilihan (kolom, mouse, scroll) */
UI.List = class {
  constructor(o){ this.x=o.x; this.y=o.y; this.w=o.w; this.h=o.h; this.items=o.items||[]; this.cols=o.cols||1; this.rowH=o.rowH||36; this.index=o.index||0; this.pad=o.pad||14; this.top=0; this.draw1=o.draw; this.enabled=o.enabled; this.active=o.active!==false; this.cancelable=o.cancelable!==false; this.t=0; this.wrap=o.wrap!==false; this.visibleRows=Math.max(1,Math.floor((this.h-this.pad*2)/this.rowH)); }
  set(items){ this.items=items; if(this.index>=items.length) this.index=Math.max(0,items.length-1); }
  colW(){ return Math.floor((this.w-this.pad*2)/this.cols); }
  itemRect(i){ const cw=this.colW(); const row=Math.floor(i/this.cols)-this.top; return {x:this.x+this.pad+(i%this.cols)*cw,y:this.y+this.pad+row*this.rowH,w:cw,h:this.rowH}; }
  ok(i){ return !this.enabled || this.enabled(this.items[i],i); }
  update(){ this.t++; if(!this.active) return null; const I=R.Input, n=this.items.length; const old=this.index; const rows=Math.ceil(n/this.cols);
    if(n>0){ const move=(d)=>{ let i=this.index+d; if(this.wrap){ i=(i%n+n)%n; } else i=Math.max(0,Math.min(n-1,i)); this.index=i; };
      if(I.repeat('down')){ if(this.cols===1||this.index+this.cols<n) move(this.cols); else if(this.wrap) this.index=this.index%this.cols; }
      else if(I.repeat('up')){ if(this.cols===1||this.index-this.cols>=0) move(-this.cols); else if(this.wrap) this.index=Math.min(n-1,(rows-1)*this.cols+this.index%this.cols); }
      else if(I.repeat('right')&&this.cols>1) move(1); else if(I.repeat('left')&&this.cols>1) move(-1);
      else if(I.repeat('pgdn')) this.index=Math.min(n-1,this.index+this.visibleRows*this.cols); else if(I.repeat('pgup')) this.index=Math.max(0,this.index-this.visibleRows*this.cols);
      const r=Math.floor(this.index/this.cols); if(r<this.top) this.top=r; if(r>=this.top+this.visibleRows) this.top=r-this.visibleRows+1; }
    const M=I.mouse; if(I._moved||I._mc){ for(let i=this.top*this.cols;i<Math.min(n,(this.top+this.visibleRows)*this.cols);i++){ const r=this.itemRect(i); if(M.x>=r.x&&M.x<r.x+r.w&&M.y>=r.y&&M.y<r.y+r.h){ if(I._moved&&this.index!==i) this.index=i; if(I._mc){ this.index=i; if(this.ok(i)){ R.Audio.se('OK'); return 'ok'; } else { R.Audio.se('Buzzer'); } } } } }
    if(this.index!==old) R.Audio.se('Cursor');
    if(I.pressed('ok')&&n>0){ if(this.ok(this.index)){ R.Audio.se('OK'); return 'ok'; } R.Audio.se('Buzzer'); }
    if(I.pressed('cancel')&&this.cancelable){ R.Audio.se('Cancel'); return 'cancel'; }
    return null; }
  draw(g,noframe){ if(!noframe) UI.win(g,this.x,this.y,this.w,this.h); g.save(); g.beginPath(); g.rect(this.x+4,this.y+4,this.w-8,this.h-8); g.clip();
    const n=this.items.length; for(let i=this.top*this.cols;i<Math.min(n,(this.top+this.visibleRows)*this.cols);i++){ const r=this.itemRect(i); if(i===this.index&&this.active) UI.cursor(g,r.x-4,r.y,r.w,r.h,this.t); const en=this.ok(i); g.globalAlpha=en?1:.45; if(this.draw1) this.draw1(g,this.items[i],i,r,en); else UI.text(g,String(this.items[i]),r.x+6,r.y+r.h/2,{maxW:r.w-12}); g.globalAlpha=1; }
    g.restore(); const rows=Math.ceil(n/this.cols); if(rows>this.visibleRows){ const sh=this.h-16, th=Math.max(20,sh*this.visibleRows/rows); const ty=this.y+8+(sh-th)*(this.top/(rows-this.visibleRows)); H.rr(g,'rgba(255,255,255,.5)',this.x+this.w-9,ty,4,th,2); } }
};

/* ---------- formula ---------- */
const fcache={};
R.evalFormula = function(f,a,b){ f=String(f||'0'); try{ const fn=fcache[f]||(fcache[f]=new Function('a','b','v','s','Math','return ('+f+');')); const v=fn(a,b||a,R.$game?R.$game.vars:[],R.$game?R.$game.sw:[],Math); return isNaN(v)?0:v; }catch(e){ return 0; } };

/* ---------- Battler ---------- */
class Battler {
  constructor(){ this.hp=1; this.mp=0; this.states=[]; this.tmp={}; }
  get mhp(){ return this.param('mhp'); } get mmp(){ return this.param('mmp'); }
  get atk(){ return this.param('atk'); } get def(){ return this.param('def'); } get mat(){ return this.param('mat'); } get mdf(){ return this.param('mdf'); } get agi(){ return this.param('agi'); } get luk(){ return this.param('luk'); }
  param(p){ let v=this.baseParam(p); for(const s of this.states){ const d=R.$db.states[s.id-1]; if(d&&d.paramRate&&d.paramRate[p]) v=v*d.paramRate[p]/100; } return Math.max(p==='mhp'?1:0,Math.round(v)); }
  isDead(){ return this.states.some(s=>s.id===1); }
  isAlive(){ return !this.isDead(); }
  hasState(id){ return this.states.some(s=>s.id===id); }
  addState(id){ if(!id) return false; const d=R.$db.states[id-1]; if(!d) return false; if(id!==1&&this.isDead()) return false; if(id===1){ this.hp=0; this.states=this.states.filter(s=>s.id===1); this.states.push({id:1,turns:0}); return true; } const ex=this.states.find(s=>s.id===id); if(ex){ ex.turns=d.turns||0; return true; } this.states.push({id:id,turns:d.turns||0}); const rs=R.$db.states[id-1].restrict; if(rs>=4) {} return true; }
  removeState(id){ const n=this.states.length; this.states=this.states.filter(s=>s.id!==id); if(id===1&&n!==this.states.length&&this.hp<=0) this.hp=1; return n!==this.states.length; }
  restriction(){ let r=0; for(const s of this.states){ const d=R.$db.states[s.id-1]; if(d&&d.restrict>r) r=d.restrict; } return r; }
  canMove(){ return this.isAlive() && this.restriction()<4; }
  clearStates(){ this.states=[]; }
  gainHp(v){ this.hp=Math.max(0,Math.min(this.mhp,this.hp+Math.round(v))); if(this.hp<=0&&!this.isDead()) this.addState(1); }
  gainMp(v){ this.mp=Math.max(0,Math.min(this.mmp,this.mp+Math.round(v))); }
  recoverAll(){ this.states=[]; this.hp=this.mhp; this.mp=this.mmp; }
  elementRate(e){ return 100; }
  onBattleEnd(){ this.states=this.states.filter(s=>{ const d=R.$db.states[s.id-1]; return !(d&&d.removeBattleEnd)||s.id===1; }); }
  /* akhir giliran: regen/poison, hitung durasi */
  turnEnd(){ const log=[]; for(const s of this.states.slice()){ const d=R.$db.states[s.id-1]; if(!d) continue; if(d.hpRegen){ const v=Math.round(d.hpRegen>0? this.mhp*d.hpRegen/100 : -Math.max(1,this.mhp*(-d.hpRegen)/100)); log.push({k:'regen',v:v,state:d}); this.gainHp(v); } if(d.mpRegen) this.gainMp(Math.round(this.mmp*d.mpRegen/100)); if(s.turns>0&&d.autoRemove){ s.turns--; if(s.turns<=0&&s.id!==1) this.removeState(s.id); } } return log; }
}
class Actor extends Battler {
  constructor(id){ super(); const d=R.$db.actors[id-1]; this.id=id; this.name=d.name; this.cls=d.cls; this.level=d.level||1; this.img=R.imgOfName(d.char)||(d.char&&d.char.kind?d.char:{kind:'preset',name:'Hero'}); this.nickname=d.nickname||''; this.equips=(d.equips||[0,0,0,0,0]).slice(0,5); while(this.equips.length<5) this.equips.push(0); this.exp=R.expFor(R.$db.classes[this.cls-1],this.level); this.skills=[]; this.learnForLevel(); this.hp=this.mhp; this.mp=this.mmp; this.tmp={}; }
  get data(){ return R.$db.actors[this.id-1]; }
  get clsData(){ return R.$db.classes[this.cls-1]; }
  get isActor(){ return true; }
  equipItem(slot){ const id=this.equips[slot]; if(!id) return null; return slot===0? R.$db.weapons[id-1] : R.$db.armors[id-1]; }
  baseParam(p){ let v=R.paramAt(this.clsData,p,this.level); for(let s=0;s<5;s++){ const e=this.equipItem(s); if(e&&e.params&&e.params[p]) v+=e.params[p]; } return v; }
  learnForLevel(){ for(const l of this.clsData.learnings||[]) if(l.lv<=this.level&&!this.skills.includes(l.skill)) this.skills.push(l.skill); if(!this.skills.includes(1)) this.skills.unshift(1); }
  expToNext(){ return R.expFor(this.clsData,this.level+1)-this.exp; }
  expRate(){ const a=R.expFor(this.clsData,this.level), b=R.expFor(this.clsData,this.level+1); return (this.exp-a)/Math.max(1,b-a); }
  gainExp(v){ const res=[]; this.exp=Math.max(0,this.exp+v); while(this.level<(this.data.maxLevel||99)&&this.exp>=R.expFor(this.clsData,this.level+1)){ const oh=this.mhp,om=this.mmp; this.level++; const ns=this.skills.length; this.learnForLevel(); this.hp=Math.min(this.mhp,this.hp+(this.mhp-oh)); this.mp=Math.min(this.mmp,this.mp+(this.mmp-om)); res.push({level:this.level,newSkills:this.skills.slice(ns)}); } return res; }
  changeLevel(l){ l=Math.max(1,Math.min(this.data.maxLevel||99,l)); this.level=l; this.exp=R.expFor(this.clsData,l); this.learnForLevel(); this.hp=Math.min(this.hp,this.mhp); this.mp=Math.min(this.mp,this.mmp); }
  elementRate(e){ return 100; }
  canEquip(slot,item){ if(!item) return true; if(slot===0) return (this.clsData.weaponOk||[]).includes(item.id); return item.etype===slot && (this.clsData.armorOk||[]).includes(item.etype); }
  usableSkills(){ return this.skills.filter(s=>R.$db.skills[s-1]&&R.$db.skills[s-1].stype!==0 || (s!==1&&s!==2&&R.$db.skills[s-1])); }
  toJSON(){ return {id:this.id,name:this.name,cls:this.cls,level:this.level,img:this.img,nickname:this.nickname,equips:this.equips,exp:this.exp,skills:this.skills,hp:this.hp,mp:this.mp,states:this.states}; }
  static fromJSON(o){ const a=new Actor(o.id); Object.assign(a,o); return a; }
}
class Enemy extends Battler {
  constructor(id,index){ super(); const d=R.$db.enemies[id-1]; this.id=id; this.index=index||0; this.name=d.name; this.hp=d.mhp; this.mp=d.mmp; this.letter=''; this.hidden=false; this.tmp={}; this.x=0; this.y=0; }
  get data(){ return R.$db.enemies[this.id-1]; }
  get isActor(){ return false; }
  baseParam(p){ return this.data[p]||0; }
  elementRate(e){ const r=this.data.elem&&this.data.elem[e]; return r===undefined?100:r; }
}
R.Battler=Battler; R.Actor=Actor; R.Enemy=Enemy;

/* ---------- State game ---------- */
class Game {
  constructor(){ this.sw=[]; this.vars=[]; this.selfSw={}; this.actors={}; this.party=[]; this.items={}; this.weapons={}; this.armors={}; this.gold=0; this.steps=0; this.frames=0; this.mapId=0; this.px=0; this.py=0; this.pdir=2; this.flags={save:true,menu:true,encounter:true,formation:true}; this.followers=true; this.transparent=false; this.erased={}; this.tint=[0,0,0,0]; this.weather={type:'none',power:0}; this.pictures={}; this.bgmName='None'; this.battles=0; this.timer=-1; this.lastBgm=''; this.bossFlags={}; }
  s(n){ return !!this.sw[n]; } v(n){ return this.vars[n]|0; }
  setS(n,b){ this.sw[n]=!!b; } setV(n,v){ this.vars[n]=Math.floor(v); }
  selfKey(m,e,k){ return m+','+e+','+k; }
  actor(id){ if(!this.actors[id]) this.actors[id]=new Actor(id); return this.actors[id]; }
  addParty(id,init){ if(init) delete this.actors[id]; const a=this.actor(id); if(!this.party.includes(a)&&this.party.length<(R.$db.system.maxParty||4)) this.party.push(a); }
  removeParty(id){ this.party=this.party.filter(a=>a.id!==id); }
  members(){ return this.party; } alive(){ return this.party.filter(a=>a.isAlive()); }
  numItems(kind,id){ const t=this[kind==='item'?'items':kind==='weapon'?'weapons':'armors']; return t[id]||0; }
  gainItem(kind,id,n){ const t=this[kind==='item'?'items':kind==='weapon'?'weapons':'armors']; t[id]=Math.max(0,Math.min(99,(t[id]||0)+n)); if(!t[id]) delete t[id]; }
  gainGold(n){ this.gold=Math.max(0,Math.min(99999999,this.gold+n)); }
  setupNew(){ const s=R.$db.system; this.mapId=s.startMap; this.px=s.startX; this.py=s.startY; this.pdir=s.startDir||2; this.gold=0; for(const id of s.party) this.addParty(id,true); for(const it of s.startingItems||[]) this.gainItem(it.kind,it.id,it.n); }
  save(){ const o={}; for(const k of Object.keys(this)) if(k!=='actors'&&k!=='party') o[k]=this[k]; o.actors={}; for(const k in this.actors) o.actors[k]=this.actors[k].toJSON(); o.party=this.party.map(a=>a.id); return o; }
  load(o){ for(const k of Object.keys(o)) if(k!=='actors'&&k!=='party') this[k]=o[k]; this.actors={}; for(const k in o.actors) this.actors[k]=Actor.fromJSON(o.actors[k]); this.party=o.party.map(id=>this.actors[id]).filter(Boolean); }
}
R.Game = Game;
})();
