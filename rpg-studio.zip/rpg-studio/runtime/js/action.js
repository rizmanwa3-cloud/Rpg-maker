/* Combat aksi real-time di peta: musuh terlihat, serangan senjata (tombol Attack), skill cepat, HUD. */
(function(){
'use strict';
const R = window.RPG, T = R.TILE, DX = R.DX, DY = R.DY, UI = R.UI;
const A = R.Action = { pops:[], projs:[], cd:0, invul:0, swing:null, skillIdx:0, rings:[], pending:null };

R.WEAPON_TYPES = {
  sword:{name:'Sword',range:1.55,width:1.15,cd:22,mult:1,kb:1},
  spear:{name:'Spear',range:2.7,width:.6,cd:30,mult:1.15,kb:1},
  axe:{name:'Axe',range:1.75,circle:true,cd:42,mult:1.55,kb:2},
  bow:{name:'Bow',proj:true,range:7,cd:30,mult:.9,speed:.3,color:'#f0e2a8',kb:1},
  staff:{name:'Staff',proj:true,magic:true,mp:3,range:6,cd:34,mult:1.2,speed:.22,color:'#8ad8ff',kb:1},
  fist:{name:'Fists',range:1.2,width:.7,cd:18,mult:.6,kb:0}
};
R.guessWType = n => /bow/i.test(n||'')?'bow':/spear|lance|pike/i.test(n||'')?'spear':/axe|hammer|mace/i.test(n||'')?'axe':/staff|wand|rod|scepter/i.test(n||'')?'staff':'sword';
A.isOn = () => (R.$db&&R.$db.system.battleMode)==='action';
A.leader = () => { const g=R.$game; return g&&g.party.find(a=>a.isAlive())||null; };
A.mobs = sc => sc.map.events.filter(e=>e.mob&&e.mob.b.hp>0&&!e.mob.dying&&!e.erased&&e.page);
A.dirOf = (dx,dy) => Math.abs(dx)>=Math.abs(dy)? (dx>0?6:4) : (dy>0?2:8);
A.pop = (x,y,text,color,big) => A.pops.push({x:x,y:y,text:text,color:color||'#fff',big:!!big,t:0});
A.sceneGen = function*(sc,id){ const s=(R.$db.scenes||[])[id-1]; if(!s||!s.list) return; if(s.cinematic) sc.letterbox=1; sc.inScene=true; yield* sc.interp.run(s.list,{eventId:0,evt:null,common:true}); sc.inScene=false; sc.letterbox=0; };
A.runScene = function(id){ A.pending={scene:id}; };
A.reset = () => { A.pops=[]; A.projs=[]; A.rings=[]; A.swing=null; A.cd=0; A.invul=0; A.pending=null; };

/* ---------- inisialisasi mob dari data event ---------- */
R.initMob = function(ev){
  const m=ev.data.mob; if(!m||!R.$db.enemies[m.enemy-1]) return;
  ev.mobCfg=Object.assign({aggro:5,speed:3,cd:70,wander:true,ranged:false,boss:false,respawn:false,deathSwitch:0,deathCommon:0},m);
  ev.mob={b:new R.Enemy(m.enemy,0),flash:0,stun:0,windup:0,cool:40,chase:false,show:0,dying:0,lunge:0};
};

/* ---------- serangan pemain ---------- */
A.atkSkill = function(w,wt){
  const base=R.$db.skills[0]; let f=wt.magic?'a.mat * 4 - b.mdf * 2':(base.formula||'a.atk * 4 - b.def * 2');
  return Object.assign({},base,{formula:'('+f+') * '+wt.mult,anim:(w&&w.anim)||base.anim||'Slash',mp:0,type:'damage',crit:true});
};
A.attack = function(sc){
  const a=A.leader(); if(!a||A.cd>0||sc.co||sc.msg||sc.transferring) return;
  const w=a.equipItem(0), wt=R.WEAPON_TYPES[w?(w.wtype||R.guessWType(w.name)):'fist']||R.WEAPON_TYPES.fist, p=sc.player;
  if(wt.mp&&a.mp<wt.mp){ A.pop(p.rx,p.ry-.3,'No MP','#8cf'); R.Audio.se('Buzzer',.5); A.cd=14; return; }
  if(wt.mp) a.gainMp(-wt.mp);
  A.cd=wt.cd; const dir=p.dir; A.swing={t:0,dur:wt.proj?8:12,dir:dir,wt:wt,icon:w&&w.icon};
  R.Audio.se(wt.magic?'Magic':'Step',.9);
  const sk=A.atkSkill(w,wt);
  if(wt.proj){ A.projs.push({x:p.rx,y:p.ry,dir:dir,vx:DX[dir]*wt.speed,vy:DY[dir]*wt.speed,left:wt.range,skill:sk,from:'player',color:wt.color,magic:!!wt.magic,kb:wt.kb}); return; }
  for(const m of A.mobs(sc)) if(A.inArc(p,m,dir,wt)) A.hitMob(sc,m,sk,wt.kb,p);
};
A.inArc = function(p,m,dir,wt){
  const fx=DX[dir], fy=DY[dir], rx=m.rx-p.rx, ry=m.ry-p.ry;
  if(wt.circle) return Math.hypot(rx,ry)<=wt.range;
  const f=rx*fx+ry*fy, l=Math.abs(-rx*fy+ry*fx); return f>-.25&&f<=wt.range&&l<=(wt.width||.8);
};
A.skills = function(a){ return a.skills.filter(id=>id!==1&&R.$db.skills[id-1]&&['damage','heal'].includes(R.$db.skills[id-1].type)); };
A.useSkill = function(sc){
  const a=A.leader(); if(!a||A.cd>0||sc.co||sc.msg) return; const p=sc.player; const list=A.skills(a);
  if(!list.length){ A.pop(p.rx,p.ry-.3,'No skills','#ccc'); A.cd=15; return; }
  const sk=R.$db.skills[list[A.skillIdx%list.length]-1];
  if(a.mp<sk.mp){ A.pop(p.rx,p.ry-.3,'No MP','#8cf'); R.Audio.se('Buzzer',.5); A.cd=14; return; }
  a.gainMp(-sk.mp); A.cd=26; R.Audio.se('Magic',.8);
  if(sk.type==='heal'){ const res=R.useOn(a,a,sk,false); sc.mapAnims.push({ch:p,name:sk.anim||'Heal',t:0,dur:30}); if(res.hp) A.pop(p.rx,p.ry-.4,String(-res.hp),'#7dffa0',true); R.Audio.se('Heal',.7); return; }
  if(sk.scope===2){ A.rings.push({x:p.rx,y:p.ry,t:0,r:3.3}); for(const m of A.mobs(sc)) if(Math.hypot(m.rx-p.rx,m.ry-p.ry)<=3.3) A.hitMob(sc,m,sk,2,p); return; }
  const dir=p.dir, sp=.24; A.projs.push({x:p.rx,y:p.ry,dir:dir,vx:DX[dir]*sp,vy:DY[dir]*sp,left:7,skill:sk,from:'player',color:'#ffb060',magic:true,kb:1});
};
A.cycleSkill = function(d){ const a=A.leader(); if(!a) return; const n=A.skills(a).length; if(!n) return; A.skillIdx=(A.skillIdx+d+n*50)%n; R.Audio.se('Cursor',.5); };

/* ---------- kena / mati ---------- */
A.hitMob = function(sc,m,skill,kb,from){
  const a=A.leader(), mb=m.mob; if(!a) return;
  const res=R.useOn(a,mb.b,skill,false);
  if(!res.hit){ A.pop(m.rx,m.ry-.5,'Miss','#ddd'); return; }
  A.pop(m.rx,m.ry-.6,res.noDmg?'0':String(res.hp),res.crit?'#ffd24a':'#fff',res.crit);
  sc.mapAnims.push({ch:m,name:skill.anim||'Slash',t:0,dur:24}); R.Audio.se(res.crit?'Crit':'Hit',.7);
  mb.flash=8; mb.stun=18; mb.show=240; mb.windup=0;
  if(mb.b.hp<=0){ A.killMob(sc,m); return; }
  if(kb&&!m.moving&&from){ const d=A.dirOf(m.x-from.x,m.y-from.y); for(let i=0;i<kb;i++){ if(m.canPass(m.x,m.y,d,sc.map)&&!(m.x+DX[d]===sc.player.x&&m.y+DY[d]===sc.player.y)){ m.speed=5; m.moveStraight(d,sc.map); break; } } }
};
A.killMob = function(sc,m){
  const mb=m.mob, cfg=m.mobCfg, en=mb.b.data, g=R.$game, T_=R.$db.system.terms; mb.dying=30; mb.show=0;
  R.Audio.se('Hit',.5);
  const lead=A.leader(); let lvBefore=lead?lead.level:0;
  for(const a of g.alive()) a.gainExp(en.exp||0);
  A.pop(m.rx,m.ry-.9,'+'+(en.exp||0)+' EXP','#9fe89f');
  if(en.gold){ g.gainGold(en.gold); A.pop(m.rx+.3,m.ry-1.25,'+'+en.gold+' '+(R.$db.system.currency||'G'),'#ffe27a'); }
  let dy=-1.6; for(const d of en.drops||[]){ if(Math.random()*100<d.rate){ g.gainItem(d.kind,d.id,1); const lst=d.kind==='item'?R.$db.items:d.kind==='weapon'?R.$db.weapons:R.$db.armors; A.pop(m.rx,m.ry+dy,lst[d.id-1].name,'#9ad0ff'); dy-=.35; } }
  if(lead&&lead.level>lvBefore){ A.pop(sc.player.rx,sc.player.ry-.9,'LEVEL UP!','#ffe27a',true); R.Audio.se('Level Up',.8); }
  if(cfg.boss){ R.Audio.stopBgm(); R.Audio.se('Victory',.8); setTimeout(()=>{ if(R.$scene===sc&&!cfg.deathCommon) sc.playMapBgm(); },1800); }
  if(!cfg.respawn) g.erased[sc.map.id+','+m.id]=1;
  if(cfg.deathSwitch){ g.setS(cfg.deathSwitch,true); sc.map.needRefresh=true; }
  if(cfg.deathCommon){ const ce=R.$db.commonEvents[cfg.deathCommon-1]; if(ce&&ce.list) A.pending=ce.list; }
};
A.hurtPlayer = function(sc,atk,skill){
  if(A.invul>0||sc.co) return; const a=A.leader(); if(!a) return; const p=sc.player;
  const res=R.useOn(atk,a,skill,false);
  if(!res.hit){ A.pop(p.rx,p.ry-.4,'Miss','#ddd'); A.invul=15; return; }
  A.invul=45; A.pop(p.rx,p.ry-.5,String(res.hp),res.crit?'#ffb040':'#ff6b6b',res.crit);
  sc.shakeFx={p:2,s:6,t:0,dur:8}; R.Audio.se(res.crit?'Crit':'Hit',.9);
  if(a.isDead()) A.onLeaderDead(sc);
};
A.onLeaderDead = function(sc){
  const g=R.$game;
  if(!g.alive().length){ sc.inEvent=true; sc.co=new R.Co(sc.gameOver()); return; }
  while(g.party[0].isDead()) g.party.push(g.party.shift());
  sc.player.img=g.party[0].img; A.pop(sc.player.rx,sc.player.ry-.9,g.party[0].name+' takes the lead!','#fff');
};

/* ---------- AI musuh ---------- */
A.mobSkill = function(e){
  const en=e.mob.b.data, acts=(en.actions||[]).filter(x=>{ const s=R.$db.skills[x.skill-1]; return s&&s.type==='damage'&&s.scope!==2; });
  if(!acts.length) return R.$db.skills[0]; const tot=acts.reduce((s,x)=>s+(x.rating||1),0); let r=Math.random()*tot; for(const x of acts){ r-=(x.rating||1); if(r<=0) return R.$db.skills[x.skill-1]; } return R.$db.skills[acts[0].skill-1];
};
A.updateMob = function(e,map){
  const sc=R.$scene, mb=e.mob; if(!mb||!sc||!(sc instanceof R.Scene_Map)) return;
  if(mb.dying>0){ mb.dying--; e.fade=Math.max(0,mb.dying/30); if(mb.dying<=0){ e.erased=true; e.refresh(); } return; }
  if(sc.co||sc.msg||sc.transferring||sc.battle) return;
  if(mb.flash>0) mb.flash--; if(mb.show>0) mb.show--; if(mb.lunge>0) mb.lunge--;
  if(mb.stun>0){ mb.stun--; return; }
  if(e.moving) return; const lead=A.leader(); if(!lead) return;
  const p=sc.player, cfg=e.mobCfg, dx=p.x-e.x, dy=p.y-e.y, dist=Math.abs(dx)+Math.abs(dy);
  if(mb.windup>0){ mb.windup--; if(mb.windup===0) A.mobStrike(sc,e); return; }
  if(mb.cool>0) mb.cool--;
  if(dist<=cfg.aggro){ if(!mb.chase&&cfg.boss&&R.$db.system.bossBgm) R.Audio.playBgm(R.$db.system.bossBgm); mb.chase=true; } else if(dist>cfg.aggro+4){ if(mb.chase&&cfg.boss) sc.playMapBgm(); mb.chase=false; }
  const line=(dx===0||dy===0);
  if(mb.chase){
    if(cfg.ranged){ if(mb.cool<=0&&line&&dist<=6){ e.dir=A.dirOf(dx,dy); mb.windup=26; return; } if(line&&dist<=4) return; }
    else if(dist===1){ e.dir=A.dirOf(dx,dy); if(mb.cool<=0) mb.windup=22; return; }
    const hd=dx>0?6:4, vd=dy>0?2:8; const order=Math.abs(dx)>=Math.abs(dy)?[dx?hd:0,dy?vd:0]:[dy?vd:0,dx?hd:0];
    for(const d of order){ if(!d) continue; if(e.x+DX[d]===p.x&&e.y+DY[d]===p.y) continue; if(e.canPass(e.x,e.y,d,map)){ e.speed=cfg.speed; e.moveStraight(d,map); return; } }
    if(Math.random()<.3){ const d=[2,4,6,8][Math.floor(Math.random()*4)]; if(!(e.x+DX[d]===p.x&&e.y+DY[d]===p.y)&&e.canPass(e.x,e.y,d,map)){ e.speed=cfg.speed; e.moveStraight(d,map); } }
  } else if(cfg.wander&&Math.random()<.015){ const d=[2,4,6,8][Math.floor(Math.random()*4)]; if(!(e.x+DX[d]===p.x&&e.y+DY[d]===p.y)&&e.canPass(e.x,e.y,d,map)){ e.speed=Math.max(2,cfg.speed-1); e.moveStraight(d,map); } }
};
A.mobStrike = function(sc,e){
  const p=sc.player, cfg=e.mobCfg, mb=e.mob, sk0=A.mobSkill(e), sk=Object.assign({},sk0,{formula:'('+(sk0.formula||'a.atk * 2 - b.def')+') * '+((cfg.dmg||40)/100)}); mb.cool=cfg.cd+Math.floor(Math.random()*30);
  if(cfg.ranged){ const d=e.dir, sp=.2; A.projs.push({x:e.rx,y:e.ry,dir:d,vx:DX[d]*sp,vy:DY[d]*sp,left:7,skill:sk,from:'mob',src:e,color:'#ff8a50',magic:true}); R.Audio.se('Magic',.5); return; }
  mb.lunge=8; if(Math.hypot(p.rx-e.rx,p.ry-e.ry)<=1.55) A.hurtPlayer(sc,mb.b,sk);
};

/* ---------- update per frame ---------- */
A.update = function(sc){
  if(A.cd>0) A.cd--; if(A.invul>0) A.invul--; sc.player.flashT=A.invul>0?A.invul:0;
  if(A.swing){ A.swing.t++; if(A.swing.t>=A.swing.dur) A.swing=null; }
  for(const r of A.rings) r.t++; A.rings=A.rings.filter(r=>r.t<18);
  for(const o of A.pops) o.t++; A.pops=A.pops.filter(o=>o.t<55);
  const map=sc.map;
  for(const pr of A.projs){
    pr.x+=pr.vx; pr.y+=pr.vy; pr.left-=Math.hypot(pr.vx,pr.vy); const tx=Math.round(pr.x), ty=Math.round(pr.y);
    if(!map.valid(tx,ty)||!map.passable(tx,ty)||pr.left<=0){ pr.dead=true; continue; }
    if(pr.from==='player'){ for(const m of A.mobs(sc)) if(Math.hypot(m.rx-pr.x,m.ry-pr.y)<.65){ A.hitMob(sc,m,pr.skill,pr.kb||0,{x:Math.round(pr.x-pr.vx*3),y:Math.round(pr.y-pr.vy*3)}); pr.dead=true; break; } }
    else { const p=sc.player; if(Math.hypot(p.rx-pr.x,p.ry-pr.y)<.55){ A.hurtPlayer(sc,pr.src.mob.b,pr.skill); pr.dead=true; } }
  }
  A.projs=A.projs.filter(p=>!p.dead);
  if(A.pending&&!sc.co){ const pd=A.pending; A.pending=null; sc.inEvent=true; sc.co=new R.Co((function*(){ if(pd.scene) yield* A.sceneGen(sc,pd.scene); else yield* sc.interp.run(pd,{eventId:0,evt:null,common:true}); sc.inEvent=false; })()); }
};
/* input (dipanggil saat pemain bebas bergerak) */
A.input = function(sc,I){ if(I.pressed('attack')) A.attack(sc); else if(I.pressed('skill')) A.useSkill(sc); if(I.pressed('pgup')) A.cycleSkill(-1); if(I.pressed('pgdn')) A.cycleSkill(1); };

/* ---------- gambar ---------- */
const sprCache=new Map(), silCache=new Map();
function sprite(e){ const en=e.mob.b.data, key=en.kind+'|'+en.color; let s=sprCache.get(key); if(!s){ s=R.makeMonster(en.kind,en.color); sprCache.set(key,s); } return s; }
function silhouette(spr,color){ const key=color+'|'+(spr.__id||(spr.__id=Math.random())); let c=silCache.get(key); if(!c){ c=document.createElement('canvas'); c.width=spr.width; c.height=spr.height; const g=c.getContext('2d'); g.drawImage(spr,0,0); g.globalCompositeOperation='source-atop'; g.fillStyle=color; g.fillRect(0,0,c.width,c.height); silCache.set(key,c); } return c; }
A.sizeOf = e => e.mobCfg.boss?110:(e.mob.b.data.mhp>=250?92:e.mob.b.data.mhp>=120?66:54);
A.drawMob = function(g,e,p){
  const mb=e.mob, spr=sprite(e), s=A.sizeOf(e); const bob=mb.dying?0:Math.sin((R.$game.frames+e.id*13)/14)*1.5;
  let ox=0,oy=0; if(mb.windup>0){ ox=(Math.random()-.5)*3; } if(mb.lunge>0){ const d=e.dir; ox+=DX[d]*mb.lunge*2; oy+=DY[d]*mb.lunge*2; }
  const cx=p.x+24+ox, fy=p.y+46+oy+bob; R.H.ell(g,'rgba(0,0,0,.3)',p.x+24,p.y+44,s*.32,s*.1);
  g.save(); if(mb.dying){ g.globalAlpha*=.8; } g.drawImage(spr,cx-s/2,fy-s,s,s);
  if(mb.flash>0){ g.globalAlpha*=.75; g.drawImage(silhouette(spr,'#ffffff'),cx-s/2,fy-s,s,s); }
  else if(mb.windup>0){ g.globalAlpha*=.4+.3*Math.sin(mb.windup); g.drawImage(silhouette(spr,'#ff3030'),cx-s/2,fy-s,s,s); }
  g.restore();
  if(mb.windup>0){ UI.text(g,'!',cx,fy-s-8,{align:'center',size:26,color:'#ffd84a'}); }
  if(!e.mobCfg.boss&&mb.show>0&&!mb.dying){ const w=Math.max(34,s*.7), r=Math.max(0,mb.b.hp/mb.b.mhp); g.fillStyle='rgba(0,0,0,.65)'; g.fillRect(cx-w/2-1,fy-s-6,w+2,7); g.fillStyle=r>.5?'#5ad06a':r>.25?'#e8c040':'#e85050'; g.fillRect(cx-w/2,fy-s-5,w*r,5); }
};
A.draw = function(g,sc,ox,oy,x0,y0){
  const S=(x,y)=>({x:ox+(x-x0)*T,y:oy+(y-y0)*T}); const p=sc.player;
  for(const r of A.rings){ const c=S(r.x,r.y), k=r.t/18; g.save(); g.globalAlpha=1-k; g.strokeStyle='#ffb060'; g.lineWidth=6*(1-k); g.beginPath(); g.arc(c.x+24,c.y+24,r.r*T*k,0,6.3); g.stroke(); g.restore(); }
  if(A.swing){ const s=A.swing, k=s.t/s.dur, wt=s.wt, c=S(p.rx,p.ry), cx=c.x+24, cy=c.y+26; const ang={2:Math.PI/2,4:Math.PI,6:0,8:-Math.PI/2}[s.dir]; g.save(); g.lineCap='round';
    if(wt.proj){ g.globalAlpha=1-k; g.fillStyle=wt.color; g.beginPath(); g.arc(cx+DX[s.dir]*26,cy+DY[s.dir]*26,8*(1-k)+3,0,6.3); g.fill(); }
    else if(wt.circle){ const r=wt.range*T*.8, a=k*Math.PI*2; g.strokeStyle='rgba(255,255,255,'+(.85*(1-k*.6))+')'; g.lineWidth=12*(1-k*.5); g.beginPath(); g.arc(cx,cy,r,ang+a-2.4,ang+a); g.stroke(); wIcon(g,s.icon,cx+Math.cos(ang+a)*r,cy+Math.sin(ang+a)*r,ang+a); }
    else if(wt.name==='Spear'){ const L=wt.range*T*(k<.5?k*2:1), a2=1-Math.max(0,(k-.6)/.4); g.globalAlpha=a2; g.strokeStyle='#e8f0ff'; g.lineWidth=6; g.beginPath(); g.moveTo(cx,cy); g.lineTo(cx+DX[s.dir]*L,cy+DY[s.dir]*L); g.stroke(); wIcon(g,s.icon,cx+DX[s.dir]*L,cy+DY[s.dir]*L,ang); }
    else { const r=wt.range*T*.78, a0=ang-1.15, a1=a0+2.3*k; g.strokeStyle='rgba(255,255,255,'+(.85*(1-k*.5))+')'; g.lineWidth=11*(1-k*.6); g.beginPath(); g.arc(cx,cy,r,a0,a1); g.stroke(); wIcon(g,s.icon,cx+Math.cos(a1)*r,cy+Math.sin(a1)*r,a1); }
    g.restore(); }
  for(const pr of A.projs){ const c=S(pr.x,pr.y), x=c.x+24, y=c.y+24; g.save(); if(pr.magic){ g.shadowColor=pr.color; g.shadowBlur=14; g.fillStyle=pr.color; g.beginPath(); g.arc(x,y,7,0,6.3); g.fill(); g.fillStyle='#fff'; g.beginPath(); g.arc(x,y,3,0,6.3); g.fill(); } else { g.strokeStyle=pr.color; g.lineWidth=3; g.beginPath(); g.moveTo(x-DX[pr.dir]*14,y-DY[pr.dir]*14); g.lineTo(x+DX[pr.dir]*10,y+DY[pr.dir]*10); g.stroke(); g.fillStyle='#fff'; g.beginPath(); g.arc(x+DX[pr.dir]*11,y+DY[pr.dir]*11,3,0,6.3); g.fill(); } g.restore(); }
  for(const o of A.pops){ const c=S(o.x,o.y), k=o.t/55; g.save(); g.globalAlpha=k<.6?1:1-(k-.6)/.4; UI.text(g,o.text,c.x+24,c.y+6-o.t*.7,{align:'center',size:o.big?30:22,color:o.color}); g.restore(); }
};
function wIcon(g,icon,x,y,a){ if(!icon) return; g.save(); g.translate(x,y); g.rotate(a+Math.PI/4); R.drawIcon(g,icon,-18,-18,36); g.restore(); }

A.hud = function(g,sc){
  if(!A.isOn()||sc.msg||sc.scrollTxt) return; const a=A.leader(); if(!a) return;
  g.save(); g.fillStyle='rgba(8,12,30,.72)'; g.strokeStyle='rgba(255,255,255,.25)'; g.lineWidth=1; g.fillRect(8,8,236,76); g.strokeRect(8.5,8.5,236,76);
  const w=a.equipItem(0); if(w) R.drawIcon(g,w.icon,14,14,32);
  UI.text(g,a.name+'  Lv'+a.level,54,24,{size:17});
  const bar=(y,v,col1,col2,label)=>{ g.fillStyle='rgba(0,0,0,.6)'; g.fillRect(54,y,180,11); const k=Math.max(0,Math.min(1,v)); g.fillStyle=col1; g.fillRect(54,y,180*k,11); g.fillStyle=col2; g.fillRect(54,y,180*k,4); UI.text(g,label,58,y+6,{size:10,bold:true}); };
  bar(38,a.hp/a.mhp,'#d94a4a','#f08a8a','HP '+a.hp+'/'+a.mhp); bar(52,a.mmp?a.mp/a.mmp:0,'#3f7fe0','#8ab4f5','MP '+a.mp+'/'+a.mmp);
  const list=A.skills(a); const sk=list.length?R.$db.skills[list[A.skillIdx%list.length]-1]:null;
  UI.text(g,sk?'Q/E ▸ '+sk.name+' ('+sk.mp+'MP)  [V]':'No skills',54,74,{size:12,color:'#bcd',bold:false});
  if(A.cd>0){ g.fillStyle='rgba(255,255,255,.25)'; g.fillRect(14,46,32*(A.cd/30>1?1:A.cd/30),4); }
  g.restore();
  // bar boss
  const boss=sc.map.events.find(e=>e.mob&&e.mobCfg.boss&&e.mob.b.hp>0&&!e.mob.dying&&!e.erased&&(e.mob.chase||e.mob.show>0));
  if(boss){ const b=boss.mob.b, W=816, w=420, x=(W-w)/2, y=sc.mapNameT>0?76:20; g.save(); g.fillStyle='rgba(8,12,30,.78)'; g.fillRect(x-8,y-6,w+16,36); UI.text(g,b.name,W/2,y+4,{align:'center',size:15}); g.fillStyle='rgba(0,0,0,.6)'; g.fillRect(x,y+14,w,10); g.fillStyle='#d94a4a'; g.fillRect(x,y+14,w*Math.max(0,b.hp/b.mhp),10); g.restore(); }
};
})();
