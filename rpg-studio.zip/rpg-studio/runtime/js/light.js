/* Pencahayaan: siang/malam, cahaya titik real-time dengan bayangan (terhalang dinding/pohon/pintu/blok),
   bayangan matahari, bayangan karakter mengikuti cahaya. Semua prosedural (tanpa aset). */
(function(){
'use strict';
const R = window.RPG, T = R.TILE || 48;
const W = 816, H = 624;
const L = R.Light = {};
const clamp=(v,a,b)=>v<a?a:v>b?b:v;
const hex = c=>{ c=String(c||'#fff').replace('#',''); if(c.length===3) c=c[0]+c[0]+c[1]+c[1]+c[2]+c[2]; const n=parseInt(c,16)||0; return [(n>>16)&255,(n>>8)&255,n&255]; };
const lerp=(a,b,t)=>a+(b-a)*t;

/* ---------- konfigurasi bawaan ---------- */
L.MAP_MODES = [{v:'off',t:'Off (no lighting)'},{v:'time',t:'Follows time of day (outdoors)'},{v:'fixed',t:'Fixed darkness (cave / indoors)'}];
L.mapDefaults = ()=>({mode:'off',ambient:'#1c2246',sun:true,shadows:true,playerLight:0,playerColor:'#ffd9a0'});
L.eventDefaults = ()=>({radius:220,color:'#ffcf80',intensity:100,flicker:25,shadows:true,nightOnly:false,switch:0,glow:true});
L.clockDefaults = ()=>({auto:true,startHour:9,dayMinutes:8,shadowStrength:100,nightColor:'#1a2048',dawnColor:'#e8a37a',duskColor:'#f08a5a'});
L.clockCfg = ()=>Object.assign(L.clockDefaults(), (R.$db&&R.$db.system&&R.$db.system.clock)||{});

/* ---------- keadaan permainan (disimpan bersama game) ---------- */
L.st = function(){ const g=R.$game; if(!g) return null; if(!g.lt){ const c=L.clockCfg(); g.lt={time:c.startHour,target:null,rate:0,auto:!!c.auto,dayMin:c.dayMinutes,torch:null,noShadow:false,mapOv:{},varId:0}; } return g.lt; };
L.hour = ()=>{ const s=L.st(); return s?s.time:12; };
L.hourText = ()=>{ const t=L.hour(), h=Math.floor(t), m=Math.floor((t-h)*60); return String(h).padStart(2,'0')+':'+String(m).padStart(2,'0'); };
L.setTime = function(h,frames){ const s=L.st(); if(!s) return; h=((h%24)+24)%24; if(!frames||frames<=0){ s.time=h; s.target=null; return; } let d=h-s.time; if(d>12) d-=24; if(d<-12) d+=24; s.target=s.time+d; s.rate=d/frames; s.tframes=frames; };

L.update = function(){ const s=L.st(); if(!s) return;
  if(s.target!=null){ s.time+=s.rate; s.tframes--; if(s.tframes<=0){ s.time=((s.target%24)+24)%24; s.target=null; } else s.time=((s.time%24)+24)%24; }
  else if(s.auto&&s.dayMin>0) s.time=(s.time+24/(s.dayMin*3600))%24;
  if(s.varId) R.$game.setV(s.varId,Math.floor(s.time)); };

/* ---------- warna ambient menurut jam ---------- */
function ambientFor(h){ const c=L.clockCfg(); const night=hex(c.nightColor), dawn=hex(c.dawnColor), dusk=hex(c.duskColor), day=[255,255,255];
  const K=[[0,night],[4.5,night],[5.8,dawn],[7.5,day],[16.5,day],[18,dusk],[19.8,night],[24,night]];
  for(let i=0;i<K.length-1;i++){ const a=K[i], b=K[i+1]; if(h>=a[0]&&h<=b[0]){ const t=(h-a[0])/((b[0]-a[0])||1), e=t*t*(3-2*t); return [lerp(a[1][0],b[1][0],e),lerp(a[1][1],b[1][1],e),lerp(a[1][2],b[1][2],e)]; } }
  return night; }
/* kekuatan matahari 0..1 (nol saat malam) */
function sunK(h){ if(h<5.5||h>19.5) return 0; if(h<7.5) return (h-5.5)/2; if(h>17.5) return (19.5-h)/2; return 1; }

/* konfigurasi cahaya peta yang berlaku (termasuk override dari command) */
L.mapCfg = function(map){ const s=L.st(); const base=Object.assign(L.mapDefaults(),map.data.light||{}); const ov=s&&s.mapOv&&s.mapOv[map.id]; return ov?Object.assign(base,ov):base; };
L.active = function(map){ if(!map||!R.$game) return false; const c=L.mapCfg(map); return c.mode!=='off'; };

/* ---------- peta penghalang cahaya ---------- */
const TALL = /Tree|Pine|Pillar|Statue|Bookshelf|Cabinet|Boulder|Crystal|Chimney|Market Stall|Fountain|Well|Fireplace|Coffin|Altar|Cliff|Black Void|Hay Bale/;
const ROUND = /Tree|Pine|Boulder|Crystal|Statue|Fountain|Well|Hay Bale|Market Stall|Altar|Coffin|Pillar|Bush/;
function tileOpaque(id,layer){ const d=R.TILES[id-1]; if(!d||d.star) return 0; if(d.opaque!==undefined) return d.opaque?1:0; if(TALL.test(d.name||'')){ if(/Cliff|Void/.test(d.name)) return 1; if(!d.pass) return ROUND.test(d.name)?2:1; return 0; } if(!d.pass&&layer===1) return 1; return 0; }
function shadowTile(id,l){ const d=R.TILES[id-1]; if(!d||d.star||d.shadow===false) return false; if(d.shadow===true) return true; if(l===1) return true; if(l===2) return !d.pass||tileOpaque(id,2)>0||/^Custom/.test(d.name||''); return false; }  // layer peta 2 = semua tile (dinding, pintu, jendela, objek kustom); layer 3 = objek tidak-lewat + kustom
function build(map){ const w=map.w, h=map.h, o=new Uint8Array(w*h); for(let i=0;i<w*h;i++){ for(let l=0;l<3;l++){ const id=map.layers[l][i]; if(id){ const k=tileOpaque(id,l); if(k){ o[i]=k; break; } } } } const runs=[]; for(let x=0;x<w;x++){ let cur=null; for(let y=0;y<=h;y++){ let ids=null; if(y<h){ for(let l=0;l<3;l++){ const id=map.layers[l][y*w+x]; if(id&&shadowTile(id,l)){ (ids||(ids=[])).push(id); } } } if(ids){ if(!cur){ cur={x:x,y:y,n:0,cells:[]}; runs.push(cur); } cur.cells.push(ids); cur.n++; } else cur=null; } }
  map._lt={stat:o,dyn:new Uint8Array(w*h),dynList:[],runs:runs}; return map._lt; }
L.invalidate = map=>{ if(map) map._lt=null; };
function dynamic(map,st){ for(const i of st.dynList) st.dyn[i]=0; st.dynList.length=0;
  for(const e of map.events){ if(!e.page||e.erased) continue; let b=false;
    if(e.door&&e.door.open<.5&&!e.through) b=true; else if(e.mover&&(e.img.kind!=='none'||e.tileId)) b=true; else if(e.data.light&&e.data.light.block&&!e.through&&(e.img.kind!=='none'||e.tileId)) b=true;
    if(!b) continue; const x=Math.round(e.rx), y=Math.round(e.ry); if(x<0||y<0||x>=map.w||y>=map.h) continue; const i=y*map.w+x; if(!st.dyn[i]){ st.dyn[i]=1; st.dynList.push(i); } } }
L.opaqueAt = function(map,x,y){ const st=map._lt||build(map); if(x<0||y<0||x>=map.w||y>=map.h) return false; const i=y*map.w+x; return !!(st.stat[i]||st.dyn[i]); };

/* sinar vs grid (DDA). Kembalikan jarak (tile) sampai penghalang pertama, maks maxD. Sel awal diabaikan. */
function ray(st,w,h,ox,oy,dx,dy,maxD){
  let cx=Math.floor(ox), cy=Math.floor(oy); const sx=dx>0?1:-1, sy=dy>0?1:-1;
  const tdx=dx===0?1e9:Math.abs(1/dx), tdy=dy===0?1e9:Math.abs(1/dy);
  let tx=dx===0?1e9:((dx>0?cx+1-ox:ox-cx)*tdx), ty=dy===0?1e9:((dy>0?cy+1-oy:oy-cy)*tdy), t=0;
  for(let n=0;n<64;n++){ if(tx<ty){ t=tx; tx+=tdx; cx+=sx; } else { t=ty; ty+=tdy; cy+=sy; } if(t>=maxD) return maxD; if(cx<0||cy<0||cx>=w||cy>=h) return t; const i=cy*w+cx; if(st.stat[i]||st.dyn[i]) return t; }
  return maxD; }

/* ---------- sumber cahaya ---------- */
function collect(map,sc,fr,night){ const s=L.st(), out=[]; const cfg=L.mapCfg(map);
  for(const e of map.events){ const d=e.data.light; if(!d||!e.page||e.erased||(d.radius|0)<=0) continue; if(d.switch&&!R.$game.s(d.switch)) continue; if(d.nightOnly&&night<.15) continue;
    const fl=(d.flicker||0)/100; const f=1-fl*(.5+.5*Math.sin(fr*.23+e.id*1.7))*(.6+.4*Math.sin(fr*.071+e.id*3.1));
    const k=d.nightOnly?clamp(night*1.6,0,1):1;
    out.push({x:e.rx+.5,y:e.ry+.45-(e.jh||0)/T,r:d.radius*(1-fl*.12*(1-f)*4),col:hex(d.color),a:clamp((d.intensity||100)/100,0,2)*f*k,sh:d.shadows!==false,glow:d.glow!==false}); }
  const p=sc.player; const tc=s&&s.torch&&s.torch.on?s.torch:(cfg.playerLight>0?{radius:cfg.playerLight,color:cfg.playerColor}:null);
  if(tc&&p) out.push({x:p.rx+.5,y:p.ry+.5,r:tc.radius,col:hex(tc.color),a:1-.06*Math.sin(fr*.2),sh:true,glow:false});
  return out; }

/* ---------- lightmap ---------- */
let LM=null, LL=null, SH=null; const SCALE=3;
function canv(w,h){ const c=document.createElement('canvas'); c.width=w; c.height=h; return c; }

function drawLight(g,map,li,ox,oy,x0,y0){ // g = LL (resolusi kecil), koordinat dalam px layar / SCALE
  const st=map._lt, k=1/SCALE; const cxp=(ox+(li.x-x0)*T)*k, cyp=(oy+(li.y-y0)*T)*k, rp=li.r*k, rt=li.r/T;
  if(cxp+rp<0||cyp+rp<0||cxp-rp>W*k||cyp-rp>H*k) return;
  g.save(); g.globalCompositeOperation='lighter';
  if(li.sh&&!L.st().noShadow){ const n=clamp(Math.round(rt*46),90,320); g.beginPath();
    for(let i=0;i<=n;i++){ const a=i/n*6.2832, dx=Math.cos(a), dy=Math.sin(a); let d=ray(st,map.w,map.h,li.x,li.y,dx,dy,rt); if(d<rt) d=Math.min(rt,d+.42); const px=cxp+dx*d*T*k, py=cyp+dy*d*T*k; if(i) g.lineTo(px,py); else g.moveTo(px,py); }
    g.closePath(); g.clip(); }
  const gr=g.createRadialGradient(cxp,cyp,0,cxp,cyp,rp), c=li.col, A=Math.min(1,li.a);
  gr.addColorStop(0,'rgba('+c[0]+','+c[1]+','+c[2]+','+A+')'); gr.addColorStop(.45,'rgba('+c[0]+','+c[1]+','+c[2]+','+(A*.62)+')'); gr.addColorStop(1,'rgba('+c[0]+','+c[1]+','+c[2]+',0)');
  g.fillStyle=gr; g.fillRect(cxp-rp,cyp-rp,rp*2,rp*2); g.restore(); }

/* dipanggil dari scene_map.draw setelah peta tergambar (koordinat ox,oy,x0,y0 sama dengan map.draw) */
L.draw = function(g,sc,ox,oy,x0,y0){ const map=sc.map; if(!L.active(map)) return; const cfg=L.mapCfg(map), s=L.st(); const hr=s.time;
  const st=map._lt||build(map); dynamic(map,st);
  let amb, night; if(cfg.mode==='time'){ amb=ambientFor(hr); night=clamp(1-sunK(hr),0,1); } else { amb=hex(cfg.ambient); night=1; }
  const lights=collect(map,sc,R.$game.frames,night);
  if(Math.min(amb[0],amb[1],amb[2])>=250) return;  // siang terang: tanpa lightmap
  if(!LM){ LM=canv(Math.ceil(W/SCALE),Math.ceil(H/SCALE)); LL=canv(LM.width,LM.height); }
  const gl=LL.getContext('2d'); gl.setTransform(1,0,0,1,0,0); gl.globalCompositeOperation='source-over'; gl.fillStyle='#000'; gl.fillRect(0,0,LL.width,LL.height);
  for(const li of lights) drawLight(gl,map,li,ox,oy,x0,y0);
  const gm=LM.getContext('2d'); gm.globalCompositeOperation='source-over'; gm.fillStyle='rgb('+(amb[0]|0)+','+(amb[1]|0)+','+(amb[2]|0)+')'; gm.fillRect(0,0,LM.width,LM.height); gm.globalCompositeOperation='lighter'; gm.drawImage(LL,0,0);
  g.save(); g.imageSmoothingEnabled=true; g.imageSmoothingQuality='high'; g.globalCompositeOperation='multiply'; g.drawImage(LM,0,0,W,H);
  // pendar cahaya (bloom ringan, hanya di area gelap)
  const dark=1-Math.min(1,(amb[0]+amb[1]+amb[2])/765); if(dark>.08){ g.globalCompositeOperation='lighter'; g.globalAlpha=.20*dark*1.3; g.drawImage(LL,0,0,W,H); }
  g.restore(); };

/* ---------- bayangan: siluet objek yang diproyeksikan (matahari + tiap cahaya) ---------- */
function sunVec(h){ const t=clamp((h-6)/12,0,1); return {x:(t-.5)*2*1.5, y:.5+.2*Math.abs(t-.5)*2}; }
const silC=new Map();
function threshold(src,w,h){ const c=canv(w,h), x=c.getContext('2d'); x.drawImage(src,0,0); const im=x.getImageData(0,0,w,h), d=im.data; for(let i=0;i<d.length;i+=4){ const a=d[i+3]>60; d[i]=d[i+1]=d[i+2]=0; d[i+3]=a?255:0; } x.putImageData(im,0,0); return c; }
const silTry={};
function silTile(id){ let c=silC.get(id); if(c!==undefined) return c; const cv=R.tileCanvas&&R.tileCanvas(id,0); c=cv?threshold(cv,cv.width,cv.height):null;
  if(c&&hasPix(c)){ silC.set(id,c); return c; } silTry[id]=(silTry[id]||0)+1; if(silTry[id]>240){ silC.set(id,null); } return null; }  // gambar tile kustom dimuat asinkron: coba lagi
function hasPix(c){ const d=c.getContext('2d').getImageData(0,0,c.width,c.height).data; for(let i=3;i<d.length;i+=4) if(d[i]) return true; return false; }
const sheetCache=new WeakMap();
function silChar(c){
  if(c.img.kind==='tile'){ const cv=silTile(c.tileId); return cv?{cv:cv,ox:0}:null; }
  const sh=R.charSheet&&R.charSheet(c.img); if(!sh||sh.complete===false||!sh.width) return null; const row={2:0,4:1,6:2,8:3}[c.dir]||0; let m=sheetCache.get(sh); if(!m){ m={}; sheetCache.set(sh,m); } const key=row+'_'+c.pat+'_'+sh.width; let e=m[key];
  if(!e){ const big=sh.width>144; const tmp=canv(96,48), x=tmp.getContext('2d'); x.imageSmoothingEnabled=false; if(big){ const cw=sh.width/3, ch=sh.height/4, dw=cw*(T/ch); x.drawImage(sh,c.pat*cw,row*ch,cw,ch,48-dw/2,0,dw,T); } else x.drawImage(sh,c.pat*48,row*48,48,48,24,0,48,48); e=m[key]={cv:threshold(tmp,96,48),ox:-24}; }
  return e; }
let SM=null;
function proj(m,cv,dx,dy,yb,ax,ay,w,h){ m.save(); m.transform(1,0,-ax,-ay,ax*yb,yb*(1+ay)); m.drawImage(cv,dx-.5,dy-.5,(w||cv.width)+1,(h||cv.height)+1); m.restore(); }
function drawGroup(m,gr,ax,ay){ if(gr.blob){ m.beginPath(); m.ellipse(gr.bx+ax*14,gr.by-2+ay*8,15,6,0,0,6.3); m.fill(); return; } for(const p of gr.parts) proj(m,p[0],p[1],p[2],gr.yb,ax,ay,p[3],p[4]); }
function runGroups(map,ox,oy,x0,y0,cols){ const st=map._lt||build(map), out=[]; for(const r of st.runs){ if(r.x<x0-8||r.x>x0+cols+8) continue; const top=oy+(r.y-y0)*T, bot=top+r.n*T; if(bot<-T*3||top>H+T*3) continue; const sx=ox+(r.x-x0)*T, yb=bot-5, gr={bx:sx+24,by:yb,yb:yb,parts:[]}; for(let k=0;k<r.cells.length;k++) for(const id of r.cells[k]){ const cv=silTile(id); if(cv) gr.parts.push([cv,sx,top+k*T]); } if(gr.parts.length) out.push(gr); } return out; }
const mobSil=new WeakMap(); let BLK=null;
function silSprite(spr){ let c=mobSil.get(spr); if(!c){ if(spr.width>320||spr.height>320) return null; c=threshold(spr,spr.width,spr.height); mobSil.set(spr,c); } return c; }
function charGroups(map,chars,ox,oy,x0,y0){ const out=[]; for(const c of chars){ if(c.transparent) continue; const p=map.charScreen(c,ox,oy,x0,y0); if(p.x<-120||p.y<-120||p.x>W+120||p.y>H+120) continue; const yb=p.y+(c.jh||0)+T-5;
    if(c.mob){ const mp=R.Action&&R.Action.shadowPart&&R.Action.shadowPart(c,p); if(mp){ const cv=silSprite(mp.spr); if(cv) out.push({bx:p.x+24,by:mp.yb,yb:mp.yb,parts:[[cv,mp.x,mp.y,mp.w,mp.h]]}); } continue; }
    if(c.door){ const t=c.door.open||0; if(t>=.95) continue; if(!BLK){ BLK=canv(48,48); const x=BLK.getContext('2d'); x.fillStyle='#000'; x.fillRect(0,0,48,48); } out.push({bx:p.x+24,by:p.y+43,yb:p.y+43,parts:[[BLK,p.x,p.y+48*t,48,48*(1-t)]]}); continue; }
    if(c.img.kind==='none'&&!c.tileId) continue; const e=silChar(c); if(e) out.push({bx:p.x+24,by:yb,yb:yb,parts:[[e.cv,p.x+e.ox,p.y+(c.jh||0)]]}); } return out; }
function passes(g,sc,groups,ox,oy,x0,y0){ if(!groups.length) return; const map=sc.map, cfg=L.mapCfg(map), s=L.st(); if(s.noShadow) return;
  const night=cfg.mode==='time'?clamp(1-sunK(s.time),0,1):1; const sun=(cfg.mode==='time'&&cfg.sun!==false)?sunK(s.time)*clamp((L.clockCfg().shadowStrength||100)/100,0,1.5):0;
  if(!SM){ SM=canv(Math.ceil(W/2),Math.ceil(H/2)); } const m=SM.getContext('2d');
  const begin=()=>{ m.setTransform(1,0,0,1,0,0); m.globalCompositeOperation='source-over'; m.clearRect(0,0,SM.width,SM.height); m.setTransform(.5,0,0,.5,0,0); m.fillStyle='#000'; };
  if(sun>.02){ begin(); const v=sunVec(s.time), ax=v.x*.7, ay=v.y; for(const gr of groups) drawGroup(m,gr,ax,ay); g.save(); g.imageSmoothingEnabled=true; g.globalAlpha=.34*Math.min(1,sun); g.drawImage(SM,0,0,W,H); g.restore(); }
  if(cfg.shadows===false) return; const lights=collect(map,sc,R.$game.frames,night).filter(l=>l.sh&&l.a>.05); if(!lights.length) return; const pl=sc.player; lights.sort((a,b)=>Math.hypot(a.x-pl.rx,a.y-pl.ry)-Math.hypot(b.x-pl.rx,b.y-pl.ry));
  for(const li of lights.slice(0,5)){ const lx=ox+(li.x-x0)*T, ly=oy+(li.y-y0)*T; if(lx<-li.r||ly<-li.r||lx>W+li.r||ly>H+li.r) continue; begin(); let n=0;
    for(const gr of groups){ const dx=gr.bx-lx, dy=gr.by-ly, d=Math.hypot(dx,dy); if(d<T*.9||d>li.r+T*2) continue; const k=clamp(.3+.75*d/li.r,.3,1.05); drawGroup(m,gr,dx/d*k,dy/d*k*.9); n++; }
    if(!n) continue; m.setTransform(1,0,0,1,0,0); m.globalCompositeOperation='destination-in'; const gr2=m.createRadialGradient(lx/2,ly/2,0,lx/2,ly/2,li.r/2); gr2.addColorStop(0,'rgba(0,0,0,'+Math.min(1,li.a)*.6+')'); gr2.addColorStop(.7,'rgba(0,0,0,'+Math.min(1,li.a)*.3+')'); gr2.addColorStop(1,'rgba(0,0,0,0)'); m.fillStyle=gr2; m.fillRect(0,0,SM.width,SM.height);
    g.save(); g.imageSmoothingEnabled=true; g.drawImage(SM,0,0,W,H); g.restore(); } }
/* dipanggil dari map.draw: setelah lantai (sebelum dinding/objek) dan sebelum karakter */
L.sunShadows = function(g,sc,ox,oy,x0,y0,cols,rows){ if(!L.active(sc.map)) return; const map=sc.map; const st=map._lt||build(map); dynamic(map,st); passes(g,sc,runGroups(map,ox,oy,x0,y0,cols),ox,oy,x0,y0); };
L.charShadows = function(g,sc,chars,ox,oy,x0,y0){ if(!L.active(sc.map)) return; passes(g,sc,charGroups(sc.map,chars,ox,oy,x0,y0),ox,oy,x0,y0); };

/* ---------- command ---------- */
L.command = function(c){ const s=L.st(); if(!s) return; const map=R.$scene&&R.$scene.map;
  switch(c.op){
    case 'time': L.setTime(+c.hour||0,c.frames|0); break;
    case 'addtime': L.setTime(s.time+(+c.hour||0),c.frames|0); break;
    case 'clock': s.auto=c.on!=='off'; if(c.dayMin>0) s.dayMin=c.dayMin; break;
    case 'torch': s.torch=c.on==='off'?null:{on:true,radius:c.radius||200,color:c.color||'#ffd9a0'}; break;
    case 'map': if(map){ const o={mode:c.mode||'time'}; if(c.mode==='fixed') o.ambient=c.color||'#1c2246'; if(c.playerLight!==undefined&&c.playerLight!==''&&c.playerLight>=0) o.playerLight=c.playerLight; s.mapOv[map.id]=Object.assign(s.mapOv[map.id]||{},o); } break;
    case 'shadows': s.noShadow=c.on==='off'; break;
    case 'tovar': s.varId=c.v|0; if(s.varId) R.$game.setV(s.varId,Math.floor(s.time)); break;
  } };
})();
