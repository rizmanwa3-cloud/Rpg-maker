/* Proyek demo bawaan: kota, ladang, gua, rumah, penginapan */
(function(){
'use strict';
const R = window.RPG;
const cm=(c,o)=>Object.assign({c:c,i:0},o||{});
const txt=(text,face)=>cm('text',{face:face||'',pos:'bottom',bg:'window',text:text});
const ind=(l,n)=>l.map(x=>Object.assign({},x,{i:x.i+n}));
const IF=(cond,th,el)=>{ const o=[cm('if',Object.assign({else:!!(el&&el.length)},cond))].concat(ind(th,1)); if(el&&el.length){ o.push(cm('else')); o.push(...ind(el,1)); } o.push(cm('endif')); return o; };
const CH=(opts,branches,cancel)=>{ const o=[cm('choices',{opts:opts,cancel:cancel===undefined?0:cancel,pos:'right'})]; opts.forEach((_,k)=>{ o.push(cm('when',{idx:k})); o.push(...ind(branches[k]||[],1)); }); o.push(cm('endchoices')); return o; };
const SE=n=>cm('playse',{name:n,vol:100});
const tid=n=>R.TILE_BY_NAME[n].id;

R.buildDemo = function(){
  const db=R.newProject(); db.system.title='Legend of Greenvale'; db.system.subtitle='A Demo Adventure';
  db.system.switches[7]='Intro Done'; db.system.startMap=1; db.system.startX=15; db.system.startY=12;
  const set=(m,x,y,n)=>{ if(x<0||y<0||x>=m.w||y>=m.h) return; const d=R.TILE_BY_NAME[n]; m.layers[d.layer][y*m.w+x]=d.id; };
  const fillR=(m,x,y,w,h,n)=>{ for(let j=0;j<h;j++) for(let i=0;i<w;i++) set(m,x+i,y+j,n); };
  const clear=(m,x,y,w,h,l)=>{ for(let j=0;j<h;j++) for(let i=0;i<w;i++) if(x+i>=0&&y+j>=0&&x+i<m.w&&y+j<m.h) m.layers[l][(y+j)*m.w+x+i]=0; };
  let eid=0; const addEv=(m,x,y,name,pages)=>{ const e=R.newEvent(m.events.length+1,x,y); e.name=name; e.pages=pages; m.events.push(e); return e; };
  const page=(o)=>{ const p=R.newPage(); p.cond=Object.assign(p.cond,o.cond||{}); if(o.img) p.img=o.img; if(o.dir) p.dir=o.dir; if(o.move) p.move=Object.assign(p.move,o.move); if(o.trigger!==undefined) p.trigger=o.trigger; if(o.prio!==undefined) p.prio=o.prio; if(o.through) p.opt.through=true; p.list=(o.list||[]).concat([cm('empty')]); return p; };
  const pre=n=>({kind:'preset',name:n});
  const npc=(m,x,y,preset,list,move,dir)=>addEv(m,x,y,preset,[page({img:pre(preset),list:list,move:move,dir:dir||2})]);
  const xfer=(m,x,y,map,tx,ty,dir,trig)=>addEv(m,x,y,'Transfer',[page({trigger:trig===undefined?1:trig,list:[cm('playse',{name:'Door',vol:100}),cm('transfer',{mode:'direct',map:map,x:tx,y:ty,dir:dir||0,fade:'black'})]})]);
  const chest=(m,x,y,kind,id,n,label)=>addEv(m,x,y,'Chest',[page({img:{kind:'tile',tile:tid('Chest Closed')},list:[SE('Chest'),cm('item',{kind:kind,id:id,op:'+',n:n}),txt('\\C[6]'+label+'\\C[0] found!'),cm('setself',{key:'A',val:'on'})]}),page({cond:{selfSw:'A'},img:{kind:'tile',tile:tid('Chest Open')}})]);
  const house=(m,x,y,w,roof,doorX)=>{ fillR(m,x,y,w,2,roof); fillR(m,x,y+2,w,1,'Wall House'); set(m,x+1,y+2,'House Window'); set(m,x+w-2,y+2,'House Window'); set(m,doorX,y+2,'House Door'); };

  /* ===== MAP 1: Greenvale ===== */
  const m1=R.newMap(1,'Greenvale',30,22,tid('Grass')); m1.bgm='Peaceful Village'; m1.battleBg='Grass';
  fillR(m1,0,11,30,2,'Dirt'); fillR(m1,14,4,2,18,'Dirt'); fillR(m1,6,7,1,4,'Dirt'); fillR(m1,22,7,1,4,'Dirt'); fillR(m1,5,13,3,3,'Cobblestone');
  for(let x=0;x<30;x++){ set(m1,x,0,'Tree'); set(m1,x,21,'Tree'); } for(let y=0;y<22;y++){ if(y<11||y>12){ set(m1,0,y,'Tree'); set(m1,29,y,'Tree'); } }
  house(m1,4,4,5,'Roof Red',6); house(m1,20,4,6,'Roof Blue',22); house(m1,10,3,3,'Roof Brown',11); house(m1,17,15,4,'Roof Green',19);
  set(m1,10,5,'Wall White'); set(m1,12,5,'Wall White'); m1.layers[1][5*30+11]=tid('House Door'); xfer(m1,11,5,6,6,7,0); /* rumah kecil -> inn kedua? pakai rumah hero */
  m1.events.pop();
  set(m1,24,6,'Inn Sign');
  [[3,2],[26,2],[2,8],[27,9],[8,18],[12,19],[24,18],[27,15],[4,16],[20,2]].forEach(([x,y])=>set(m1,x,y,'Tree')); [[2,13],[26,14],[12,15],[16,8],[9,9]].forEach(([x,y])=>set(m1,x,y,'Flowers Red')); [[3,14],[25,13],[13,16],[7,17]].forEach(([x,y])=>set(m1,x,y,'Flowers Yellow')); [[21,17],[10,10],[18,9]].forEach(([x,y])=>set(m1,x,y,'Flowers Blue'));
  set(m1,10,15,'Fountain'); set(m1,24,16,'Well'); set(m1,8,12,'Bench'); m1.layers[2][12*30+8]=tid('Bench'); set(m1,16,10,'Signpost'); set(m1,13,17,'Bush'); set(m1,23,19,'Hay Bale'); set(m1,22,19,'Barrel'); set(m1,18,13,'Market Stall'); set(m1,5,11,'Street Lamp'); set(m1,24,11,'Street Lamp');
  clear(m1,8,12,1,1,2); fillR(m1,8,12,1,1,'Dirt');
  /* events kota */
  addEv(m1,15,12,'Intro',[page({trigger:3,list:[cm('fadeout'),cm('playbgm',{name:'Peaceful Village',vol:100}),cm('wait',{frames:30}),cm('fadein'),txt('Welcome to \\C[6]Greenvale\\C[0], a quiet village at the edge of the Whispering Fields.','Elder'),txt('\\C[6]Move\\C[0]: Arrow keys / WASD   \\C[6]Talk\\C[0]: Z or Enter\\n\\C[6]Dash\\C[0]: hold Shift   \\C[6]Menu\\C[0]: X or Esc'),txt('Speak with the village elder to begin your adventure!'),cm('setswitch',{a:8,a2:8,val:'on'})]}),page({cond:{s1:8}})]);
  m1.events[0].pages[1].list=[cm('empty')];
  /* pencahayaan: Greenvale mengikuti siang/malam, lampu jalan menyala saat gelap */
  m1.light={mode:'time',ambient:'#1c2246',sun:true,shadows:true,playerLight:0,playerColor:'#ffd9a0'};
  [[12,10],[19,10],[12,13],[21,13]].forEach(([x,y],i)=>{ set(m1,x,y,'Street Lamp'); const e=addEv(m1,x,y,'Lamp '+(i+1),[page({trigger:0,prio:0,through:true})]); e.light={radius:230,color:'#ffd88a',intensity:100,flicker:8,shadows:true,nightOnly:true,switch:0,glow:true}; });
  npc(m1,13,10,'Elder',[].concat(IF({kind:'switch',a:3,b:'off'},[txt('Ah, young \\N[1]! A darkness stirs in the \\C[6]Old Cave\\C[0] north of the fields.','Elder'),txt('Take this \\C[6]Old Key\\C[0}. It opens the sealed gate. Be careful... monsters roam the fields.'.replace('0}','0]'),'Elder'),cm('item',{kind:'item',id:9,op:'+',n:1}),SE('Chest'),txt('\\C[6]Old Key\\C[0] received!'),txt('Gather allies in the village first. \\C[6]Mira\\C[0] the mage is by the fountain, and \\C[6]Brann\\C[0] drinks at the inn.','Elder'),cm('setswitch',{a:3,a2:3,val:'on'})],[txt('Go north through the fields, east of here. The cave awaits... Take care, \\N[1].','Elder')])),[],2);
  npc(m1,17,13,'Merchant',[txt('Welcome! Finest goods in Greenvale!','Merchant')].concat(CH(['Buy / Sell','Just looking'],[[cm('shop',{goods:[{kind:'item',id:1},{kind:'item',id:2},{kind:'item',id:3},{kind:'item',id:5},{kind:'item',id:6},{kind:'item',id:7},{kind:'weapon',id:2},{kind:'weapon',id:4},{kind:'weapon',id:6},{kind:'weapon',id:9},{kind:'armor',id:1},{kind:'armor',id:3},{kind:'armor',id:5},{kind:'armor',id:6},{kind:'armor',id:7},{kind:'armor',id:12}],buyOnly:false})],[txt('Come again!','Merchant')]],1)),[],4);
  npc(m1,9,8,'Villager F',[txt('The fountain is lovely this time of year, isn\'t it?','Villager F')],{type:'random',speed:3,freq:2});
  npc(m1,20,12,'Child',[cm('balloon',{target:0,icon:'Heart',wait:true}),txt('Wanna play? ...Oh, you\'re too busy. Okay!','Child')],{type:'random',speed:4,freq:4});
  npc(m1,25,8,'Guard',[txt('This inn has the best soup in the valley.\\nOh, I\'m not on duty. Just eating.','Guard')],{},2);
  npc(m1,8,15,'Villager M',[txt('They say a dragon sleeps beneath the Old Cave...','Villager M')],{type:'approach',speed:2,freq:1});
  addEv(m1,16,10,'Sign',[page({trigger:0,list:[txt('\\C[6]Greenvale\\C[0]\\nWest: Home   East: Whispering Fields')]})]);
  addEv(m1,10,16,'Fountain heal',[page({trigger:0,list:[txt('The fountain water sparkles. Drink?')].concat(CH(['Drink','Leave'],[[cm('fadeout'),cm('recover',{target:0}),SE('Heal'),cm('wait',{frames:20}),cm('fadein'),txt('You feel refreshed!')],[]],1))})]);
  m1.events[m1.events.length-1].x=10; m1.events[m1.events.length-1].y=16; m1.events[m1.events.length-1].pages[0].img={kind:'none'};
  const mira=npc(m1,11,15,'Mage',[].concat(IF({kind:'switch',a:4,b:'off'},[txt('I\'m \\C[6]Mira\\C[0], a mage. The elder said you\'re heading for the cave? Take me along!','Mage'),cm('balloon',{target:0,icon:'Light bulb',wait:true}),cm('partymember',{actor:2,op:'add',init:true}),cm('setswitch',{a:4,a2:4,val:'on'}),SE('Level Up'),txt('\\C[6]Mira\\C[0] joined the party!'),cm('erase')])),[],4);
  mira.pages=[page({cond:{},img:pre('Mage'),dir:4,list:mira.pages[0].list}),page({cond:{s1:4}})]; mira.pages[1].list=[cm('empty')];
  addEv(m1,6,6,'To Home',[page({trigger:1,list:[SE('Door'),cm('transfer',{mode:'direct',map:4,x:6,y:8,dir:8,fade:'black'})]})]);
  addEv(m1,22,6,'To Inn',[page({trigger:1,list:[SE('Door'),cm('transfer',{mode:'direct',map:5,x:6,y:8,dir:8,fade:'black'})]})]);
  [11,12].forEach(y=>addEv(m1,29,y,'To Fields',[page({trigger:1,list:[cm('transfer',{mode:'direct',map:2,x:1,y:y===11?13:14,dir:6,fade:'black'})]})]));
  chest(m1,27,18,'item',1,3,'Potion x3');

  /* ===== MAP 2: Whispering Fields ===== */
  const m2=R.newMap(2,'Whispering Fields',40,28,tid('Grass'));
  m2.light={mode:'time',ambient:'#1c2246',sun:true,shadows:true,playerLight:0,playerColor:'#ffd9a0'}; m2.bgm='Adventure Field'; m2.encounterStep=26; m2.encounters=[{troop:1,weight:5},{troop:2,weight:4},{troop:3,weight:4},{troop:4,weight:2},{troop:6,weight:2},{troop:9,weight:3}];
  const rng=R.rngf(7);
  for(let i=0;i<70;i++){ const x=Math.floor(rng()*40),y=Math.floor(rng()*28); set(m2,x,y,['Dark Grass','Dark Grass','Dirt'][i%3]); }
  for(let i=0;i<40;i++){ const x=Math.floor(rng()*38)+1,y=Math.floor(rng()*26)+1; if(y>=12&&y<=15) continue; set(m2,x,y,'Tall Grass'); }
  fillR(m2,0,13,31,2,'Dirt'); fillR(m2,30,3,2,12,'Dirt'); fillR(m2,12,18,8,6,'Water'); fillR(m2,14,19,4,3,'Deep Water'); fillR(m2,6,4,5,4,'Sand');
  for(let x=0;x<40;x++){ set(m2,x,0,'Pine Tree'); set(m2,x,27,'Pine Tree'); } for(let y=0;y<28;y++){ if(y<13||y>14) set(m2,0,y,'Pine Tree'); set(m2,39,y,'Pine Tree'); }
  fillR(m2,26,0,10,3,'Rocky Ground'); fillR(m2,26,1,10,1,'Cliff'); fillR(m2,26,0,10,1,'Cliff'); set(m2,30,1,'Dungeon Door'); set(m2,31,1,'Dungeon Door'); fillR(m2,30,2,2,1,'Stone Floor');
  for(let i=0;i<46;i++){ const x=Math.floor(rng()*38)+1,y=Math.floor(rng()*24)+3; if((y>=12&&y<=15)||(x>=11&&x<=20&&y>=17&&y<=24)||(x>=29&&x<=32)) continue; set(m2,x,y,['Tree','Pine Tree','Bush','Rock','Flowers White','Flowers Blue','Mushroom','Small Bush'][i%8]); }
  fillR(m2,3,5,2,1,'Reeds'); set(m2,9,5,'Campfire');
  fillR(m2,35,19,1,1,'Boulder'); fillR(m2,36,20,1,1,'Stump'); fillR(m2,8,22,1,1,'Log'); fillR(m2,21,12,1,1,'Signpost');
  [14,15].forEach(y=>addEv(m2,0,y-1,'To Town',[page({trigger:1,list:[cm('transfer',{mode:'direct',map:1,x:28,y:y-3,dir:4,fade:'black'})]})]));
  m2.events=m2.events.slice(); const xe=[13,14]; m2.events.forEach(e=>{ e.y=e.y; });
  m2.events.length=0; [13,14].forEach(y=>addEv(m2,0,y,'To Town',[page({trigger:1,list:[cm('transfer',{mode:'direct',map:1,x:28,y:y-1,dir:4,fade:'black'})]})]));
  [30,31].forEach(x=>addEv(m2,x,1,'Cave Gate',[page({trigger:1,list:[].concat(IF({kind:'item',a:9},[SE('Door'),cm('transfer',{mode:'direct',map:3,x:15,y:22,dir:8,fade:'black'})],[SE('Buzzer'),txt('The gate is sealed. You need the \\C[6]Old Key\\C[0].'),cm('moveroute',{target:-1,route:[['move',2]],wait:true,repeat:false})]))}) ]));
  addEv(m2,21,12,'Sign',[page({trigger:0,list:[txt('\\C[6]Whispering Fields\\C[0]\\nNorth-east: Old Cave   West: Greenvale')]})]);
  const lyra=npc(m2,8,5,'Healer',[txt('Oh! A traveler. I\'m \\C[6]Lyra\\C[0], a cleric. These fields grow dangerous. May I join you?','Healer'),cm('partymember',{actor:4,op:'add',init:true}),cm('setswitch',{a:6,a2:6,val:'on'}),SE('Level Up'),txt('\\C[6]Lyra\\C[0] joined the party!')],{},2);
  lyra.pages=[lyra.pages[0],page({cond:{s1:6}})]; lyra.pages[1].list=[cm('empty')]; lyra.pages[0].list=lyra.pages[0].list.concat([cm('erase')]);
  chest(m2,36,5,'item',2,2,'Hi-Potion x2'); chest(m2,4,24,'weapon',3,1,'Steel Sword'); chest(m2,33,22,'armor',10,1,'Power Ring');

  /* ===== MAP 3: Old Cave ===== */
  const m3=R.newMap(3,'Old Cave',30,24,tid('Cave Floor')); m3.bgm='Dark Dungeon'; m3.battleBg='Cave'; m3.encounterStep=20; m3.encounters=[{troop:5,weight:4},{troop:7,weight:3},{troop:8,weight:3},{troop:11,weight:2},{troop:12,weight:2}];
  fillR(m3,0,0,30,24,'Cave Wall');
  const carve=(x,y,w,h)=>{ clear(m3,x,y,w,h,1); };
  carve(14,15,3,8); carve(7,10,16,6); carve(4,5,4,6); carve(14,5,3,6); carve(9,1,13,5); carve(22,11,5,3); carve(2,14,6,6); carve(5,17,2,2);
  fillR(m3,8,1,1,1,'Torch Wall'); fillR(m3,22,1,1,1,'Torch Wall'); m3.layers[1][0]=m3.layers[1][0];
  [[10,2],[20,2],[10,4],[20,4]].forEach(([x,y])=>set(m3,x,y,'Pillar')); [[9,12],[21,14],[6,8],[15,8]].forEach(([x,y])=>set(m3,x,y,'Crystal')); [[8,11],[22,15],[3,15]].forEach(([x,y])=>set(m3,x,y,'Skull Pile')); [[12,11],[18,13],[4,7],[16,6],[24,12]].forEach(([x,y])=>set(m3,x,y,'Web')); [[8,13],[19,11]].forEach(([x,y])=>set(m3,x,y,'Rocky Ground')); set(m3,15,3,'Altar'); m3.layers[0][2*30+15]=tid('Dark Floor');
  fillR(m3,9,1,13,5,'Dark Floor'); [[10,2],[20,2],[10,4],[20,4]].forEach(([x,y])=>set(m3,x,y,'Pillar'));
  addEv(m3,15,23,'Exit',[page({trigger:1,list:[cm('transfer',{mode:'direct',map:2,x:30,y:3,dir:2,fade:'black'})]})]); m3.events[0].y=23; m3.layers[1][23*30+15]=0; m3.layers[1][23*30+14]=0; m3.layers[1][23*30+16]=0; m3.layers[0][23*30+15]=tid('Stone Floor');
  const bossSpec={skin:'#d9a878',hair:'#2a2a30',hairStyle:1,outfit:'#3a3a48',outfit2:'#a8353f',boots:'#2a2a30',acc:3,body:2};
  addEv(m3,15,4,'Dark Knight',[page({img:{kind:'custom',spec:bossSpec},dir:2,list:[cm('playbgm',{name:'Boss Battle',vol:100}),txt('\\C[2]Dark Knight\\C[0]: So the key-bearer arrives. None shall pass!'),cm('battle',{kind:'direct',id:13,escape:false,lose:false}),cm('ifwin'),cm('setswitch',{a:1,a2:1,val:'on'}),cm('playbgm',{name:'Dark Dungeon',vol:100}),txt('The Dark Knight crumbles to dust. A dark presence stirs in the altar...')].map((c,i)=>i>=3&&i<=5?Object.assign(c,{i:c.c==='ifwin'?0:1}):c)}),page({cond:{s1:1}})]);
  { const l=m3.events[1].pages[0].list; l.length=0; l.push(cm('playbgm',{name:'Boss Battle',vol:100}),txt('\\C[2]Dark Knight\\C[0]: So the key-bearer arrives. None shall pass!'),cm('battle',{kind:'direct',id:13,escape:false,lose:false}),cm('ifwin'),Object.assign(cm('setswitch',{a:1,a2:1,val:'on'}),{i:1}),Object.assign(cm('playbgm',{name:'Dark Dungeon',vol:100}),{i:1}),Object.assign(txt('The Dark Knight crumbles to dust. A dark presence stirs from the altar...'),{i:1}),cm('endbattle'),cm('empty')); m3.events[1].pages[1].list=[cm('empty')]; }
  m3.light={mode:'fixed',ambient:'#0a0d1c',sun:false,shadows:true,playerLight:190,playerColor:'#ffd9a0'}; [[8,2],[22,2]].forEach(([x,y],i)=>{ const e=addEv(m3,x,y,'Torch '+(i+1),[page({trigger:0,prio:0,through:true})]); e.light={radius:250,color:'#ff9a4a',intensity:110,flicker:35,shadows:true,nightOnly:false,switch:0,glow:true}; });
  addEv(m3,15,2,'Dark Priest',[page({cond:{s1:1},img:{kind:'custom',spec:{skin:'#c8946a',hair:'#2a2a30',hairStyle:4,outfit:'#4a1a6a',outfit2:'#e8c25a',boots:'#2a2a30',acc:6,body:1}},dir:2,list:[txt('\\C[5]Dark Priest\\C[0]: You defeated my knight... Witness the awakening of the \\C[2]Elder Dragon\\C[0]!'),cm('shake',{power:7,speed:7,frames:60,wait:true}),cm('playbgm',{name:'Boss Battle',vol:100}),cm('battle',{kind:'direct',id:14,escape:false,lose:false}),cm('ifwin'),Object.assign(cm('playbgm',{name:'Victory Fanfare',vol:100}),{i:1}),Object.assign(cm('fadeout'),{i:1}),Object.assign(cm('scrolltext',{speed:2,text:'The dragon falls, and peace returns to Greenvale.\n\n\\C[6]Legend of Greenvale\\C[0]\n\nThank you for playing this demo!\n\nMade with RPG Studio.\nAll graphics and sounds are generated by code.'}),{i:1}),Object.assign(cm('title'),{i:1}),cm('endbattle')]})]);
  chest(m3,5,6,'item',4,1,'Elixir'); chest(m3,3,18,'armor',8,1,'Iron Armor'); chest(m3,25,12,'item',8,3,'Bomb x3'); chest(m3,22,2,'weapon',7,1,'Crystal Rod');

  /* ===== MAP 4: Aldric's House ===== */
  const m4=R.newMap(4,"Aldric's House",12,9,tid('Wood Floor')); m4.bgm='Peaceful Village'; m4.encounters=[];
  fillR(m4,0,0,12,2,'Wall Wood'); fillR(m4,0,2,1,7,'Wall Top'); fillR(m4,11,2,1,7,'Wall Top'); fillR(m4,0,8,12,1,'Wall Top'); set(m4,6,8,'Wood Floor'); m4.layers[1][8*12+6]=0; fillR(m4,5,8,1,1,'Wall Top'); fillR(m4,7,8,1,1,'Wall Top');
  set(m4,2,1,'Window'); set(m4,9,1,'Window'); set(m4,5,1,'Painting'); set(m4,2,2,'Bed'); set(m4,3,2,'Bookshelf'); set(m4,8,2,'Cabinet'); set(m4,6,4,'Rug'); set(m4,5,4,'Rug'); set(m4,7,5,'Round Table'); set(m4,8,5,'Chair'); set(m4,9,5,'Plant Pot'); set(m4,2,6,'Pot'); set(m4,3,6,'Barrel'); set(m4,10,2,'Lamp'); set(m4,1,2,'Fireplace');
  npc(m4,5,5,'Villager F',[txt('Oh, \\N[1]! Heading out again? Come, rest a moment.','Villager F'),cm('fadeout'),cm('recover',{target:0}),SE('Heal'),cm('wait',{frames:30}),cm('fadein'),txt('You feel completely refreshed. Take care out there!','Villager F')],{},2);
  addEv(m4,6,8,'Exit',[page({trigger:1,list:[SE('Door'),cm('transfer',{mode:'direct',map:1,x:6,y:8,dir:2,fade:'black'})]})]);
  /* ===== MAP 5: Inn ===== */
  const m5=R.newMap(5,'Silver Moon Inn',12,9,tid('Wood Floor')); m5.bgm='Peaceful Village'; m5.encounters=[];
  fillR(m5,0,0,12,2,'Wall Plaster'); fillR(m5,0,2,1,7,'Wall Top'); fillR(m5,11,2,1,7,'Wall Top'); fillR(m5,0,8,12,1,'Wall Top'); m5.layers[1][8*12+6]=0; m5.layers[1][8*12+5]=tid('Wall Top');
  set(m5,3,1,'Window'); set(m5,8,1,'Window'); set(m5,5,1,'Painting'); set(m5,1,2,'Bed'); set(m5,2,2,'Bed'); set(m5,9,2,'Bookshelf'); set(m5,3,4,'Table'); set(m5,3,5,'Chair'); set(m5,8,5,'Round Table'); set(m5,9,5,'Chair'); set(m5,4,4,'Table'); set(m5,6,3,'Rug'); set(m5,2,6,'Barrel'); set(m5,10,6,'Barrel'); set(m5,6,2,'Lamp'); set(m5,10,2,'Plant Pot');
  npc(m5,5,3,'Merchant',[txt('Welcome to the \\C[6]Silver Moon Inn\\C[0]! A bed costs \\C[6]30\\C[0] \\G.','Merchant')].concat(CH(['Rest (30 \\G)','Leave'],[IF({kind:'gold',op:'>=',b:30},[cm('gold',{op:'-',v:30}),cm('fadeout'),cm('stopbgm'),cm('recover',{target:0}),SE('Heal'),cm('wait',{frames:60}),cm('playbgm',{name:'Peaceful Village',vol:100}),cm('fadein'),txt('Good morning! Sleep well?','Merchant')],[SE('Buzzer'),txt('Not enough gold, I\'m afraid.','Merchant')]),[]],1)),{},2);
  const brann=npc(m5,9,7,'Warrior',[txt('Name\'s \\C[6]Brann\\C[0]. Heard there\'s a boss in that cave. Mind if I tag along?','Warrior'),cm('partymember',{actor:3,op:'add',init:true}),cm('setswitch',{a:5,a2:5,val:'on'}),SE('Level Up'),txt('\\C[6]Brann\\C[0] joined the party!'),cm('erase')],{},4);
  brann.pages=[brann.pages[0],page({cond:{s1:5}})]; brann.pages[1].list=[cm('empty')];
  addEv(m5,6,8,'Exit',[page({trigger:1,list:[SE('Door'),cm('transfer',{mode:'direct',map:1,x:22,y:8,dir:2,fade:'black'})]})]);
  db.maps=[m1,m2,m3,m4,m5]; db.mapTree=db.maps.map(m=>({id:m.id,parent:0}));
  /* ===== Mode aksi: musuh terlihat di peta ===== */
  { const rnd=R.rngf(1234); const pass=(m,x,y)=>[0,1,2,3].every(l=>{ const id=m.layers[l][y*m.w+x]; return !id||(R.TILES[id-1]&&R.TILES[id-1].pass); });
    const spot=(m,minY)=>{ for(let k=0;k<400;k++){ const x=2+Math.floor(rnd()*(m.w-4)), y=Math.max(2,minY||0)+Math.floor(rnd()*(m.h-4-(minY||0))); if(!pass(m,x,y)) continue; if(m.events.some(e=>e&&Math.abs(e.x-x)+Math.abs(e.y-y)<4)) continue; return [x,y]; } return null; };
    const mob=(m,enemy,o)=>{ const sp=o&&o.at||spot(m,o&&o.minY); if(!sp) return; const e=R.newEvent(Math.max(0,...m.events.map(q=>q.id))+1,sp[0],sp[1]); e.name='Enemy '+db.enemies[enemy-1].name; e.mob=Object.assign({enemy:enemy,aggro:5,speed:3,cd:70,wander:true,ranged:false,boss:false,respawn:true,deathSwitch:0,deathCommon:0,dmg:40},o&&o.mob||{}); if(o&&o.cond) e.pages[0].cond=Object.assign(e.pages[0].cond,o.cond); m.events.push(e); return e; };
    [1,1,1,2,2,3,3,5,8].forEach(en=>mob(m2,en)); [4,4,6,6,7,9,10,10,2].forEach(en=>mob(m3,en,{minY:7}));
    // bos Dark Knight
    const dk=m3.events.findIndex(e=>e&&e.name==='Dark Knight'); if(dk>=0) m3.events.splice(dk,1);
    mob(m3,11,{at:[15,4],mob:{boss:true,aggro:8,speed:3,cd:60,deathSwitch:1,respawn:false,dmg:34,phases:R.BOSS_PRESETS.knight}});
    // Dark Priest -> dialog lalu naga muncul
    const pr=m3.events.find(e=>e&&e.name==='Dark Priest'); db.system.switches[7]='Dragon Awake';
    pr.pages[0].list=[txt('\\C[5]Dark Priest\\C[0]: You defeated my knight... Witness the awakening of the \\C[2]Elder Dragon\\C[0]!'),cm('shake',{power:7,speed:7,frames:60,wait:true}),cm('playbgm',{name:'Boss Battle',vol:100}),cm('setswitch',{a:8,a2:8,val:'on'}),cm('erase'),cm('empty')];
    db.commonEvents.push({id:3,name:'Ending',trigger:0,switch:0,list:[cm('playbgm',{name:'Victory Fanfare',vol:100}),cm('fadeout'),cm('scrolltext',{speed:2,text:'The dragon falls, and peace returns to Greenvale.\n\n\\C[6]Legend of Greenvale\\C[0]\n\nThank you for playing this demo!\n\nMade with RPG Studio.\nAll graphics and sounds are generated by code.'}),cm('title'),cm('empty')]});
    mob(m3,12,{at:[14,3],cond:{s1:8},mob:{boss:true,aggro:12,speed:3,cd:55,ranged:false,respawn:false,deathCommon:3,dmg:30,phases:R.BOSS_PRESETS.dragon}}); }
  db.scenes=[{id:1,name:'Sample Cutscene',cinematic:true,list:[cm('fadeout'),cm('wait',{frames:20}),cm('fadein'),txt('\\C[6]Narrator\\C[0]: This is a sample cinematic scene. Edit it in Database → Scenes.'),cm('empty')]}];
  db.commonEvents[0].list=[cm('fadeout'),cm('recover',{target:0}),SE('Heal'),cm('wait',{frames:30}),cm('fadein'),cm('empty')];
  db.commonEvents[1].list=[txt('A gentle spring heals your wounds.'),cm('recover',{target:0}),SE('Heal'),cm('empty')];
  db.system.party=[1]; db.system.startingItems=[{kind:'item',id:1,n:3},{kind:'item',id:6,n:3}];
  return db;
};
})();
