/* Sistem pertarungan: efek skill/item + Scene_Battle (side-view, turn based) */
(function(){
'use strict';
const R = window.RPG, UI = R.UI, H = R.H;
const rnd = (a,b)=> a+Math.floor(Math.random()*(b-a+1));

/* ---------- efek skill/item ---------- */
R.useOn = function(user,target,d,isItem,opts){
  opts=opts||{}; const res={hit:true,crit:false,hp:0,mp:0,added:[],removed:[],revived:false,fail:false,evaded:false};
  const type=d.type||'damage';
  if(type==='revive'){ if(!target.isDead()){ res.fail=true; return res; } target.removeState(1); let v=d.formula? R.evalFormula(d.formula,user,target): 0; if(isItem) v=target.mhp*(d.hpPct||50)/100; target.hp=Math.max(1,Math.min(target.mhp,Math.round(v))); res.hp=-target.hp; res.revived=true; return res; }
  if(target.isDead()&&type!=='heal') { res.fail=true; return res; }
  if(type==='damage'){
    const hitRate=(d.hit||100)/100 - (user!==target&&!opts.noEvade? Math.min(.3,Math.max(0,(target.agi-user.agi)*.005)):0);
    if(Math.random()>hitRate){ res.hit=false; res.evaded=true; return res; }
    let v=R.evalFormula(d.formula,user,target); const er=target.elementRate(d.element||0)/100; v*=er; res.elemRate=er;
    if(target.hasState(2)) v*=.5;
    const crit=d.crit!==false && !isItem && Math.random()<(.04+Math.max(0,user.luk-target.luk)/400); if(crit){ v*=1.8; res.crit=true; }
    const va=(d.variance===undefined?15:d.variance)/100; v*= 1+(Math.random()*2-1)*va;
    v=Math.max(0,Math.round(v)); target.gainHp(-v); res.hp=v; if(v===0) res.noDmg=true;
  } else if(type==='heal'){
    let v=d.formula? R.evalFormula(d.formula,user,target):0; if(isItem||d.hp!==undefined&&!d.formula){ v=(d.hp||0)+target.mhp*(d.hpPct||0)/100 + (d.formula? R.evalFormula(d.formula,user,target):0); } if(!isItem||true){ const va=(d.variance||0)/100; v*=1+(Math.random()*2-1)*va; }
    v=Math.round(v); if(v!==0){ target.gainHp(v); res.hp=-v; }
    const m=Math.round((d.mp||0)+target.mmp*(d.mpPct||0)/100); if(m){ target.gainMp(m); res.mp=-m; }
  }
  if(isItem&&type!=='heal'&&type!=='damage'){ const m=Math.round((d.mp||0)+target.mmp*(d.mpPct||0)/100); if(m){ target.gainMp(m); res.mp=-m; } }
  if(isItem&&type==='heal'&&d.mp===undefined){}
  for(const s of d.addStates||[]){ const resist=target.isActor?100:((target.data.stateRes&&target.data.stateRes[s.id]!==undefined)?target.data.stateRes[s.id]:100); if(Math.random()*100 < (s.rate||100)*resist/100){ if(!target.hasState(s.id)&&target.addState(s.id)) res.added.push(s.id); else if(target.hasState(s.id)) target.addState(s.id); } }
  for(const id of d.removeStates||[]){ if(target.removeState(id)) res.removed.push(id); }
  if(target.hp<=0&&!target.isDead()){ target.addState(1); res.dead=true; }
  if(type==='damage'&&target.isDead()) res.dead=true;
  return res;
};
R.Battler.prototype.isDead=R.Battler.prototype.isDead;
R.isForOpponent = sc => sc===1||sc===2; R.isForFriend = sc => sc>=3;

/* ---------- koroutin ---------- */
R.Co = class {
  constructor(gen){ this.gen=gen; this.wait=0; this.done=false; }
  step(){ if(this.done) return; if(this.wait>0){ this.wait--; return; } let r; try{ r=this.gen.next(); }catch(e){ console.error(e); this.done=true; return; } if(r.done){ this.done=true; return; } if(typeof r.value==='number') this.wait=Math.max(0,r.value-1); }
};

/* ---------- latar ---------- */
const BG = {
  Grass:g=>{ const gr=g.createLinearGradient(0,0,0,440); gr.addColorStop(0,'#7ec4f0'); gr.addColorStop(.52,'#cfeaf8'); gr.addColorStop(.53,'#6bb85b'); gr.addColorStop(1,'#3f8a3a'); g.fillStyle=gr; g.fillRect(0,0,816,440); for(let i=0;i<5;i++){ H.circ(g,'rgba(255,255,255,.85)',100+i*170,70+(i%2)*30,28+i%3*8); H.circ(g,'rgba(255,255,255,.85)',130+i*170,78+(i%2)*30,22); } H.poly(g,'#5a8a6a',0,230,160,120,320,230); H.poly(g,'#6a9a7a',240,230,420,100,600,230); H.poly(g,'#5a8a6a',520,230,700,130,816,230); },
  Cave:g=>{ const gr=g.createLinearGradient(0,0,0,440); gr.addColorStop(0,'#1a1220'); gr.addColorStop(.5,'#3a2a3a'); gr.addColorStop(.51,'#4a3a2e'); gr.addColorStop(1,'#2a1f18'); g.fillStyle=gr; g.fillRect(0,0,816,440); for(let i=0;i<14;i++){ H.poly(g,'#2a1e2a',i*60,0,i*60+30,40+(i*37%60),i*60+60,0); } for(let i=0;i<8;i++){ H.circ(g,'rgba(140,100,220,.25)',60+i*100,200+(i*53%50),24); } },
  Snow:g=>{ const gr=g.createLinearGradient(0,0,0,440); gr.addColorStop(0,'#aac8e8'); gr.addColorStop(.52,'#e4eef8'); gr.addColorStop(.53,'#f4f8fc'); gr.addColorStop(1,'#cfdcec'); g.fillStyle=gr; g.fillRect(0,0,816,440); H.poly(g,'#cfdcec',0,230,200,110,400,230); H.poly(g,'#dbe6f2',300,230,520,90,740,230); },
  Desert:g=>{ const gr=g.createLinearGradient(0,0,0,440); gr.addColorStop(0,'#f0c880'); gr.addColorStop(.52,'#f8e4b0'); gr.addColorStop(.53,'#e8cf8f'); gr.addColorStop(1,'#c9a860'); g.fillStyle=gr; g.fillRect(0,0,816,440); H.circ(g,'#fff4b0',640,90,44); },
  Castle:g=>{ const gr=g.createLinearGradient(0,0,0,440); gr.addColorStop(0,'#3a3a52'); gr.addColorStop(.52,'#55556e'); gr.addColorStop(.53,'#8a7a6a'); gr.addColorStop(1,'#5a4a3a'); g.fillStyle=gr; g.fillRect(0,0,816,440); for(let i=0;i<6;i++){ H.rect(g,'#2a2a3a',30+i*140,40,50,230); H.rect(g,'#2a2a3a',24+i*140,30,62,14); } }
};
const bgCache = {};
R.battleBgCanvas = function(name){ if(bgCache[name]) return bgCache[name]; const c=R.mkCanvas(816,440); (BG[name]||BG.Grass)(c.getContext('2d')); return (bgCache[name]=c); };
R.BATTLE_BGS = Object.keys(BG);

/* ---------- Scene_Battle ---------- */
R.Scene_Battle = class {
  constructor(troopId,opts){ opts=opts||{}; this.troopId=troopId; this.canEscape=opts.escape!==false; this.canLose=!!opts.lose; this.onEnd=opts.onEnd; this.result=-1; this.t=0; this.popups=[]; this.anims=[]; this.log=[]; this.shake=0; this.flash=0; this.escRatio=0; this.turn=0; this.lists={}; this.targetHL=null; this.fadeIn=30; this.currentActor=null; this.offsets=new Map(); this.blink=new Map(); this.defeatedFade=new Map(); }
  start(){ const db=R.$db, g=R.$game; const troop=db.troops[this.troopId-1]; this.troop=troop; this.bg=troop.bg||'Grass';
    this.enemies=[]; const cnt={}; troop.members.forEach(id=>{ cnt[id]=(cnt[id]||0)+1; }); const seen={}; troop.members.forEach((id,i)=>{ const e=new R.Enemy(id,i); seen[id]=(seen[id]||0)+1; if(cnt[id]>1) e.letter=String.fromCharCode(64+seen[id]); this.enemies.push(e); });
    const n=this.enemies.length; this.enemies.forEach((e,i)=>{ const big=db.enemies[e.id-1].mhp>=250; e.scale=n===1&&big?1.35:big?1:.82; if(n===1){ e.x=230; e.y=300; } else { e.x=110+(i%2)*150+(Math.floor(i/2)%2)*34; e.y=205+Math.floor(i/2)*84+(i%2)*46; } e.sprite=R.makeMonster(e.data.kind,e.data.color); });
    this.party=g.party.slice(0,4); this.party.forEach((a,i)=>{ a.bx=590+i*34; a.by=150+i*66; });
    this.isBoss=troop.name&&/boss/i.test(troop.name); const bgm=this.isBoss?db.system.bossBgm:db.system.battleBgm; R.Audio.playBgm(bgm); R.Audio.se('Encounter');
    this.co=new R.Co(this.main()); }
  allEnemies(){ return this.enemies.filter(e=>e.isAlive()); }
  name(b){ return b.isActor? b.name : b.name+(b.letter?' '+b.letter:''); }
  *msg(text,frames){ this.log.push(text); if(this.log.length>5) this.log.shift(); this.logT=0; yield (frames===undefined?36:frames); }
  *main(){
    yield 20; yield* this.msg(UI.expand(R.$db.system.terms.emerge).replace('%s',this.enemies.length?this.name(this.enemies[0])+(this.enemies.length>1?' & co.':''):'?'),40);
    this.turn=0; this.escRatio=.5*this.avg(this.party,'agi')/Math.max(1,this.avg(this.enemies,'agi'));
    while(true){
      this.turn++; this.log=[];
      const actions=[]; this.currentActor=null;
      // input
      for(const a of this.party){ if(a.isDead()) continue; a.tmp.guard=false; if(a.states.some(s=>s.id===2)) a.removeState(2); }
      const cmd=yield* this.partyCommand();
      if(cmd==='escape'){ yield* this.msg(UI.expand(R.$db.system.terms.escapeStart).replace('%s',this.party[0].name),30); if(Math.random()<this.escRatio){ R.Audio.se('Escape'); this.result=1; yield 20; return this.finish(); } this.escRatio+=.1; yield* this.msg(R.$db.system.terms.escapeFail,40); }
      else { for(const a of this.party){ if(!a.canMove()) continue; const act=yield* this.actorCommand(a); if(act==='back'){ break; } if(act) actions.push(act); } }
      if(cmd==='escape'){ for(const e of this.allEnemies()) actions.push(this.enemyAction(e)); }
      else { for(const e of this.allEnemies()) actions.push(this.enemyAction(e)); }
      this.lists={}; this.currentActor=null;
      // sort by speed
      actions.forEach(a=>{ a.spd=a.subject.agi+(a.skill&&a.skill.speed||0)*100+Math.random()*10; if(a.guard) a.spd+=9999; });
      actions.sort((a,b)=>b.spd-a.spd);
      for(const act of actions){ if(this.result>=0) break; if(!act.subject.canMove()&&!act.guard) { if(act.subject.isAlive()) { const rs=act.subject.states.map(s=>R.$db.states[s.id-1]).find(s=>s&&s.restrict>=4); if(rs) yield* this.msg(this.name(act.subject)+' cannot move!',30); } continue; } yield* this.doAction(act); const end=this.checkEnd(); if(end>=0){ this.result=end; break; } }
      if(this.result>=0){ yield 20; return this.finish(); }
      // turn end
      for(const b of this.party.concat(this.enemies)){ if(b.isDead()) continue; const lg=b.turnEnd(); for(const l of lg){ if(l.v<0){ this.pop(b,Math.abs(l.v),'#ff8a8a'); yield* this.msg(UI.expand(R.$db.system.terms.dmg).replace('%s',this.name(b)).replace('%s',Math.abs(l.v)),24); R.Audio.se('Hit'); } else if(l.v>0){ this.pop(b,l.v,'#9cf0a8'); } } if(b.isDead()){ yield* this.msg(this.name(b)+' is defeated!',30); } }
      const end=this.checkEnd(); if(end>=0){ this.result=end; yield 20; return this.finish(); }
    }
  }
  avg(l,p){ const a=l.filter(x=>x.isAlive()); if(!a.length) return 1; return a.reduce((s,x)=>s+x[p],0)/a.length; }
  checkEnd(){ if(this.allEnemies().length===0) return 0; if(R.$game.party.every(a=>a.isDead())) return 2; return -1; }
  /* ---- input ---- */
  *partyCommand(){ const T=R.$db.system.terms; const items=[T.fight].concat(this.canEscape?[T.escape]:[]); const L=new UI.List({x:0,y:444,w:220,h:180,items:items,rowH:40,cancelable:false}); this.lists.cmd=L; this.lists.status=null; while(true){ const r=L.update(); if(r==='ok'){ delete this.lists.cmd; return L.index===0?'fight':'escape'; } yield; } }
  *actorCommand(a){ this.currentActor=a; const T=R.$db.system.terms; const L=new UI.List({x:0,y:444,w:220,h:180,items:[T.attack,T.skill,T.guard,T.item],rowH:40,cancelable:false}); this.lists.cmd=L;
    while(true){ const r=L.update(); if(r==='cancel'){ } if(r==='ok'){ const i=L.index;
        if(i===0){ const tg=yield* this.chooseTarget(a,R.$db.skills[0]); if(tg){ delete this.lists.cmd; return {subject:a,skill:R.$db.skills[0],targets:tg}; } }
        else if(i===1){ const sk=yield* this.chooseSkill(a); if(sk){ const tg=yield* this.chooseTarget(a,sk); if(tg){ delete this.lists.cmd; return {subject:a,skill:sk,targets:tg}; } } }
        else if(i===2){ delete this.lists.cmd; return {subject:a,skill:R.$db.skills[1],targets:[a],guard:true}; }
        else { const it=yield* this.chooseItem(a); if(it){ const tg=yield* this.chooseTarget(a,it); if(tg){ delete this.lists.cmd; return {subject:a,item:it,targets:tg}; } } } }
      if(R.Input.pressed('cancel')&&this.party.indexOf(a)>0){ return 'back'; }
      yield; } }
  *chooseSkill(a){ const db=R.$db; const ids=a.skills.filter(id=>{ const s=db.skills[id-1]; return s&&id!==1&&id!==2&&s.occasion!==2&&s.occasion!==3; }); if(!ids.length){ R.Audio.se('Buzzer'); return null; }
    const L=new UI.List({x:220,y:444,w:596,h:180,items:ids,cols:2,rowH:38,enabled:id=>db.skills[id-1].mp<=a.mp,draw:(g,id,i,r,en)=>{ const s=db.skills[id-1]; R.drawIcon(g,s.icon,r.x,r.y+3,28); UI.text(g,s.name,r.x+34,r.y+r.h/2,{maxW:r.w-110}); UI.text(g,s.mp+' '+db.system.terms.mp,r.x+r.w-8,r.y+r.h/2,{align:'right',size:18,color:'#9cf'}); }}); this.lists.sub=L; this.lists.help=true;
    while(true){ const r=L.update(); this.helpText=L.items.length?db.skills[L.items[L.index]-1].desc:''; if(r==='cancel'){ delete this.lists.sub; this.lists.help=false; return null; } if(r==='ok'){ delete this.lists.sub; this.lists.help=false; return db.skills[L.items[L.index]-1]; } yield; } }
  *chooseItem(a){ const db=R.$db, g=R.$game; const ids=Object.keys(g.items).map(Number).filter(id=>{ const it=db.items[id-1]; return it&&!it.key&&it.occasion<=1; }); if(!ids.length){ R.Audio.se('Buzzer'); return null; }
    const L=new UI.List({x:220,y:444,w:596,h:180,items:ids,cols:2,rowH:38,draw:(g2,id,i,r)=>{ const it=db.items[id-1]; R.drawIcon(g2,it.icon,r.x,r.y+3,28); UI.text(g2,it.name,r.x+34,r.y+r.h/2,{maxW:r.w-80}); UI.text(g2,'x'+g.items[id],r.x+r.w-8,r.y+r.h/2,{align:'right',size:18}); }}); this.lists.sub=L; this.lists.help=true;
    while(true){ const r=L.update(); this.helpText=L.items.length?db.items[L.items[L.index]-1].desc:''; if(r==='cancel'){ delete this.lists.sub; this.lists.help=false; return null; } if(r==='ok'){ delete this.lists.sub; this.lists.help=false; return db.items[L.items[L.index]-1]; } yield; } }
  *chooseTarget(a,obj){ const sc=obj.scope; if(sc===0||sc===5) return [a]; if(sc===2) return this.allEnemies(); if(sc===4) return this.party.filter(m=>m.isAlive());
    const foe=sc===1; const pool=foe? this.allEnemies() : (sc===6? this.party.filter(m=>m.isDead()) : this.party.filter(m=>m.isAlive())); if(!pool.length){ R.Audio.se('Buzzer'); return null; }
    const L=new UI.List({x:220,y:444,w:596,h:180,items:pool,cols:2,rowH:38,draw:(g,b,i,r)=>{ UI.text(g,this.name(b),r.x+6,r.y+r.h/2,{maxW:r.w-12}); }}); this.lists.sub=L;
    while(true){ const r=L.update(); this.targetHL=L.items[L.index]; if(r==='cancel'){ delete this.lists.sub; this.targetHL=null; return null; } if(r==='ok'){ delete this.lists.sub; this.targetHL=null; return [L.items[L.index]]; } yield; } }
  enemyAction(e){ const d=e.data; const acts=(d.actions||[]).filter(a=>{ const sk=R.$db.skills[a.skill-1]; if(!sk||sk.mp>e.mp) return false; const c=a.cond||'always'; if(c==='always') return true; let m; if((m=/^hp<(\d+)$/.exec(c))) return e.hp/e.mhp*100<+m[1]; if((m=/^turn>=(\d+)$/.exec(c))) return this.turn>=+m[1]; if((m=/^turn=(\d+)$/.exec(c))) return this.turn===+m[1]; if((m=/^state(\d+)$/.exec(c))) return e.hasState(+m[1]); return true; });
    let sk=R.$db.skills[0]; if(acts.length){ const tot=acts.reduce((s,a)=>s+(a.rating||1),0); let r=Math.random()*tot; for(const a of acts){ r-=(a.rating||1); if(r<=0){ sk=R.$db.skills[a.skill-1]; break; } } }
    return {subject:e,skill:sk,targets:null}; }
  autoTargets(sub,sk){ const rs=sub.restriction(); let foes=sub.isActor?this.allEnemies():this.party.filter(m=>m.isAlive()); let friends=sub.isActor?this.party.filter(m=>m.isAlive()):this.allEnemies();
    if(rs===2){ const all=foes.concat(friends); return [all[rnd(0,all.length-1)]]; } if(rs===3){ return [friends[rnd(0,friends.length-1)]]; }
    const sc=sk.scope; if(sc===2) return foes; if(sc===4) return friends; if(sc===5||sc===0) return [sub]; if(sc===3) { const f=friends.slice().sort((a,b)=>a.hp/a.mhp-b.hp/b.mhp); return [f[0]||sub]; } if(sc===6) { const d=(sub.isActor?this.party:this.enemies).filter(m=>m.isDead()); return d.length?[d[0]]:[]; }
    return foes.length? [foes[rnd(0,foes.length-1)]] : []; }
  /* ---- eksekusi aksi ---- */
  *doAction(act){ const sub=act.subject, T=R.$db.system.terms; const obj=act.skill||act.item; if(!obj) return; this.currentActor=sub.isActor?sub:null;
    if(act.guard){ sub.addState(2); yield* this.msg(UI.expand(R.$db.states[1].msg||'%s guards.').replace('%s',this.name(sub)),26); return; }
    let targets=act.targets; const rs=sub.restriction(); if(!targets||rs===2||rs===3){ targets=this.autoTargets(sub,act.skill||{scope:1}); } else { targets=targets.filter(t=>act.skill&&act.skill.scope===6? t.isDead():(act.item&&act.item.scope===6? t.isDead():t.isAlive()||(act.skill&&act.skill.type==='revive'))); if(!targets.length) targets=this.autoTargets(sub,act.skill||act.item); }
    if(act.skill&&act.skill.type!=='revive'&&targets.length===0) return;
    if(act.skill){ const sk=act.skill; if(sk.mp>sub.mp){ yield* this.msg(this.name(sub)+' lacks MP!',26); return; } sub.gainMp(-sk.mp); const m=sk.id===1? '%s attacks!' : sk.msg||'%s uses %s!'; yield* this.msg(m.replace('%s',this.name(sub)).replace('%s',sk.name),30); }
    else { const it=act.item; if(R.$game.numItems('item',it.id)<=0) return; if(it.consumable) R.$game.gainItem('item',it.id,-1); yield* this.msg(this.name(sub)+' uses '+it.name+'!',30); }
    // maju
    const dirX=sub.isActor?-1:1; if(sub.isActor||true){ for(let i=0;i<8;i++){ this.offsets.set(sub,dirX*i*5); yield 1; } }
    const reps=(act.skill&&act.skill.repeats)||1; const animName=(act.skill&&act.skill.anim)||(act.item&&act.item.anim)||'Hit'; const weaponAnim=act.skill&&act.skill.id===1&&sub.isActor? (sub.equipItem(0)&&sub.equipItem(0).anim):null;
    for(let rep=0;rep<reps;rep++){ for(const tg of targets){ if(this.result>=0) break;
        this.anims.push({name:weaponAnim||animName,x:tg.isActor?tg.bx:tg.x,y:tg.isActor?tg.by-20:tg.y-30,t:0,dur:26}); const wasDead=tg.isDead(); yield 14; const res=R.useOn(sub,tg,act.skill||act.item,!!act.item); yield* this.applyResult(sub,tg,res,act,wasDead); yield 8; } }
    for(let i=7;i>=0;i--){ this.offsets.set(sub,dirX*i*5); yield 1; } this.offsets.delete(sub); }
  pop(b,text,color){ const x=b.isActor?b.bx:b.x, y=(b.isActor?b.by-50:b.y-60); this.popups.push({text:String(text),x:x,y:y,t:0,color:color||'#fff'}); }
  *applyResult(sub,tg,res,act,wasDead){ const T=R.$db.system.terms; const nm=this.name(tg);
    if(res.fail){ yield* this.msg('It had no effect.',24); return; }
    if(res.evaded){ R.Audio.se('Cancel'); this.pop(tg,'MISS','#cde'); yield* this.msg(UI.expand(T.evade).replace('%s',nm),26); return; }
    if(res.hp>0){ R.Audio.se(res.crit?'Crit':'Hit'); if(res.crit) this.shake=10; this.blink.set(tg,14); this.pop(tg,res.hp,res.crit?'#ffe27a':'#fff'); if(res.crit) yield* this.msg(T.critical,22); yield* this.msg(UI.expand(T.dmg).replace('%s',nm).replace('%s',res.hp),28); if(tg.isActor) this.shake=Math.max(this.shake,6); }
    else if(res.noDmg){ yield* this.msg(UI.expand(T.noDmg).replace('%s',nm),24); }
    else if(res.hp<0){ R.Audio.se('Heal'); this.pop(tg,-res.hp,'#9cf0a8'); yield* this.msg(UI.expand(T.hpHeal).replace('%s',nm).replace('%s',-res.hp),28); }
    if(res.mp<0){ this.pop(tg,-res.mp+' MP','#9cd0ff'); yield* this.msg(UI.expand(T.mpHeal).replace('%s',nm).replace('%s',-res.mp),24); }
    for(const id of res.added){ const s=R.$db.states[id-1]; if(s&&s.msg&&id!==1) yield* this.msg(UI.expand(s.msg).replace('%s',nm),26); }
    if(tg.isDead()&&!wasDead){ yield* this.msg(nm+(tg.isActor?' is knocked out!':' is defeated!'),30); if(!tg.isActor) this.defeatedFade.set(tg,30); }
    if(res.revived){ yield* this.msg(nm+' is revived!',24); } }
  /* ---- hasil ---- */
  finish(){ this.co=new R.Co(this.end()); }
  *end(){ const db=R.$db, g=R.$game, T=db.system.terms;
    for(const a of this.party) a.onBattleEnd(); g.battles++;
    if(this.result===0){ R.Audio.stopBgm(); R.Audio.se('Victory'); R.Audio.playBgm(db.system.victoryBgm); this.log=[]; yield* this.msg(UI.expand(T.victory).replace('%s',this.party[0].name+(this.party.length>1?"'s party":'')),50);
      let exp=0,gold=0; const drops=[]; for(const e of this.enemies){ exp+=e.data.exp; gold+=e.data.gold; for(const d of e.data.drops||[]){ if(Math.random()*100<d.rate) drops.push(d); } }
      yield* this.msg(UI.expand(T.gainExp).replace('%s',exp),40); if(gold){ g.gainGold(gold); yield* this.msg(UI.expand(T.gainGold).replace('%s',gold),40); }
      for(const d of drops){ g.gainItem(d.kind,d.id,1); const lst=d.kind==='item'?db.items:d.kind==='weapon'?db.weapons:db.armors; yield* this.msg(UI.expand(T.obtainItem).replace('%s',lst[d.id-1].name),36); }
      for(const a of this.party){ if(a.isDead()) continue; const lv=a.gainExp(exp); for(const l of lv){ R.Audio.se('Level Up'); yield* this.msg(UI.expand(T.levelUp).replace('%s',a.name).replace('%s',l.level),50); for(const s of l.newSkills) yield* this.msg(a.name+' learned '+db.skills[s-1].name+'!',44); } }
      for(const a of this.party) if(a.isDead()){ a.hp=1; a.states=[]; }
      yield 20; }
    else if(this.result===2){ yield* this.msg(UI.expand(T.defeat).replace('%s',this.party[0].name+"'s party"),60); if(this.canLose){ for(const a of this.party){ if(a.isDead()){ a.states=[]; a.hp=1; } } } }
    this.fadeOut=30; yield 30; this.done=true; }
  /* ---- loop ---- */
  update(){ this.t++; if(this.fadeIn>0) this.fadeIn--; if(this.fadeOut>0) this.fadeOut--; this.co.step(); R.Input.flush && 0; if(this.shake>0) this.shake--; this.popups.forEach(p=>p.t++); this.popups=this.popups.filter(p=>p.t<46); this.anims.forEach(a=>a.t++); this.anims=this.anims.filter(a=>a.t<a.dur); for(const [k,v] of this.blink) { if(v<=1) this.blink.delete(k); else this.blink.set(k,v-1); } for(const [k,v] of this.defeatedFade) this.defeatedFade.set(k,Math.max(0,v-1)); if(this.done&&this.onEnd){ const f=this.onEnd; this.onEnd=null; f(this.result); } }
  draw(g){ const ox=this.shake? (Math.random()-.5)*this.shake*1.2:0, oy=this.shake? (Math.random()-.5)*this.shake*.8:0; g.save(); g.translate(ox,oy); g.drawImage(R.battleBgCanvas(this.bg),0,0);
    // enemy
    for(const e of this.enemies){ const fade=this.defeatedFade.has(e)? this.defeatedFade.get(e)/30 : (e.isDead()?0:1); if(fade<=0) continue; const off=this.offsets.get(e)||0; const bl=this.blink.get(e); const s=e.scale, w=160*s, h=160*s; g.save(); g.globalAlpha=fade*((bl&&bl%4<2)?.4:1); g.drawImage(e.sprite,e.x-w/2+off,e.y-h*.8,w,h); if(this.targetHL===e||(this.lists.sub&&this.targetHL===e)){ g.globalAlpha=.4+.3*Math.sin(this.t/4); UI.cursor(g,e.x-w/2,e.y-h*.8,w,h,this.t); } g.restore(); if(e.isAlive()&&this.targetHL===e) UI.text(g,this.name(e),e.x,e.y+22,{align:'center',size:18}); }
    // party
    this.party.forEach((a,i)=>{ const sheet=R.charSheet(a.img); const off=this.offsets.get(a)||0; const bl=this.blink.get(a); const hl=this.targetHL===a||this.currentActor===a; let dx=a.bx+off, dy=a.by; if(hl&&this.currentActor===a&&!this.offsets.has(a)) dx-=14; g.save(); const dead=a.isDead(); if(sheet){ const col=dead?1:(Math.floor(this.t/20)%2?1:1); if(dead){ g.translate(dx,dy); g.rotate(-1.4); g.translate(-dx,-dy); g.globalAlpha=.6; } else g.globalAlpha=(bl&&bl%4<2)?.4:1; g.imageSmoothingEnabled=false; g.drawImage(sheet,48,48,48,48,dx-48,dy-76,96,96); } if(hl&&this.targetHL===a) UI.cursor(g,dx-44,dy-72,88,92,this.t); g.restore(); });
    for(const an of this.anims) R.drawAnim(g,an.name,an.x,an.y,an.t/an.dur);
    for(const p of this.popups){ const t=p.t/46; const y=p.y-Math.sin(Math.min(1,t*2)*Math.PI)*12-t*10; UI.text(g,p.text,p.x,y,{align:'center',size:30,color:p.color}); }
    g.restore();
    // log
    if(this.log.length){ const lines=this.log.slice(-4); UI.win(g,100,10,616,lines.length*32+20,{alpha:.8}); lines.forEach((l,i)=>UI.text(g,UI.stripCodes(l),120,36+i*32,{size:22,maxW:576,bold:i===lines.length-1})); }
    // status
    const db=R.$db; UI.win(g,220,444,596,180); const st=this.lists.sub?null:true;
    if(!this.lists.sub){ this.party.forEach((a,i)=>{ const y=458+i*40; if(this.currentActor===a) UI.cursor(g,230,y-4,576,38,this.t); UI.text(g,a.name,242,y+14,{size:20,maxW:130}); UI.text(g,db.system.terms.hp,388,y+14,{size:15,color:'#8cf'}); UI.gauge(g,414,y+8,150,12,a.hp/a.mhp,'#e8433f','#f5a33a'); UI.text(g,a.hp+'/'+a.mhp,570,y+14,{size:15,maxW:80}); UI.gauge(g,650,y+8,100,12,a.mmp?a.mp/a.mmp:0,'#3a7fe8','#6ad0ff'); UI.text(g,a.mp+'',760,y+14,{size:15}); let sx=242+130; a.states.slice(0,3).forEach(s=>{ R.drawIcon(g,db.states[s.id-1].icon,sx-6,y-2,22); sx+=24; }); }); }
    if(!this.lists.cmd){ UI.win(g,0,444,220,180); UI.text(g,'Turn '+this.turn,110,534,{align:'center',size:24,color:'#9cf'}); }
    if(this.lists.cmd) this.lists.cmd.draw(g); if(this.lists.sub){ this.lists.sub.draw(g); }
    if(this.lists.help&&this.helpText) { UI.win(g,100,10,616,52); UI.text(g,this.helpText,120,36,{size:20,maxW:580}); }
    if(this.fadeIn>0){ g.fillStyle='rgba(255,255,255,'+(this.fadeIn/30)+')'; g.fillRect(0,0,816,624); }
    if(this.fadeOut>0||this.done){ g.fillStyle='rgba(0,0,0,'+(1-this.fadeOut/30)+')'; g.fillRect(0,0,816,624); } }
};
})();
