/* RPG Studio - aset prosedural (semua orisinal, digambar lewat kode). Bagian 1: helper + tile Ground & Nature */
(function(){
'use strict';
const R = window.RPG = window.RPG || {};
const T = R.TILE = 48;

function mk(w,h){ const c=document.createElement('canvas'); c.width=w; c.height=h; return c; }
R.mkCanvas = mk;
function rngf(seed){ let s=((seed*2654435761)>>>0)||123456789; return function(){ s^=s<<13; s>>>=0; s^=s>>>17; s^=s<<5; s>>>=0; return s/4294967296; }; }
R.rngf = rngf;
function hex2rgb(h){ h=h.replace('#',''); if(h.length===3) h=h.split('').map(c=>c+c).join(''); const n=parseInt(h,16); return [n>>16&255,n>>8&255,n&255]; }
function shade(h,a){ const m=hex2rgb(h); const f=v=>Math.max(0,Math.min(255,Math.round(a<0? v*(1+a) : v+(255-v)*a))); return 'rgb('+f(m[0])+','+f(m[1])+','+f(m[2])+')'; }
R.shade = shade;

const H = R.H = {
  fill(g,c,x,y,w,h){ g.fillStyle=c; g.fillRect(x||0,y||0,w===undefined?T:w,h===undefined?T:h); },
  rect(g,c,x,y,w,h){ g.fillStyle=c; g.fillRect(x,y,w,h); },
  circ(g,c,x,y,r){ g.fillStyle=c; g.beginPath(); g.arc(x,y,r,0,6.2832); g.fill(); },
  ell(g,c,x,y,rx,ry){ g.fillStyle=c; g.beginPath(); g.ellipse(x,y,rx,ry,0,0,6.2832); g.fill(); },
  poly(g,c){ const p=Array.prototype.slice.call(arguments,2); g.fillStyle=c; g.beginPath(); g.moveTo(p[0],p[1]); for(let i=2;i<p.length;i+=2) g.lineTo(p[i],p[i+1]); g.closePath(); g.fill(); },
  line(g,c,x1,y1,x2,y2,w){ g.strokeStyle=c; g.lineWidth=w||1; g.lineCap='round'; g.beginPath(); g.moveTo(x1,y1); g.lineTo(x2,y2); g.stroke(); },
  rr(g,c,x,y,w,h,r){ g.fillStyle=c; g.beginPath(); g.moveTo(x+r,y); g.arcTo(x+w,y,x+w,y+h,r); g.arcTo(x+w,y+h,x,y+h,r); g.arcTo(x,y+h,x,y,r); g.arcTo(x,y,x+w,y,r); g.closePath(); g.fill(); },
  speckle(g,r,cols,n,s){ s=s||3; for(let i=0;i<n;i++){ g.fillStyle=cols[(r()*cols.length)|0]; g.fillRect((r()*T)|0,(r()*T)|0,((r()*s)|0)+1,((r()*s)|0)+1); } },
  shadow(g,x,y,rx,ry){ H.ell(g,'rgba(0,0,0,.28)',x===undefined?24:x,y===undefined?42:y,rx||14,ry||5); }
};
const {fill,rect,circ,ell,poly,line,rr,speckle,shadow} = H;

R.TILE_TABS = [['A','Ground'],['B','Nature'],['C','Interior'],['D','Town'],['E','Dungeon']];
const defs = R.TILES = [];
R.TILE_BY_NAME = {};
function D(name,tab,o,draw){
  const d = Object.assign({id:defs.length+1,name:name,tab:tab,layer:0,pass:true,star:false,bush:false,counter:false,damage:false,anim:false,auto:false,edge:null,draw:draw},o||{});
  defs.push(d); R.TILE_BY_NAME[name]=d; return d;
}
R.D_TILE = D;
// ground helper
function GR(name,base,extra,o){
  return D(name,'A',Object.assign({auto:true,base:base,edge:shade(base,-.33)},o||{}),function(g,r,f){ fill(g,base); extra(g,r,f); });
}
GR('Grass','#62a84f',(g,r)=>{ speckle(g,r,['#4f9440','#74b95f','#58a046'],46,3); for(let i=0;i<9;i++){ const x=r()*44+2,y=r()*40+6; line(g,'#3f8236',x,y,x-2,y-5,1.4); line(g,'#4a8f3e',x,y,x+2,y-4,1.4);} });
GR('Dark Grass','#3f7a3a',(g,r)=>{ speckle(g,r,['#2f6a2f','#4c8a44','#356f33'],46,3); for(let i=0;i<7;i++){ const x=r()*44+2,y=r()*40+6; line(g,'#2a5e2a',x,y,x-2,y-5,1.4);} });
GR('Dirt','#a8764a',(g,r)=>{ speckle(g,r,['#8f6238','#bf8d5e','#7a5230'],50,3); for(let i=0;i<4;i++) ell(g,'#8f6238',r()*44+2,r()*44+2,3,2); });
GR('Sand','#e3cf8f',(g,r)=>{ speckle(g,r,['#d1bb78','#f0e0a8','#c9b36e'],55,2); });
GR('Snow','#eef3fa',(g,r)=>{ speckle(g,r,['#d8e3f0','#ffffff','#cfdcec'],45,3); });
GR('Water','#3b7fd1',(g,r,f)=>{ for(let row=0;row<4;row++){ const y=6+row*12; g.strokeStyle=row%2?'#6fb0f0':'#5a9be3'; g.lineWidth=2; g.beginPath(); for(let x=0;x<=48;x+=4){ const yy=y+Math.sin((x+f*16)/48*6.2832+row)*2.2; if(x) g.lineTo(x,yy); else g.moveTo(x,yy);} g.stroke(); } },{pass:false,anim:true,edge:'rgba(255,255,255,.7)'});
GR('Deep Water','#244f9c',(g,r,f)=>{ for(let row=0;row<4;row++){ const y=6+row*12; g.strokeStyle=row%2?'#3b6fc0':'#2f62b3'; g.lineWidth=2; g.beginPath(); for(let x=0;x<=48;x+=4){ const yy=y+Math.sin((x+f*16)/48*6.2832+row*2)*2.2; if(x) g.lineTo(x,yy); else g.moveTo(x,yy);} g.stroke(); } },{pass:false,anim:true,edge:'rgba(160,200,255,.6)'});
GR('Lava','#d8480f',(g,r,f)=>{ for(let i=0;i<5;i++){ const x=(i*11+f*5)%48,y=(i*17+9)%44; circ(g,'#ffb23a',x,y,5+((i+f)%3)); circ(g,'#ffe27a',x,y,2); } speckle(g,r,['#a8300a','#f06a1a'],20,3); },{pass:false,anim:true,edge:'#ffcc55',damage:true});
GR('Swamp','#4a5a2a',(g,r,f)=>{ speckle(g,r,['#38461f','#5d7034','#2f3a18'],50,3); for(let i=0;i<3;i++) circ(g,'#7a9444',(i*17+f*6)%44+4,(i*13+8)%40+4,2+(i+f)%2); },{anim:true,damage:true});
GR('Cobblestone','#8f8f94',(g,r)=>{ for(let y=0;y<3;y++) for(let x=0;x<3;x++){ rr(g,y%2?'#9c9ca2':'#a5a5ab',x*16+(y%2?-6:0)+1,y*16+1,14,14,4);} g.fillStyle='rgba(0,0,0,.15)'; for(let i=0;i<8;i++) g.fillRect(r()*44,r()*44,3,2); });
GR('Stone Floor','#a9a9b3',(g,r)=>{ for(let i=0;i<2;i++) for(let j=0;j<2;j++){ rect(g,(i+j)%2?'#b4b4be':'#a2a2ad',i*24,j*24,24,24); } g.strokeStyle='#8a8a95'; g.lineWidth=1.5; g.strokeRect(.75,.75,46.5,46.5); line(g,'#8a8a95',24,0,24,48,1.5); line(g,'#8a8a95',0,24,48,24,1.5); });
GR('Wood Floor','#b5824f',(g,r)=>{ for(let i=0;i<4;i++){ rect(g,i%2?'#a3733f':'#b5824f',0,i*12,48,12); line(g,'#7d5530',0,i*12,48,i*12,1.5); line(g,'#8e6234',r()*40,i*12+5,r()*40+8,i*12+6,1); circ(g,'#5e3f20',(i*19+5)%44+2,i*12+6,1); } });
GR('Dark Floor','#3a3a48',(g,r)=>{ rect(g,'#42424f',0,0,24,24); rect(g,'#42424f',24,24,24,24); g.strokeStyle='#2a2a35'; g.lineWidth=1.5; g.strokeRect(.75,.75,46.5,46.5); line(g,'#2a2a35',24,0,24,48,1.5); line(g,'#2a2a35',0,24,48,24,1.5); line(g,'#2a2a35',30,4,36,16,1); });
GR('Red Carpet','#a82a35',(g,r)=>{ rect(g,'#c4414c',4,0,40,48); rect(g,'#a82a35',8,0,32,48); rect(g,'#e8c25a',4,0,2,48); rect(g,'#e8c25a',42,0,2,48); for(let y=4;y<48;y+=16){ poly(g,'#e8c25a',24,y,28,y+4,24,y+8,20,y+4);} });
GR('Checker Floor','#f2f2f2',(g,r)=>{ for(let i=0;i<2;i++) for(let j=0;j<2;j++) rect(g,(i+j)%2?'#c9c9d3':'#f2f2f2',i*24,j*24,24,24); });
GR('Brick Path','#b8643c',(g,r)=>{ for(let y=0;y<4;y++) for(let x=-1;x<3;x++){ rr(g,(x+y)%2?'#c8744a':'#b45c34',x*24+(y%2?12:0)+1,y*12+1,22,10,2);} });
GR('Ice','#b9e2f5',(g,r)=>{ line(g,'rgba(255,255,255,.8)',6,40,22,10,3); line(g,'rgba(255,255,255,.6)',26,44,42,18,2); speckle(g,r,['#a3d4ec','#d6f1fb'],30,3); },{});
GR('Cave Floor','#59473a',(g,r)=>{ speckle(g,r,['#4a3a2f','#6a5646','#3d2f26'],55,3); for(let i=0;i<3;i++) ell(g,'#6f5c4b',r()*40+4,r()*40+4,4,3); });
GR('Rocky Ground','#7d7569',(g,r)=>{ speckle(g,r,['#6a6258','#8f877b'],40,3); for(let i=0;i<5;i++){ const x=r()*40+4,y=r()*40+4; ell(g,'#6a6258',x,y,5,3.5); ell(g,'#948c80',x-1,y-1,3,2);} });
GR('Cliff','#6b5a4a',(g,r)=>{ for(let i=0;i<6;i++) rect(g,i%2?'#7a6755':'#5f4f40',i*8,0,8,48); rect(g,'#4a3c30',0,40,48,8); rect(g,'#85715d',0,0,48,4); },{pass:false});
GR('Black Void','#000000',(g)=>{},{pass:false,auto:false});

// ----- NATURE (B)
const N = (name,o,fn)=>D(name,'B',Object.assign({layer:2},o||{}),fn);
N('Tree',{pass:false},(g)=>{ shadow(g,24,43,15,5); rect(g,'#6b4423',20,26,8,17); rect(g,'#553419',20,26,3,17); circ(g,'#2c7a33',24,19,17); circ(g,'#379a40',18,15,10); circ(g,'#4bb44f',15,11,5); circ(g,'#2c7a33',31,23,8); });
N('Pine Tree',{pass:false},(g)=>{ shadow(g,24,43,12,4); rect(g,'#5a3a1c',21,34,6,9); poly(g,'#1f6b3a',24,3,38,22,10,22); poly(g,'#287a45',24,12,41,33,7,33); poly(g,'#2f8a50',24,20,44,40,4,40); });
N('Tree Top',{layer:3,star:true,pass:true},(g)=>{ ell(g,'#2c7a33',24,40,23,22); ell(g,'#379a40',17,32,12,10); ell(g,'#4bb44f',14,26,6,5); });
N('Tree Trunk',{pass:false},(g)=>{ shadow(g,24,44,14,4); rect(g,'#6b4423',19,6,10,38); rect(g,'#553419',19,6,3,38); ell(g,'#2c7a33',24,0,23,16); ell(g,'#379a40',17,2,10,8); });
N('Bush',{pass:false},(g)=>{ shadow(g,24,42,16,5); circ(g,'#2f7d35',16,30,11); circ(g,'#2f7d35',32,30,11); circ(g,'#3a9441',24,24,13); circ(g,'#52b058',20,20,5); });
N('Small Bush',{layer:1},(g)=>{ shadow(g,24,40,10,3); circ(g,'#3a9441',19,34,8); circ(g,'#4aa851',29,34,7); circ(g,'#5fbd64',22,31,3); });
N('Tall Grass',{layer:1,bush:true},(g,r)=>{ for(let i=0;i<14;i++){ const x=i*3.4+1,h=18+r()*14; line(g,i%2?'#3f8f3a':'#56a84c',x,48,x+(r()-.5)*6,48-h,2); } });
const flower=(c)=>(g,r)=>{ for(let i=0;i<5;i++){ const x=8+r()*32,y=14+r()*26; line(g,'#3f8f3a',x,y,x,y+8,1.5); circ(g,c,x,y,3.5); circ(g,'#ffe066',x,y,1.5);} };
N('Flowers Red',{layer:1},flower('#e8433f')); N('Flowers Blue',{layer:1},flower('#4a7fe8')); N('Flowers Yellow',{layer:1},flower('#f5d23a')); N('Flowers White',{layer:1},flower('#f4f4f4'));
N('Mushroom',{layer:1},(g)=>{ shadow(g,24,38,9,3); rect(g,'#f0e6d0',21,28,6,10); ell(g,'#d9433a',24,28,12,8); circ(g,'#fff',19,26,2); circ(g,'#fff',27,25,2); circ(g,'#fff',24,30,1.5); });
N('Rock',{pass:false},(g)=>{ shadow(g,24,41,15,5); ell(g,'#7a7a80',24,31,14,10); ell(g,'#9a9aa2',21,28,9,6); ell(g,'#b4b4bc',18,25,4,2.5); });
N('Boulder',{pass:false},(g)=>{ shadow(g,24,43,20,5); ell(g,'#6d6d75',24,28,20,16); ell(g,'#8d8d96',20,24,14,10); ell(g,'#aaaab4',15,19,6,4); line(g,'#55555c',30,26,36,36,1.5); });
N('Stump',{pass:false},(g)=>{ shadow(g,24,41,13,4); rect(g,'#6b4423',13,24,22,16); ell(g,'#c49a60',24,24,11,6); ell(g,'#a67c45',24,24,7,3.5); ell(g,'#c49a60',24,24,3,1.5); });
N('Log',{pass:false},(g)=>{ shadow(g,24,40,19,4); rr(g,'#7a4f26',4,22,40,16,7); ell(g,'#c49a60',9,30,5,7); ell(g,'#a67c45',9,30,2.5,4); line(g,'#5c3a1a',16,26,40,26,1.5); line(g,'#5c3a1a',16,32,40,32,1.5); });
N('Fallen Leaves',{layer:1},(g,r)=>{ const cs=['#d98b2b','#c0562a','#e8b83a','#a8431f']; for(let i=0;i<14;i++){ ell(g,cs[i%4],r()*40+4,r()*40+4,3,1.8);} });
N('Fence Horizontal',{pass:false},(g)=>{ rect(g,'#9c6b38',0,18,48,5); rect(g,'#9c6b38',0,30,48,5); for(const x of [4,38]){ rect(g,'#7d5226',x,12,6,28); rect(g,'#b88348',x,12,6,3);} });
N('Fence Vertical',{pass:false},(g)=>{ rect(g,'#7d5226',20,0,8,48); rect(g,'#9c6b38',14,6,20,5); rect(g,'#9c6b38',14,28,20,5); rect(g,'#b88348',20,0,3,48); });
N('Signpost',{pass:false},(g)=>{ shadow(g,24,43,10,3); rect(g,'#6b4423',22,20,5,23); rr(g,'#b88348',8,8,32,16,2); rect(g,'#7d5226',8,20,32,2); line(g,'#5c3a1a',13,14,35,14,1.5); line(g,'#5c3a1a',13,18,28,18,1.5); });
N('Gravestone',{pass:false},(g)=>{ shadow(g,24,43,12,3); rr(g,'#8d8d96',14,10,20,32,8); rect(g,'#8d8d96',14,24,20,18); line(g,'#5e5e66',24,16,24,28,2.5); line(g,'#5e5e66',19,21,29,21,2.5); });
N('Campfire',{pass:false,anim:true},(g,r,f)=>{ shadow(g,24,42,14,4); line(g,'#6b4423',10,38,38,32,5); line(g,'#7d5226',10,32,38,38,5); const h=[16,20,14][f]; poly(g,'#e8601a',24,38-h-10,34,34,14,34); poly(g,'#ffa63a',24,38-h-3,30,34,18,34); poly(g,'#ffe27a',24,38-h+5,27,34,21,34); });
N('Well',{pass:false},(g)=>{ shadow(g,24,43,17,5); circ(g,'#8d8d96',24,30,15); circ(g,'#3b6fc0',24,29,10); circ(g,'#5a95e0',22,27,4); rect(g,'#7d5226',8,6,4,26); rect(g,'#7d5226',36,6,4,26); poly(g,'#b0432f',4,10,24,0,44,10); });
N('Hay Bale',{pass:false},(g)=>{ shadow(g,24,43,16,4); rr(g,'#d9b440',6,16,36,26,6); for(let i=0;i<5;i++) line(g,'#b8922a',10+i*7,18,12+i*7,40,1.5); line(g,'#8a6a1c',6,29,42,29,2); });
N('Crops',{layer:1},(g,r)=>{ for(let x=6;x<48;x+=14) for(let y=14;y<48;y+=16){ line(g,'#7a9a2a',x,y,x-3,y-9,2); line(g,'#8fb034',x,y,x+3,y-9,2); line(g,'#6a8a22',x,y,x,y-11,2); circ(g,'#e8c840',x,y-11,2);} });
N('Lily Pad',{layer:1},(g)=>{ ell(g,'#3f9a3a',24,26,14,9); poly(g,'#3b7fd1',24,26,40,18,40,26); circ(g,'#f4a8c8',30,24,3.5); circ(g,'#fff',30,24,1.5); });
N('Reeds',{pass:false},(g)=>{ for(const x of [14,20,26,32,38]){ line(g,'#6a8a3a',x,44,x+(x%3-1)*2,8+x%7,2.5); rr(g,'#7a4f26',x-1.5+(x%3-1)*2,4+x%7,4,9,2);} });

})();
