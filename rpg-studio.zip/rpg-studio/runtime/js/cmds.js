/* Katalog perintah event (dipakai editor & interpreter). Perintah disimpan datar: {c, i(indent), ...field} */
(function(){
'use strict';
const R = window.RPG;
const DIRS = {2:'Down',4:'Left',6:'Right',8:'Up',0:'Retain'};
const ON = v => v==='on'?'ON':v==='off'?'OFF':'Toggle';
const nm = (list,id)=>{ const o=list&&list[id-1]; return String(id).padStart(3,'0')+':'+(o&&o.name||'?'); };
const cmdS = {}; // summary
const CAT = R.CMD_CATEGORIES = ['Message','Flow','Game Progress','Party','Actor','Movement','Screen','Audio','Scene','Advanced'];
const CMDS = R.CMDS = {}; // code -> {label,cat,fields,block?,def,sum(cmd,db)}
function C(code,label,cat,fields,def,sum,extra){ CMDS[code]=Object.assign({code:code,label:label,cat:cat,fields:fields,def:def||{},sum:sum||(()=>'')},extra||{}); }
const F = (k,t,l,o)=>Object.assign({k:k,t:t,l:l},o||{});
const OPS = ['==','>=','<=','>','<','!='];
const PRESETS = ()=>R.CHAR_PRESETS.map(p=>p.name);

C('text','Show Text','Message',[F('face','face','Face'),F('pos','select','Position',{opts:['bottom','middle','top']}),F('bg','select','Background',{opts:['window','dim','none']}),F('text','multiline','Text (4 lines; \\V[n] \\N[n] \\C[n] \\G \\I[n] \\. \\!)')],{face:'',pos:'bottom',bg:'window',text:''},c=>'Text: '+(c.text||'').split('\n')[0]);
C('choices','Show Choices','Message',[F('opts','list','Choices'),F('cancel','select','When Cancel',{opts:['Disallow','Branch','Choice 1','Choice 2','Choice 3','Choice 4','Choice 5','Choice 6']}),F('pos','select','Window',{opts:['right','middle','left']})],{opts:['Yes','No'],cancel:0,pos:'right'},c=>'Choices: '+(c.opts||[]).join(' | '),{block:'choices'});
C('when','When','Message',[],{idx:0},c=>'When ['+((c._label)||c.idx+1)+']',{hidden:true});
C('endchoices','End Choices','Message',[],{},()=>'End',{hidden:true});
C('numinput','Input Number','Message',[F('v','variable','Variable'),F('digits','number','Digits',{min:1,max:8})],{v:1,digits:3},(c,db)=>'Input Number: variable '+c.v+', '+c.digits+' digits');
C('selitem','Select Key Item','Message',[F('v','variable','Variable')],{v:1},c=>'Select Key Item: variable '+c.v);
C('scrolltext','Show Scrolling Text','Message',[F('speed','number','Speed',{min:1,max:8}),F('text','multiline','Text')],{speed:2,text:''},c=>'Scrolling: '+(c.text||'').split('\n')[0]);

C('if','Conditional Branch','Flow',[F('kind','select','Condition',{opts:['switch','variable','selfswitch','gold','item','weapon','armor','actor','direction','button','script']}),F('a','any','Target'),F('op','select','Operator',{opts:OPS}),F('b','any','Value'),F('cmp','select','Compare with',{opts:['constant','variable']}),F('else','bool','Create Else branch')],{kind:'switch',a:1,b:'on',op:'==',cmp:'constant',else:true},(c)=>{
  switch(c.kind){ case 'switch': return 'If: Switch '+c.a+' is '+ON(c.b);
   case 'variable': return 'If: Variable '+c.a+' '+c.op+' '+(c.cmp==='variable'?'Var '+c.b:c.b);
   case 'selfswitch': return 'If: Self Switch '+c.a+' is '+ON(c.b);
   case 'gold': return 'If: Gold '+c.op+' '+c.b;
   case 'item': case 'weapon': case 'armor': return 'If: Party has '+c.kind+' #'+c.a;
   case 'actor': return 'If: Actor #'+c.a+' is in party';
   case 'direction': return 'If: Player is facing '+DIRS[c.a];
   case 'button': return 'If: Button '+c.a+' is pressed';
   default: return 'If: Script: '+c.a; } },{block:'if'});
C('else','Else','Flow',[],{},()=>'Else',{hidden:true});
C('endif','End If','Flow',[],{},()=>'End',{hidden:true});
C('loop','Loop','Flow',[],{},()=>'Loop',{block:'loop'});
C('endloop','Repeat Above','Flow',[],{},()=>'Repeat Above',{hidden:true});
C('break','Break Loop','Flow',[],{},()=>'Break Loop');
C('exit','Exit Event Processing','Flow',[],{},()=>'Exit Event Processing');
C('label','Label','Flow',[F('name','text','Label name')],{name:'A'},c=>'Label: '+c.name);
C('goto','Jump to Label','Flow',[F('name','text','Label name')],{name:'A'},c=>'Jump to Label: '+c.name);
C('playscene','Play Scene','Flow',[F('scene','scene','Scene')],{scene:1},(c,db)=>'Play Scene: '+nm(db&&db.scenes,c.scene));
C('common','Common Event','Flow',[F('id','commonevent','Common Event')],{id:1},(c,db)=>'Common Event: '+nm(db&&db.commonEvents,c.id));
C('comment','Comment','Flow',[F('text','multiline','Comment')],{text:''},c=>'Comment: '+(c.text||'').split('\n')[0]);
C('wait','Wait','Flow',[F('frames','number','Frames (60 = 1 s)',{min:1,max:999})],{frames:60},c=>'Wait: '+c.frames+' frames');

C('setswitch','Control Switches','Game Progress',[F('a','switch','Switch (from)'),F('a2','switch','Switch (to)'),F('val','select','Set',{opts:['on','off','toggle']})],{a:1,a2:1,val:'on'},c=>'Switches: #'+c.a+(c.a2>c.a?'..#'+c.a2:'')+' = '+ON(c.val));
C('setvar','Control Variables','Game Progress',[F('a','variable','Variable (from)'),F('a2','variable','Variable (to)'),F('op','select','Operation',{opts:['=','+=','-=','*=','/=','%=']}),F('src','select','Operand',{opts:['constant','variable','random','item count','gold','steps','playtime','map id','party size','player x','player y','script']}),F('v','any','Value / Script'),F('v2','number','Random max')],{a:1,a2:1,op:'=',src:'constant',v:0,v2:10},c=>'Variable: #'+c.a+(c.a2>c.a?'..#'+c.a2:'')+' '+c.op+' '+c.src+(c.src==='constant'||c.src==='script'||c.src==='variable'?' '+c.v:c.src==='random'?' '+c.v+'..'+c.v2:c.src==='item count'?' item#'+c.v:''));
C('setself','Control Self Switch','Game Progress',[F('key','select','Self Switch',{opts:['A','B','C','D']}),F('val','select','Set',{opts:['on','off','toggle']})],{key:'A',val:'on'},c=>'Self Switch '+c.key+' = '+ON(c.val));
C('gold','Change Gold','Party',[F('op','select','Operation',{opts:['+','-']}),F('v','number','Amount',{min:0,max:99999999})],{op:'+',v:100},c=>'Change Gold: '+c.op+' '+c.v);
C('item','Change Items','Party',[F('kind','select','Type',{opts:['item','weapon','armor']}),F('id','itemref','Item'),F('op','select','Operation',{opts:['+','-']}),F('n','number','Quantity',{min:1,max:99})],{kind:'item',id:1,op:'+',n:1},(c,db)=>'Change '+c.kind+': '+nm(db&&db[c.kind==='item'?'items':c.kind==='weapon'?'weapons':'armors'],c.id)+' '+c.op+' '+c.n);
C('partymember','Change Party Member','Party',[F('actor','actor','Actor'),F('op','select','Operation',{opts:['add','remove']}),F('init','bool','Initialize on add')],{actor:1,op:'add',init:true},(c,db)=>'Party Member: '+c.op+' '+nm(db&&db.actors,c.actor));
C('hp','Change HP','Actor',[F('target','actortarget','Actor'),F('op','select','Operation',{opts:['+','-']}),F('v','number','Amount',{min:0,max:99999}),F('death','bool','Allow Knockout')],{target:0,op:'+',v:50,death:false},c=>'Change HP: '+(c.target?'#'+c.target:'Entire party')+' '+c.op+' '+c.v);
C('mp','Change MP','Actor',[F('target','actortarget','Actor'),F('op','select','Operation',{opts:['+','-']}),F('v','number','Amount',{min:0,max:99999})],{target:0,op:'+',v:20},c=>'Change MP: '+(c.target?'#'+c.target:'Entire party')+' '+c.op+' '+c.v);
C('state','Change State','Actor',[F('target','actortarget','Actor'),F('op','select','Operation',{opts:['add','remove']}),F('state','state','State')],{target:0,op:'add',state:3},(c,db)=>'Change State: '+(c.target?'#'+c.target:'Entire party')+' '+c.op+' '+nm(db&&db.states,c.state));
C('recover','Recover All','Actor',[F('target','actortarget','Actor')],{target:0},c=>'Recover All: '+(c.target?'#'+c.target:'Entire party'));
C('exp','Change EXP','Actor',[F('target','actortarget','Actor'),F('op','select','Operation',{opts:['+','-']}),F('v','number','Amount',{min:0,max:9999999}),F('show','bool','Show level up')],{target:0,op:'+',v:100,show:true},c=>'Change EXP: '+(c.target?'#'+c.target:'Entire party')+' '+c.op+' '+c.v);
C('level','Change Level','Actor',[F('target','actortarget','Actor'),F('op','select','Operation',{opts:['+','-']}),F('v','number','Levels',{min:1,max:99})],{target:0,op:'+',v:1},c=>'Change Level: '+(c.target?'#'+c.target:'Entire party')+' '+c.op+' '+c.v);
C('skill','Change Skill','Actor',[F('target','actor','Actor'),F('op','select','Operation',{opts:['learn','forget']}),F('skill','skill','Skill')],{target:1,op:'learn',skill:1},(c,db)=>'Change Skill: actor#'+c.target+' '+c.op+' '+nm(db&&db.skills,c.skill));
C('name','Change Name','Actor',[F('actor','actor','Actor'),F('name','text','Name')],{actor:1,name:''},c=>'Change Name: actor#'+c.actor+' -> '+c.name);
C('class','Change Class','Actor',[F('actor','actor','Actor'),F('cls','class','Class')],{actor:1,cls:1},c=>'Change Class: actor#'+c.actor+' -> class#'+c.cls);
C('actorimage','Change Actor Graphic','Actor',[F('actor','actor','Actor'),F('img','charimg','Character')],{actor:1,img:{kind:'preset',name:'Hero'}},c=>'Change Actor Graphic: actor#'+c.actor);
C('nameinput','Name Input Processing','Actor',[F('actor','actor','Actor'),F('max','number','Max chars',{min:1,max:16})],{actor:1,max:8},c=>'Name Input: actor#'+c.actor);

C('transfer','Transfer Player','Movement',[F('mode','select','Designation',{opts:['direct','variables']}),F('map','map','Map'),F('x','number','X',{min:0,max:999}),F('y','number','Y',{min:0,max:999}),F('dir','select','Direction',{opts:['0','2','4','6','8'],labels:['Retain','Down','Left','Right','Up']}),F('fade','select','Fade',{opts:['black','white','none']})],{mode:'direct',map:1,x:0,y:0,dir:0,fade:'black'},(c,db)=>'Transfer Player: '+(c.mode==='direct'?'Map '+c.map+' ('+c.x+','+c.y+')':'variables')+' '+DIRS[c.dir]);
C('setevtloc','Set Event Location','Movement',[F('event','event','Event'),F('mode','select','Designation',{opts:['direct','variables','exchange']}),F('x','number','X',{min:0,max:999}),F('y','number','Y',{min:0,max:999}),F('dir','select','Direction',{opts:['0','2','4','6','8'],labels:['Retain','Down','Left','Right','Up']})],{event:0,mode:'direct',x:0,y:0,dir:0},c=>'Set Event Location: '+(c.event===0?'This':c.event===-1?'Player':'#'+c.event)+' ('+c.x+','+c.y+')');
C('moveroute','Set Move Route','Movement',[F('target','event','Target'),F('route','route','Route'),F('wait','bool','Wait for completion'),F('repeat','bool','Repeat')],{target:-1,route:[],wait:true,repeat:false},c=>'Move Route: '+(c.target===-1?'Player':c.target===0?'This Event':'#'+c.target)+' ('+(c.route||[]).length+' steps)');
C('transparent','Change Transparency','Movement',[F('val','select','Player',{opts:['on','off']})],{val:'on'},c=>'Transparency: '+c.val);
C('followers','Change Followers','Movement',[F('val','select','Followers',{opts:['on','off']})],{val:'on'},c=>'Followers: '+c.val);
C('erase','Erase Event','Movement',[],{},()=>'Erase Event');

C('fadeout','Fadeout Screen','Screen',[],{},()=>'Fadeout Screen');
C('fadein','Fadein Screen','Screen',[],{},()=>'Fadein Screen');
C('tint','Tint Screen','Screen',[F('r','number','Red',{min:-255,max:255}),F('g','number','Green',{min:-255,max:255}),F('b','number','Blue',{min:-255,max:255}),F('gray','number','Gray',{min:0,max:255}),F('frames','number','Frames',{min:1,max:600}),F('wait','bool','Wait')],{r:0,g:0,b:0,gray:0,frames:60,wait:true},c=>'Tint Screen ('+c.r+','+c.g+','+c.b+','+c.gray+')');
C('flash','Flash Screen','Screen',[F('color','color','Color'),F('frames','number','Frames',{min:1,max:600}),F('wait','bool','Wait')],{color:'#ffffff',frames:30,wait:true},c=>'Flash Screen '+c.color);
C('shake','Shake Screen','Screen',[F('power','number','Power',{min:1,max:9}),F('speed','number','Speed',{min:1,max:9}),F('frames','number','Frames',{min:1,max:600}),F('wait','bool','Wait')],{power:5,speed:5,frames:60,wait:true},c=>'Shake Screen: power '+c.power);
C('weather','Set Weather Effect','Screen',[F('type','select','Type',{opts:['none','rain','storm','snow']}),F('power','number','Power',{min:1,max:9}),F('frames','number','Frames',{min:1,max:600})],{type:'rain',power:5,frames:60},c=>'Weather: '+c.type);
C('showpic','Show Picture','Screen',[F('id','number','Picture #',{min:1,max:20}),F('name','picture','Image'),F('x','number','X',{min:-9999,max:9999}),F('y','number','Y',{min:-9999,max:9999}),F('scale','number','Scale %',{min:1,max:500}),F('opacity','number','Opacity',{min:0,max:255})],{id:1,name:'',x:0,y:0,scale:100,opacity:255},c=>'Show Picture #'+c.id+' '+c.name);
C('movepic','Move Picture','Screen',[F('id','number','Picture #',{min:1,max:20}),F('x','number','X',{min:-9999,max:9999}),F('y','number','Y',{min:-9999,max:9999}),F('scale','number','Scale %',{min:1,max:500}),F('opacity','number','Opacity',{min:0,max:255}),F('frames','number','Frames',{min:1,max:600}),F('wait','bool','Wait')],{id:1,x:0,y:0,scale:100,opacity:255,frames:60,wait:true},c=>'Move Picture #'+c.id);
C('erasepic','Erase Picture','Screen',[F('id','number','Picture #',{min:1,max:20})],{id:1},c=>'Erase Picture #'+c.id);
C('animation','Show Animation','Screen',[F('target','event','Target'),F('anim','anim','Animation'),F('wait','bool','Wait')],{target:-1,anim:'Slash',wait:true},c=>'Animation: '+c.anim+' on '+(c.target===-1?'Player':c.target===0?'This Event':'#'+c.target));
C('balloon','Show Balloon Icon','Screen',[F('target','event','Target'),F('icon','select','Icon',{opts:['Exclamation','Question','Music','Heart','Anger','Sweat','Frustration','Silence','Light bulb','Zzz']}),F('wait','bool','Wait')],{target:0,icon:'Exclamation',wait:true},c=>'Balloon: '+c.icon);

C('playbgm','Play BGM','Audio',[F('name','bgm','BGM'),F('vol','number','Volume %',{min:0,max:100})],{name:'Peaceful Village',vol:100},c=>'Play BGM: '+c.name);
C('fadebgm','Fadeout BGM','Audio',[F('sec','number','Seconds',{min:1,max:60})],{sec:3},c=>'Fadeout BGM: '+c.sec+'s');
C('stopbgm','Stop BGM','Audio',[],{},()=>'Stop BGM');
C('playse','Play SE','Audio',[F('name','se','SE'),F('vol','number','Volume %',{min:0,max:100})],{name:'OK',vol:100},c=>'Play SE: '+c.name);

C('battle','Battle Processing','Scene',[F('kind','select','Troop',{opts:['direct','variable','random']}),F('id','troop','Troop'),F('escape','bool','Can Escape'),F('lose','bool','Continue Even When Loser')],{kind:'direct',id:1,escape:true,lose:false},(c,db)=>'Battle: '+nm(db&&db.troops,c.id),{block:'battle'});
C('ifwin','If Win','Scene',[],{},()=>'If Win',{hidden:true});
C('ifescape','If Escape','Scene',[],{},()=>'If Escape',{hidden:true});
C('iflose','If Lose','Scene',[],{},()=>'If Lose',{hidden:true});
C('endbattle','End Battle','Scene',[],{},()=>'End',{hidden:true});
C('shop','Shop Processing','Scene',[F('goods','goods','Goods'),F('buyOnly','bool','Purchase Only')],{goods:[],buyOnly:false},c=>'Shop: '+(c.goods||[]).length+' goods');
C('menu','Open Menu Screen','Scene',[],{},()=>'Open Menu Screen');
C('save','Open Save Screen','Scene',[],{},()=>'Open Save Screen');
C('gameover','Game Over','Scene',[],{},()=>'Game Over');
C('title','Return to Title Screen','Scene',[],{},()=>'Return to Title Screen');
C('sysopt','Change System Access','Scene',[F('key','select','Setting',{opts:['save','menu','encounter']}),F('val','select','Value',{opts:['on','off']})],{key:'save',val:'off'},c=>'Access: '+c.key+' '+c.val);
C('script','Script','Advanced',[F('s','multiline','JavaScript ($game, $v(n), $s(n), $map, $player, R)')],{s:''},c=>'Script: '+(c.s||'').split('\n')[0]);
R.CMD_DIRS = DIRS;
R.cmdSummary = function(c,db){ const d=CMDS[c.c]; return d? d.sum(c,db): '??? '+c.c; };
R.newCmd = function(code,indent){ const d=CMDS[code]; const o=Object.assign({c:code,i:indent||0},JSON.parse(JSON.stringify(d.def||{}))); return o; };
/* Bangun daftar perintah lengkap (dengan blok pembuka/penutup) untuk satu perintah yang baru */
R.buildCmdBlock = function(code,indent,fields){
  const base = Object.assign(R.newCmd(code,indent),fields||{}); const out=[base]; const i=indent;
  if(code==='choices'){ (base.opts||[]).forEach((o,k)=>{ out.push({c:'when',i:i,idx:k}); out.push({c:'empty',i:i+1}); }); if(base.cancel===1){ out.push({c:'when',i:i,idx:-2}); out.push({c:'empty',i:i+1}); } out.push({c:'endchoices',i:i}); }
  else if(code==='if'){ out.push({c:'empty',i:i+1}); if(base.else){ out.push({c:'else',i:i}); out.push({c:'empty',i:i+1}); } out.push({c:'endif',i:i}); }
  else if(code==='loop'){ out.push({c:'empty',i:i+1}); out.push({c:'endloop',i:i}); }
  else if(code==='battle'){ out.push({c:'ifwin',i:i}); out.push({c:'empty',i:i+1}); if(base.escape){ out.push({c:'ifescape',i:i}); out.push({c:'empty',i:i+1}); } if(base.lose){ out.push({c:'iflose',i:i}); out.push({c:'empty',i:i+1}); } out.push({c:'endbattle',i:i}); }
  return out;
};
})();
