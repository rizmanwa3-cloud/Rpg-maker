/* Katalog perintah event (dipakai editor & interpreter). Perintah disimpan datar: {c, i(indent), ...field} */
(function(){
'use strict';
const R = window.RPG;
const DIRS = {2:'Down',4:'Left',6:'Right',8:'Up',0:'Retain'};
const ON = v => v==='on'?'ON':v==='off'?'OFF':'Toggle';
const nm = (list,id)=>{ const o=list&&list[id-1]; return String(id).padStart(3,'0')+':'+(o&&o.name||'?'); };
const cmdS = {}; // summary
const CAT = R.CMD_CATEGORIES = ['Message','Flow','Game Progress','Party','Actor','Movement','Screen','Audio','Scene','Advanced'];
const CMDS = R.CMDS = {}; // code -> {label,cat,fields,block?,def,sum(cmd,db)}
function C(code,label,cat,fields,def,sum,extra){ CMDS[code]=Object.assign({code:code,label:label,cat:cat,fields:fields,def:def||{},sum:sum||(()=>'')},extra||{}); }
const F = (k,t,l,o)=>Object.assign({k:k,t:t,l:l},o||{});
R.FX_TYPES = ['fog','mist','blur','blurEdge','vignette','darkness','particles','scanlines','grayscale','sepia','pixelate','overlay','colorWash'];
const OPS = ['==','>=','<=','>','<','!='];
const PRESETS = ()=>R.CHAR_PRESETS.map(p=>p.name);

C('text','Show Text','Message',[F('face','face','Face / Portrait'),F('speaker','text','Speaker name'),F('pstyle','select','Portrait style',{opts:['box','big'],labels:['In window','Big (side)']}),F('pside','select','Big portrait side',{opts:['left','right']}),F('pos','select','Position',{opts:['bottom','middle','top']}),F('bg','select','Background',{opts:['window','dim','none']}),F('text','multiline','Text (4 lines; \\V[n] \\N[n] \\C[n] \\G \\I[n] \\. \\!)')],{face:'',speaker:'',pstyle:'box',pside:'left',pos:'bottom',bg:'window',text:''},c=>(c.speaker?'['+c.speaker+'] ':'')+'Text: '+(c.text||'').split('\n')[0]);
C('choices','Show Choices','Message',[F('opts','list','Choices'),F('cancel','select','When Cancel',{opts:['Disallow','Branch','Choice 1','Choice 2','Choice 3','Choice 4','Choice 5','Choice 6']}),F('pos','select','Window',{opts:['right','middle','left']})],{opts:['Yes','No'],cancel:0,pos:'right'},c=>'Choices: '+(c.opts||[]).join(' | '),{block:'choices'});
C('when','When','Message',[],{idx:0},c=>'When ['+((c._label)||c.idx+1)+']',{hidden:true});
C('endchoices','End Choices','Message',[],{},()=>'End',{hidden:true});
C('numinput','Input Number','Message',[F('v','variable','Variable'),F('digits','number','Digits',{min:1,max:8})],{v:1,digits:3},(c,db)=>'Input Number: variable '+c.v+', '+c.digits+' digits');
C('selitem','Select Key Item','Message',[F('v','variable','Variable')],{v:1},c=>'Select Key Item: variable '+c.v);
C('scrolltext','Show Scrolling Text','Message',[F('speed','number','Speed',{min:1,max:8}),F('text','multiline','Text')],{speed:2,text:''},c=>'Scrolling: '+(c.text||'').split('\n')[0]);

C('if','Conditional Branch','Flow',[F('kind','select','Condition',{opts:['switch','variable','selfswitch','gold','item','weapon','armor','actor','direction','button','script']}),F('a','any','Target'),F('op','select','Operator',{opts:OPS}),F('b','any','Value'),F('cmp','select','Compare with',{opts:['constant','variable']}),F('else','bool','Create Else branch')],{kind:'switch',a:1,b:'on',op:'==',cmp:'constant',else:true},(c)=>{
  switch(c.kind){ case 'switch': return 'If: Switch '+c.a+' is '+ON(c.b);
   case 'variable': return 'If: Variable '+c.a+' '+c.op+' '+(c.cmp==='variable'?'Var '+c.b:c.b);
   case 'selfswitch': return 'If: Self Switch '+c.a+' is '+ON(c.b);
   case 'gold': return 'If: Gold '+c.op+' '+c.b;
   case 'item': case 'weapon': case 'armor': return 'If: Party has '+c.kind+' #'+c.a;
   case 'actor': return 'If: Actor #'+c.a+' is in party';
   case 'direction': return 'If: Player is facing '+DIRS[c.a];
   case 'button': return 'If: Button '+c.a+' is pressed';
   default: return 'If: Script: '+c.a; } },{block:'if'});
C('else','Else','Flow',[],{},()=>'Else',{hidden:true});
C('endif','End If','Flow',[],{},()=>'End',{hidden:true});
C('loop','Loop','Flow',[],{},()=>'Loop',{block:'loop'});
C('endloop','Repeat Above','Flow',[],{},()=>'Repeat Above',{hidden:true});
C('break','Break Loop','Flow',[],{},()=>'Break Loop');
C('exit','Exit Event Processing','Flow',[],{},()=>'Exit Event Processing');
C('label','Label','Flow',[F('name','text','Label name')],{name:'A'},c=>'Label: '+c.name);
C('goto','Jump to Label','Flow',[F('name','text','Label name')],{name:'A'},c=>'Jump to Label: '+c.name);
C('playscene','Play Scene','Flow',[F('scene','scene','Scene')],{scene:1},(c,db)=>'Play Scene: '+nm(db&&db.scenes,c.scene));
C('common','Common Event','Flow',[F('id','commonevent','Common Event')],{id:1},(c,db)=>'Common Event: '+nm(db&&db.commonEvents,c.id));
C('comment','Comment','Flow',[F('text','multiline','Comment')],{text:''},c=>'Comment: '+(c.text||'').split('\n')[0]);
C('wait','Wait','Flow',[F('frames','number','Frames (60 = 1 s)',{min:1,max:999})],{frames:60},c=>'Wait: '+c.frames+' frames');

C('setswitch','Control Switches','Game Progress',[F('a','switch','Switch (from)'),F('a2','switch','Switch (to)'),F('val','select','Set',{opts:['on','off','toggle']})],{a:1,a2:1,val:'on'},c=>'Switches: #'+c.a+(c.a2>c.a?'..#'+c.a2:'')+' = '+ON(c.val));
C('setvar','Control Variables','Game Progress',[F('a','variable','Variable (from)'),F('a2','variable','Variable (to)'),F('op','select','Operation',{opts:['=','+=','-=','*=','/=','%=']}),F('src','select','Operand',{opts:['constant','variable','random','item count','gold','steps','playtime','map id','party size','player x','player y','script']}),F('v','any','Value / Script'),F('v2','number','Random max')],{a:1,a2:1,op:'=',src:'constant',v:0,v2:10},c=>'Variable: #'+c.a+(c.a2>c.a?'..#'+c.a2:'')+' '+c.op+' '+c.src+(c.src==='constant'||c.src==='script'||c.src==='variable'?' '+c.v:c.src==='random'?' '+c.v+'..'+c.v2:c.src==='item count'?' item#'+c.v:''));
C('setself','Control Self Switch','Game Progress',[F('key','select','Self Switch',{opts:['A','B','C','D']}),F('val','select','Set',{opts:['on','off','toggle']})],{key:'A',val:'on'},c=>'Self Switch '+c.key+' = '+ON(c.val));
C('gold','Change Gold','Party',[F('op','select','Operation',{opts:['+','-']}),F('v','number','Amount',{min:0,max:99999999})],{op:'+',v:100},c=>'Change Gold: '+c.op+' '+c.v);
C('item','Change Items','Party',[F('kind','select','Type',{opts:['item','weapon','armor']}),F('id','itemref','Item'),F('op','select','Operation',{opts:['+','-']}),F('n','number','Quantity',{min:1,max:99})],{kind:'item',id:1,op:'+',n:1},(c,db)=>'Change '+c.kind+': '+nm(db&&db[c.kind==='item'?'items':c.kind==='weapon'?'weapons':'armors'],c.id)+' '+c.op+' '+c.n);
C('partymember','Change Party Member','Party',[F('actor','actor','Actor'),F('op','select','Operation',{opts:['add','remove']}),F('init','bool','Initialize on add')],{actor:1,op:'add',init:true},(c,db)=>'Party Member: '+c.op+' '+nm(db&&db.actors,c.actor));
C('hp','Change HP','Actor',[F('target','actortarget','Actor'),F('op','select','Operation',{opts:['+','-']}),F('v','number','Amount',{min:0,max:99999}),F('death','bool','Allow Knockout')],{target:0,op:'+',v:50,death:false},c=>'Change HP: '+(c.target?'#'+c.target:'Entire party')+' '+c.op+' '+c.v);
C('mp','Change MP','Actor',[F('target','actortarget','Actor'),F('op','select','Operation',{opts:['+','-']}),F('v','number','Amount',{min:0,max:99999})],{target:0,op:'+',v:20},c=>'Change MP: '+(c.target?'#'+c.target:'Entire party')+' '+c.op+' '+c.v);
C('state','Change State','Actor',[F('target','actortarget','Actor'),F('op','select','Operation',{opts:['add','remove']}),F('state','state','State')],{target:0,op:'add',state:3},(c,db)=>'Change State: '+(c.target?'#'+c.target:'Entire party')+' '+c.op+' '+nm(db&&db.states,c.state));
C('recover','Recover All','Actor',[F('target','actortarget','Actor')],{target:0},c=>'Recover All: '+(c.target?'#'+c.target:'Entire party'));
C('exp','Change EXP','Actor',[F('target','actortarget','Actor'),F('op','select','Operation',{opts:['+','-']}),F('v','number','Amount',{min:0,max:9999999}),F('show','bool','Show level up')],{target:0,op:'+',v:100,show:true},c=>'Change EXP: '+(c.target?'#'+c.target:'Entire party')+' '+c.op+' '+c.v);
C('level','Change Level','Actor',[F('target','actortarget','Actor'),F('op','select','Operation',{opts:['+','-']}),F('v','number','Levels',{min:1,max:99})],{target:0,op:'+',v:1},c=>'Change Level: '+(c.target?'#'+c.target:'Entire party')+' '+c.op+' '+c.v);
C('skill','Change Skill','Actor',[F('target','actor','Actor'),F('op','select','Operation',{opts:['learn','forget']}),F('skill','skill','Skill')],{target:1,op:'learn',skill:1},(c,db)=>'Change Skill: actor#'+c.target+' '+c.op+' '+nm(db&&db.skills,c.skill));
C('name','Change Name','Actor',[F('actor','actor','Actor'),F('name','text','Name')],{actor:1,name:''},c=>'Change Name: actor#'+c.actor+' -> '+c.name);
C('class','Change Class','Actor',[F('actor','actor','Actor'),F('cls','class','Class')],{actor:1,cls:1},c=>'Change Class: actor#'+c.actor+' -> class#'+c.cls);
C('actorimage','Change Actor Graphic','Actor',[F('actor','actor','Actor'),F('img','charimg','Character')],{actor:1,img:{kind:'preset',name:'Hero'}},c=>'Change Actor Graphic: actor#'+c.actor);
C('nameinput','Name Input Processing','Actor',[F('actor','actor','Actor'),F('max','number','Max chars',{min:1,max:16})],{actor:1,max:8},c=>'Name Input: actor#'+c.actor);

C('transfer','Transfer Player','Movement',[F('mode','select','Designation',{opts:['direct','variables']}),F('map','map','Map'),F('x','number','X',{min:0,max:999}),F('y','number','Y',{min:0,max:999}),F('dir','select','Direction',{opts:['0','2','4','6','8'],labels:['Retain','Down','Left','Right','Up']}),F('fade','select','Fade',{opts:['black','white','none']})],{mode:'direct',map:1,x:0,y:0,dir:0,fade:'black'},(c,db)=>'Transfer Player: '+(c.mode==='direct'?'Map '+c.map+' ('+c.x+','+c.y+')':'variables')+' '+DIRS[c.dir]);
C('setevtloc','Set Event Location','Movement',[F('event','event','Event'),F('mode','select','Designation',{opts:['direct','variables','exchange']}),F('x','number','X',{min:0,max:999}),F('y','number','Y',{min:0,max:999}),F('dir','select','Direction',{opts:['0','2','4','6','8'],labels:['Retain','Down','Left','Right','Up']})],{event:0,mode:'direct',x:0,y:0,dir:0},c=>'Set Event Location: '+(c.event===0?'This':c.event===-1?'Player':'#'+c.event)+' ('+c.x+','+c.y+')');
C('moveroute','Set Move Route','Movement',[F('target','event','Target'),F('route','route','Route'),F('wait','bool','Wait for completion'),F('repeat','bool','Repeat')],{target:-1,route:[],wait:true,repeat:false},c=>'Move Route: '+(c.target===-1?'Player':c.target===0?'This Event':'#'+c.target)+' ('+(c.route||[]).length+' steps)');
C('transparent','Change Transparency','Movement',[F('val','select','Player',{opts:['on','off']})],{val:'on'},c=>'Transparency: '+c.val);
C('followers','Change Followers','Movement',[F('val','select','Followers',{opts:['on','off']})],{val:'on'},c=>'Followers: '+c.val);
C('screenfx','Screen Effect (fog, blur...)','Screen',[F('op','select','Action',{opts:['add','remove','clear'],labels:['Add / change','Remove one','Remove all']}),F('id','number','Effect #',{min:1,max:30}),F('type','select','Type',{opts:R.FX_TYPES}),F('color','color','Color'),F('opacity','number','Opacity %',{min:0,max:100}),F('power','number','Strength / blur px / pixel size',{min:0,max:40}),F('speed','number','Speed',{min:0,max:40}),F('size','number','Size %',{min:10,max:500}),F('angle','number','Direction (deg)',{min:0,max:360}),F('radius','number','Light radius (darkness)',{min:40,max:800}),F('count','number','Particle count',{min:1,max:400}),F('img','asset','Overlay image',{kinds:['pictures']}),F('frames','number','Fade frames',{min:1,max:600})],{op:'add',id:1,type:'fog',color:'#c8d2e6',opacity:45,power:6,speed:5,size:100,angle:0,radius:200,count:40,img:'',frames:60},c=>c.op==='clear'?'Screen Effect: remove all':c.op==='remove'?'Screen Effect #'+c.id+': remove':'Screen Effect #'+c.id+': '+c.type+' '+c.opacity+'%');

C('lighting','Lighting / Day-Night','Screen',[F('op','select','Action',{opts:['time','addtime','clock','torch','map','shadows','tovar'],labels:['Set time of day','Advance time','Clock: auto on / off','Player torch','Change THIS map lighting','Shadows on / off','Store hour in variable']}),F('hour','number','Hour (0-24, e.g. 21.5)',{min:-24,max:24,step:.5,float:true}),F('frames','number','Transition frames (0 = instant)',{min:0,max:3600}),F('on','select','State',{opts:['on','off'],labels:['ON','OFF']}),F('dayMin','number','Real minutes per game day',{min:0,max:240}),F('radius','number','Torch radius',{min:40,max:600}),F('color','color','Color'),F('mode','select','Map lighting',{opts:['off','time','fixed'],labels:['Off','Follows time of day','Fixed darkness']}),F('playerLight','number','Player light radius (0 = none)',{min:0,max:600}),F('v','variable','Variable')],{op:'time',hour:21,frames:120,on:'on',dayMin:0,radius:220,color:'#ffd9a0',mode:'time',playerLight:0,v:1},c=>({time:'Set time to '+c.hour+':00',addtime:'Advance time '+c.hour+' h',clock:'Clock auto '+c.on,torch:'Player torch '+c.on,map:'This map lighting: '+c.mode,shadows:'Shadows '+c.on,tovar:'Hour -> variable '+c.v}[c.op]||'Lighting'));C('camera','Camera Move','Screen',[F('op','select','Move to',{opts:['event','tile','player','zoom'],labels:['Event / Player','Map tile (x,y)','Back to player (end)','Zoom only']}),F('ev','event','Target'),F('x','number','Tile X',{min:0,max:255}),F('y','number','Tile Y',{min:0,max:255}),F('zoom','number','Zoom %',{min:100,max:300}),F('frames','number','Duration (frames)',{min:0,max:600}),F('ease','select','Easing',{opts:['smooth','linear']}),F('wait','bool','Wait')],{op:'event',ev:-1,x:0,y:0,zoom:100,frames:60,ease:'smooth',wait:true},c=>'Camera: '+(c.op==='tile'?'tile ('+c.x+','+c.y+')':c.op==='event'?'event '+(c.ev===-1?'Player':c.ev===0?'This Event':'#'+c.ev):c.op==='zoom'?'zoom':'back to player')+' zoom '+c.zoom+'%, '+c.frames+'f');
C('cinema','Cinematic Mode','Screen',[F('on','select','Mode',{opts:['on','off'],labels:['ON (bars, hide HUD)','OFF']})],{on:'on'},c=>'Cinematic Mode '+c.on.toUpperCase());
C('media','Show Image / Video','Screen',[F('id','number','Slot #',{min:1,max:10}),F('src','asset','File',{kinds:['videos','pictures']}),F('pos','select','Position',{opts:['full','left','right','top','custom']}),F('x','number','X (custom)',{min:-2000,max:2000}),F('y','number','Y (custom)',{min:-2000,max:2000}),F('w','number','Width (custom)',{min:8,max:2000}),F('h','number','Height (custom)',{min:8,max:2000}),F('fit','select','Fit',{opts:['contain','cover','stretch']}),F('opacity','number','Opacity %',{min:0,max:100}),F('frames','number','Fade-in frames',{min:1,max:300}),F('dim','bool','Dim background (non-full)'),F('loop','bool','Loop (video)'),F('mute','bool','Mute (video)'),F('vol','number','Video volume %',{min:0,max:100}),F('stopBgm','bool','Stop BGM when video starts')],{id:1,src:'',pos:'full',x:0,y:0,w:400,h:300,fit:'contain',opacity:100,frames:20,dim:true,loop:false,mute:false,vol:100,stopBgm:false},c=>'Show Media #'+c.id+': '+(c.src||'(none)').split('/').pop());
C('hidemedia','Hide Image / Video','Screen',[F('id','number','Slot # (0 = all)',{min:0,max:10}),F('frames','number','Fade-out frames',{min:1,max:300})],{id:0,frames:15},c=>'Hide Media '+(c.id||'all'));
C('waitmedia','Wait for Video End','Screen',[F('id','number','Slot #',{min:1,max:10}),F('skip','bool','Player can skip (OK)')],{id:1,skip:true},c=>'Wait for Video #'+c.id);
C('doorctl','Door Control','Movement',[F('ev','event','Door event'),F('op','select','Action',{opts:['open','close','lock','unlock','slam'],labels:['Open','Close','Lock','Unlock','Slam shut + lock (shake)']}),F('wait','bool','Wait a moment')],{ev:0,op:'close',wait:true},c=>'Door '+(c.ev===0?'(this)':'#'+c.ev)+': '+c.op);
C('erase','Erase Event','Movement',[],{},()=>'Erase Event');

C('fadeout','Fadeout Screen','Screen',[],{},()=>'Fadeout Screen');
C('fadein','Fadein Screen','Screen',[],{},()=>'Fadein Screen');
C('tint','Tint Screen','Screen',[F('r','number','Red',{min:-255,max:255}),F('g','number','Green',{min:-255,max:255}),F('b','number','Blue',{min:-255,max:255}),F('gray','number','Gray',{min:0,max:255}),F('frames','number','Frames',{min:1,max:600}),F('wait','bool','Wait')],{r:0,g:0,b:0,gray:0,frames:60,wait:true},c=>'Tint Screen ('+c.r+','+c.g+','+c.b+','+c.gray+')');
C('flash','Flash Screen','Screen',[F('color','color','Color'),F('frames','number','Frames',{min:1,max:600}),F('wait','bool','Wait')],{color:'#ffffff',frames:30,wait:true},c=>'Flash Screen '+c.color);
C('shake','Shake Screen','Screen',[F('power','number','Power',{min:1,max:9}),F('speed','number','Speed',{min:1,max:9}),F('frames','number','Frames',{min:1,max:600}),F('wait','bool','Wait')],{power:5,speed:5,frames:60,wait:true},c=>'Shake Screen: power '+c.power);
C('weather','Set Weather Effect','Screen',[F('type','select','Type',{opts:['none','rain','storm','snow']}),F('power','number','Power',{min:1,max:9}),F('frames','number','Frames',{min:1,max:600})],{type:'rain',power:5,frames:60},c=>'Weather: '+c.type);
C('showpic','Show Picture','Screen',[F('id','number','Picture #',{min:1,max:20}),F('name','picture','Image'),F('x','number','X',{min:-9999,max:9999}),F('y','number','Y',{min:-9999,max:9999}),F('scale','number','Scale %',{min:1,max:500}),F('opacity','number','Opacity',{min:0,max:255})],{id:1,name:'',x:0,y:0,scale:100,opacity:255},c=>'Show Picture #'+c.id+' '+c.name);
C('movepic','Move Picture','Screen',[F('id','number','Picture #',{min:1,max:20}),F('x','number','X',{min:-9999,max:9999}),F('y','number','Y',{min:-9999,max:9999}),F('scale','number','Scale %',{min:1,max:500}),F('opacity','number','Opacity',{min:0,max:255}),F('frames','number','Frames',{min:1,max:600}),F('wait','bool','Wait')],{id:1,x:0,y:0,scale:100,opacity:255,frames:60,wait:true},c=>'Move Picture #'+c.id);
C('erasepic','Erase Picture','Screen',[F('id','number','Picture #',{min:1,max:20})],{id:1},c=>'Erase Picture #'+c.id);
C('animation','Show Animation','Screen',[F('target','event','Target'),F('anim','anim','Animation'),F('wait','bool','Wait')],{target:-1,anim:'Slash',wait:true},c=>'Animation: '+c.anim+' on '+(c.target===-1?'Player':c.target===0?'This Event':'#'+c.target));
C('balloon','Show Balloon Icon','Screen',[F('target','event','Target'),F('icon','select','Icon',{opts:['Exclamation','Question','Music','Heart','Anger','Sweat','Frustration','Silence','Light bulb','Zzz']}),F('wait','bool','Wait')],{target:0,icon:'Exclamation',wait:true},c=>'Balloon: '+c.icon);

C('playbgm','Play BGM','Audio',[F('name','bgm','BGM'),F('vol','number','Volume %',{min:0,max:100})],{name:'Peaceful Village',vol:100},c=>'Play BGM: '+c.name);
C('fadebgm','Fadeout BGM','Audio',[F('sec','number','Seconds',{min:1,max:60})],{sec:3},c=>'Fadeout BGM: '+c.sec+'s');
C('stopbgm','Stop BGM','Audio',[],{},()=>'Stop BGM');
C('playse','Play SE','Audio',[F('name','se','SE'),F('vol','number','Volume %',{min:0,max:100})],{name:'OK',vol:100},c=>'Play SE: '+c.name);

C('battle','Battle Processing','Scene',[F('kind','select','Troop',{opts:['direct','variable','random']}),F('id','troop','Troop'),F('escape','bool','Can Escape'),F('lose','bool','Continue Even When Loser')],{kind:'direct',id:1,escape:true,lose:false},(c,db)=>'Battle: '+nm(db&&db.troops,c.id),{block:'battle'});
C('ifwin','If Win','Scene',[],{},()=>'If Win',{hidden:true});
C('ifescape','If Escape','Scene',[],{},()=>'If Escape',{hidden:true});
C('iflose','If Lose','Scene',[],{},()=>'If Lose',{hidden:true});
C('endbattle','End Battle','Scene',[],{},()=>'End',{hidden:true});
C('shop','Shop Processing','Scene',[F('goods','goods','Goods'),F('buyOnly','bool','Purchase Only')],{goods:[],buyOnly:false},c=>'Shop: '+(c.goods||[]).length+' goods');
C('menu','Open Menu Screen','Scene',[],{},()=>'Open Menu Screen');
C('save','Open Save Screen','Scene',[],{},()=>'Open Save Screen');
C('gameover','Game Over','Scene',[],{},()=>'Game Over');
C('title','Return to Title Screen','Scene',[],{},()=>'Return to Title Screen');
C('sysopt','Change System Access','Scene',[F('key','select','Setting',{opts:['save','menu','encounter']}),F('val','select','Value',{opts:['on','off']})],{key:'save',val:'off'},c=>'Access: '+c.key+' '+c.val);
C('script','Script','Advanced',[F('s','multiline','JavaScript ($game, $v(n), $s(n), $map, $player, R)')],{s:''},c=>'Script: '+(c.s||'').split('\n')[0]);
R.CMD_DIRS = DIRS;
R.cmdSummary = function(c,db){ const d=CMDS[c.c]; return d? d.sum(c,db): '??? '+c.c; };
R.newCmd = function(code,indent){ const d=CMDS[code]; const o=Object.assign({c:code,i:indent||0},JSON.parse(JSON.stringify(d.def||{}))); return o; };
/* Bangun daftar perintah lengkap (dengan blok pembuka/penutup) untuk satu perintah yang baru */
R.buildCmdBlock = function(code,indent,fields){
  const base = Object.assign(R.newCmd(code,indent),fields||{}); const out=[base]; const i=indent;
  if(code==='choices'){ (base.opts||[]).forEach((o,k)=>{ out.push({c:'when',i:i,idx:k}); out.push({c:'empty',i:i+1}); }); if(base.cancel===1){ out.push({c:'when',i:i,idx:-2}); out.push({c:'empty',i:i+1}); } out.push({c:'endchoices',i:i}); }
  else if(code==='if'){ out.push({c:'empty',i:i+1}); if(base.else){ out.push({c:'else',i:i}); out.push({c:'empty',i:i+1}); } out.push({c:'endif',i:i}); }
  else if(code==='loop'){ out.push({c:'empty',i:i+1}); out.push({c:'endloop',i:i}); }
  else if(code==='battle'){ out.push({c:'ifwin',i:i}); out.push({c:'empty',i:i+1}); if(base.escape){ out.push({c:'ifescape',i:i}); out.push({c:'empty',i:i+1}); } if(base.lose){ out.push({c:'iflose',i:i}); out.push({c:'empty',i:i+1}); } out.push({c:'endbattle',i:i}); }
  return out;
};
})();
