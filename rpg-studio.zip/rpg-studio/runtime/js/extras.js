/* Extras: tema UI & font, efek layar (kabut/blur/dll), kamera sinematik, media (gambar/video), animasi kustom, keybinds, remap SE */
(function(){
'use strict';
const R = window.RPG, UI = R.UI, H = R.H;
const W=816, Hh=624, T=48;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const ease=(k,m)=> m==='linear'?k : k<.5?2*k*k:1-Math.pow(-2*k+2,2)/2;

/* ================= TEMA UI ================= */
R.UIDEF = { font:'', fontFile:'', fontSize:22, textColor:'#ffffff', outline:'#000014', skinColor:'#1c2a5c', borderColor:'#ffffff', borderColor2:'#7896ff', alpha:.93, radius:10, skinImage:'', skinSlice:16, cursorColor:'#78aaff', gauge:'',
  layout:{ msg:{x:8,y:-1,w:800,h:180}, hud:{x:8,y:8}, boss:{x:0,y:0}, mapName:{x:0,y:0} }, touch:null, touchScale:1 };
R.uiCfg = function(){ const u=(R.$db&&R.$db.system&&R.$db.system.ui)||{}; const d=R.UIDEF; const L={}; for(const k of Object.keys(d.layout)) L[k]=Object.assign({},d.layout[k],(u.layout||{})[k]); return Object.assign({},d,u,{layout:L}); };
R.uiRect = function(name){ return R.uiCfg().layout[name]; };
let fontLoaded='';
R.applyUI = function(){
  const c=R.uiCfg(); UI.cfg=c; UI.skinColor=c.skinColor; UI.fs=c.fontSize||22;
  const fam=[]; if(c.fontFile&&R.$db.assets&&R.$db.assets[c.fontFile]){ const url=R.$db.assets[c.fontFile]; if(fontLoaded!==c.fontFile){ fontLoaded=c.fontFile; try{ const ff=new FontFace('RPGCustomFont','url('+url+')'); ff.load().then(f=>{ document.fonts.add(f); if(R.onImageLoad) R.onImageLoad(); }).catch(()=>{}); }catch(e){} } fam.push('"RPGCustomFont"'); }
  if(c.font) fam.push('"'+c.font+'"'); fam.push('"Segoe UI",Roboto,Arial,sans-serif'); UI.font=fam.join(',');
  if(R.applyTouchLayout) R.applyTouchLayout();
};
function nine(g,im,x,y,w,h,s){ const iw=im.width, ih=im.height; s=Math.min(s,iw/2-1,ih/2-1); const d=Math.min(s,w/2,h/2); const sx=[0,s,iw-s,iw], sy=[0,s,ih-s,ih], dx=[x,x+d,x+w-d,x+w], dy=[y,y+d,y+h-d,y+h];
  g.imageSmoothingEnabled=false; for(let j=0;j<3;j++)for(let i=0;i<3;i++){ const ww=dx[i+1]-dx[i], hh=dy[j+1]-dy[j]; if(ww<=0||hh<=0) continue; g.drawImage(im,sx[i],sy[j],sx[i+1]-sx[i],sy[j+1]-sy[j],dx[i],dy[j],ww,hh); } }
UI.win = function(g,x,y,w,h,o){ o=o||{}; const c=UI.cfg||R.UIDEF; g.save(); const al=o.alpha===undefined?c.alpha:o.alpha;
  const img=c.skinImage&&R.loadImage(c.skinImage);
  if(img){ g.globalAlpha=al; nine(g,img,x,y,w,h,c.skinSlice||16); }
  else { const base=o.color||c.skinColor||UI.skinColor; const gr=g.createLinearGradient(0,y,0,y+h); gr.addColorStop(0,R.shade(base,.18)); gr.addColorStop(1,R.shade(base,-.25)); g.globalAlpha=al; H.rr(g,gr,x,y,w,h,c.radius); g.globalAlpha=1;
    const rr=(inset,r)=>{ g.beginPath(); g.roundRect?g.roundRect(x+inset,y+inset,w-inset*2,h-inset*2,Math.max(0,r)):g.rect(x+inset,y+inset,w-inset*2,h-inset*2); };
    g.strokeStyle=c.borderColor; g.globalAlpha=.85; g.lineWidth=2.5; rr(1.5,c.radius-1); g.stroke(); g.strokeStyle=c.borderColor2; g.globalAlpha=.55; g.lineWidth=1.5; rr(5,c.radius-4); g.stroke(); }
  g.restore(); };
UI.cursor = function(g,x,y,w,h,t){ const c=UI.cfg||R.UIDEF; const a=.55+.25*Math.sin((t||0)/8); g.save(); g.globalAlpha=a; H.rr(g,c.cursorColor,x,y,w,h,6); g.globalAlpha=.55+.4*Math.sin((t||0)/8); g.strokeStyle='rgba(255,255,255,.9)'; g.lineWidth=2; g.strokeRect(x+1,y+1,w-2,h-2); g.restore(); };
{ const t0=UI.text; UI.text=function(g,s,x,y,o){ const c=UI.cfg; if(c&&c.textColor&&c.textColor!=='#ffffff'&&(!o||!o.color)) o=Object.assign({},o,{color:c.textColor}); return t0.call(UI,g,s,x,y,o); }; }

/* ================= REMAP SE ================= */
{ const AU=R.Audio; const se0=AU.se; AU.se=function(name,v){ const m=R.$db&&R.$db.system&&R.$db.system.seMap; if(m&&m[name]) name=m[name]; return se0.call(AU,name,v); }; }

/* ================= PORTRAIT (face dari file) ================= */
{ const fc0=R.faceCanvas; R.faceCanvas=function(img,size){ if(img&&img.kind==='portrait'){ const im=R.loadImage(img.file); if(!im) return null; const k=size||96; const key='P|'+img.file+'|'+k; R.__pf=R.__pf||{}; if(R.__pf[key]) return R.__pf[key]; const c=document.createElement('canvas'); c.width=c.height=k; const g=c.getContext('2d'); const s=Math.min(k/im.width,k/im.height); g.imageSmoothingEnabled=false; g.drawImage(im,(k-im.width*s)/2,(k-im.height*s)/2,im.width*s,im.height*s); return R.__pf[key]=c; } return fc0(img,size); }; }
R.faceOf = function(f){ if(!f) return null; if(typeof f!=='string') return f; if(/^(img|data:)/.test(f)) return {kind:'portrait',file:f}; return R.imgOfName(f); };

/* ================= ICON dari file ================= */
{ const di0=R.drawIcon; R.drawIcon=function(g,idx,x,y,s){ if(typeof idx==='string'){ const im=R.loadImage(idx); if(im){ s=s||32; g.imageSmoothingEnabled=false; g.drawImage(im,x,y,s,s); } return; } return di0(g,idx,x,y,s); }; }

/* ================= EFEK LAYAR ================= */
const Fx = R.Fx = { st:{}, noise:{} };
R.FX_TYPES = R.FX_TYPES||['fog'];
Fx.defaults = ()=>({id:1,type:'fog',color:'#c8d2e6',opacity:45,power:6,speed:5,size:100,angle:0,radius:200,count:40,img:'',frames:60});
function noiseTex(color,seed){ const key=color+seed; if(Fx.noise[key]) return Fx.noise[key]; const S=256, c=document.createElement('canvas'); c.width=c.height=S; const g=c.getContext('2d'); let s=seed*9301+49297; const rnd=()=>{ s=(s*9301+49297)%233280; return s/233280; };
  const rgb=R.hexToRgb?R.hexToRgb(color):[200,210,230]; for(let i=0;i<46;i++){ const x=rnd()*S,y=rnd()*S,r=30+rnd()*70; for(const ox of [-S,0,S]) for(const oy of [-S,0,S]){ const gr=g.createRadialGradient(x+ox,y+oy,0,x+ox,y+oy,r); gr.addColorStop(0,'rgba('+rgb.join(',')+',.55)'); gr.addColorStop(1,'rgba('+rgb.join(',')+',0)'); g.fillStyle=gr; g.fillRect(x+ox-r,y+oy-r,r*2,r*2); } }
  return Fx.noise[key]=c; }
if(!R.hexToRgb) R.hexToRgb=h=>{ h=String(h||'#fff').replace('#',''); if(h.length===3) h=h.split('').map(x=>x+x).join(''); const n=parseInt(h,16); return [(n>>16)&255,(n>>8)&255,n&255]; };
let snap=null, snap2=null;
function getSnap(g,w,h,k){ const c=k?(snap2=snap2||document.createElement('canvas')):(snap=snap||document.createElement('canvas')); if(c.width!==w||c.height!==h){ c.width=w; c.height=h; } return c; }
Fx.list = ()=>{ const g=R.$game; return g&&(g.fx||(g.fx=[])); };
Fx.add = function(cfg){ const l=Fx.list(); if(!l) return; const ex=l.findIndex(e=>e.id===cfg.id); const o=Object.assign(Fx.defaults(),cfg); o.k0=ex>=0?(Fx.cur(l[ex])):0; o.t=0; o.fade=Math.max(1,cfg.frames||1); o.dir=1; if(ex>=0) l[ex]=o; else l.push(o); };
Fx.cur = e=> e.dir<0? Math.max(0,1-e.t/e.fade) * (e.kOut||1) : Math.min(1,(e.k0||0)+e.t/e.fade*(1-(e.k0||0)));
Fx.remove = function(id,frames){ const l=Fx.list(); if(!l) return; if(id==='all'||id===0){ l.forEach(e=>{ e.kOut=Fx.cur(e); e.dir=-1; e.t=0; e.fade=Math.max(1,frames||1); }); } else { const e=l.find(x=>x.id===id); if(e){ e.kOut=Fx.cur(e); e.dir=-1; e.t=0; e.fade=Math.max(1,frames||1); } } };
Fx.update = function(){ const l=Fx.list(); if(!l||!l.length) return; for(const e of l){ e.t++; } for(let i=l.length-1;i>=0;i--){ const e=l[i]; if(e.dir<0&&e.t>=e.fade){ l.splice(i,1); delete Fx.st[e.id]; } } };
Fx.draw = function(g,sc){ const l=Fx.list(); if(!l||!l.length) return; const fr=R.$game.frames;
  for(const e of l){ const k=Fx.cur(e); if(k<=0) continue; const op=clamp((e.opacity||0)/100,0,1)*k; g.save();
    switch(e.type){
      case 'blur': case 'blurEdge': { const px=(e.power||5)*k; const a=getSnap(g,W,Hh,0); const sg=a.getContext('2d'); sg.clearRect(0,0,W,Hh); sg.drawImage(g.canvas,0,0,W,Hh); if(e.type==='blur'){ g.filter='blur('+px.toFixed(1)+'px)'; g.drawImage(a,0,0); g.filter='none'; }
        else { const b=getSnap(g,W,Hh,1), bg=b.getContext('2d'); bg.clearRect(0,0,W,Hh); bg.drawImage(a,0,0); bg.globalCompositeOperation='destination-in'; const r=bg.createRadialGradient(W/2,Hh/2,Math.min(W,Hh)*.18,W/2,Hh/2,Math.max(W,Hh)*.62); r.addColorStop(0,'rgba(0,0,0,0)'); r.addColorStop(1,'rgba(0,0,0,1)'); bg.fillStyle=r; bg.fillRect(0,0,W,Hh); bg.globalCompositeOperation='source-over'; g.filter='blur('+px.toFixed(1)+'px)'; g.drawImage(b,0,0); g.filter='none'; } break; }
      case 'grayscale': case 'sepia': { const a=getSnap(g,W,Hh,0); const sg=a.getContext('2d'); sg.clearRect(0,0,W,Hh); sg.drawImage(g.canvas,0,0,W,Hh); g.globalAlpha=op||k; g.filter=(e.type==='sepia'?'sepia(1)':'grayscale(1)'); g.drawImage(a,0,0); g.filter='none'; break; }
      case 'pixelate': { const sz=Math.max(2,Math.round((e.power||6)*k)); const a=getSnap(g,W,Hh,0); const w2=Math.ceil(W/sz), h2=Math.ceil(Hh/sz); const sg=a.getContext('2d'); a.width=w2; a.height=h2; sg.imageSmoothingEnabled=true; sg.drawImage(g.canvas,0,0,w2,h2); g.imageSmoothingEnabled=false; g.drawImage(a,0,0,w2,h2,0,0,w2*sz,h2*sz); g.imageSmoothingEnabled=true; break; }
      case 'fog': case 'mist': { const sp=(e.speed||5)*.06, ang=(e.angle||0)*Math.PI/180, sc2=(e.size||100)/100; g.globalAlpha=op; let mask=null;
        if(e.type==='mist'){ mask=getSnap(g,W,Hh,1); const mg=mask.getContext('2d'); mg.clearRect(0,0,W,Hh); }
        const tgt=mask?mask.getContext('2d'):g;
        for(let i=0;i<3;i++){ const tex=noiseTex(e.color,i+1+(e.id|0)); const s=(1.1+i*.7)*sc2*2, sz=256*s; const vx=Math.cos(ang)*sp*(1+i*.6), vy=Math.sin(ang)*sp*(1+i*.6)+.05*(i%2?1:-1); const ox=((fr*vx)%sz+sz)%sz, oy=((fr*vy+i*77)%sz+sz)%sz; tgt.globalAlpha=(mask?1:op)*(.6-i*.1);
          for(let x=-sz+ox;x<W;x+=sz) for(let y=-sz+oy;y<Hh;y+=sz) tgt.drawImage(tex,x,y,sz,sz); }
        if(mask){ const mg=mask.getContext('2d'); mg.globalAlpha=1; mg.globalCompositeOperation='destination-in'; const gr=mg.createLinearGradient(0,Hh*.35,0,Hh); gr.addColorStop(0,'rgba(0,0,0,0)'); gr.addColorStop(1,'rgba(0,0,0,1)'); mg.fillStyle=gr; mg.fillRect(0,0,W,Hh); mg.globalCompositeOperation='source-over'; g.globalAlpha=op*1.2; g.drawImage(mask,0,0); } break; }
      case 'vignette': { const rgb=R.hexToRgb(e.color||'#000000'); const r=g.createRadialGradient(W/2,Hh/2,Math.min(W,Hh)*.25*(1+(e.size||100)/100*.2),W/2,Hh/2,Math.max(W,Hh)*.7); r.addColorStop(0,'rgba('+rgb+',0)'); r.addColorStop(1,'rgba('+rgb+','+op+')'); g.fillStyle=r; g.fillRect(0,0,W,Hh); break; }
      case 'darkness': { const a=getSnap(g,W,Hh,1), ag=a.getContext('2d'); ag.globalCompositeOperation='source-over'; ag.clearRect(0,0,W,Hh); const rgb=R.hexToRgb(e.color||'#000010'); ag.fillStyle='rgba('+rgb+','+op+')'; ag.fillRect(0,0,W,Hh); const p=sc.map.charScreen?sc.map.charScreen(sc.player,-(sc.map.dispX-Math.floor(sc.map.dispX))*T,-(sc.map.dispY-Math.floor(sc.map.dispY))*T,Math.floor(sc.map.dispX),Math.floor(sc.map.dispY)):{x:W/2,y:Hh/2}; const cx=p.x+24, cy=p.y+20, rad=(e.radius||200)*(1+Math.sin(fr/9)*.02);
        ag.globalCompositeOperation='destination-out'; const rg=ag.createRadialGradient(cx,cy,rad*.1,cx,cy,rad); rg.addColorStop(0,'rgba(0,0,0,1)'); rg.addColorStop(1,'rgba(0,0,0,0)'); ag.fillStyle=rg; ag.fillRect(0,0,W,Hh); ag.globalCompositeOperation='source-over'; g.drawImage(a,0,0); break; }
      case 'scanlines': { g.globalAlpha=op*.6; g.fillStyle='#000'; for(let y=0;y<Hh;y+=Math.max(2,Math.round((e.size||100)/25))*1) g.fillRect(0,y,W,1); break; }
      case 'colorWash': { g.globalAlpha=op; g.globalCompositeOperation=e.power>5?'overlay':'source-over'; g.fillStyle=e.color; g.fillRect(0,0,W,Hh); break; }
      case 'overlay': { const im=e.img&&R.loadImage(e.img); if(im){ g.globalAlpha=op; const sp=(e.speed||0)*.3, ang=(e.angle||0)*Math.PI/180; const sz=Math.max(32,im.width*(e.size||100)/100), sh=im.height*sz/im.width; if(e.speed){ const ox=((fr*Math.cos(ang)*sp)%sz+sz)%sz, oy=((fr*Math.sin(ang)*sp)%sh+sh)%sh; for(let x=-sz+ox;x<W;x+=sz) for(let y=-sh+oy;y<Hh;y+=sh) g.drawImage(im,x,y,sz,sh); } else g.drawImage(im,0,0,W,Hh); } break; }
      case 'particles': { let st=Fx.st[e.id]; const n=Math.max(1,e.count|0); if(!st||st.n!==n){ st=Fx.st[e.id]={n:n,p:Array.from({length:n},()=>({x:Math.random()*W,y:Math.random()*Hh,s:.5+Math.random(),ph:Math.random()*6.28}))}; }
        const ang=(e.angle||0)*Math.PI/180, sp=(e.speed||5)*.25, sz=Math.max(1,(e.size||100)/100*2.5); g.fillStyle=e.color; g.shadowColor=e.color; g.shadowBlur=8;
        for(const q of st.p){ q.x+=Math.cos(ang)*sp*q.s+Math.sin(fr/40+q.ph)*.3; q.y+=Math.sin(ang)*sp*q.s+Math.cos(fr/50+q.ph)*.25; if(q.x<-10) q.x=W+10; if(q.x>W+10) q.x=-10; if(q.y<-10) q.y=Hh+10; if(q.y>Hh+10) q.y=-10; g.globalAlpha=op*(.5+.5*Math.sin(fr/14+q.ph)); g.beginPath(); g.arc(q.x,q.y,sz*q.s,0,6.3); g.fill(); } break; }
    }
    g.restore(); } };

/* ================= KAMERA SINEMATIK ================= */
const Cam = R.Cam = {};
Cam.get = sc => sc.cam||(sc.cam={free:false,x:0,y:0,z:1,tw:null});
Cam.apply = function(sc){ const c=sc.cam, p=sc.player; if(!c||(!c.free&&!c.tw&&c.z===1)){ sc.map.centerOn(p.rx,p.ry); return; }
  if(c.tw){ const t=c.tw; t.t++; const k=ease(Math.min(1,t.t/t.dur),t.ease); const tx=t.toPlayer?p.rx:t.x, ty=t.toPlayer?p.ry:t.y; c.x=t.fx+(tx-t.fx)*k; c.y=t.fy+(ty-t.fy)*k; c.z=t.fz+(t.z-t.fz)*k; if(t.t>=t.dur){ c.tw=null; if(t.toPlayer){ c.free=false; c.z=t.z; } } }
  if(c.free) sc.map.centerOn(c.x,c.y); else sc.map.centerOn(p.rx,p.ry); };
Cam.begin = function(sc){ const c=Cam.get(sc); if(!c.free){ c.free=true; c.x=sc.map.dispX+(sc.map.vw-1)/2; c.y=sc.map.dispY+(sc.map.vh-1)/2; } return c; };
Cam.zoomed = function(sc,g,fn){ const c=sc.cam; const z=c&&c.z>1.001?c.z:1; if(z===1){ fn(); return; } g.save(); g.translate(W/2,Hh/2); g.scale(z,z); g.translate(-W/2,-Hh/2); fn(); g.restore(); };
Cam.cmd = function*(sc,c,ctx){ const cam=Cam.get(sc); const frames=Math.max(1,c.frames||60); const z=Math.max(1,(c.zoom||100)/100);
  if(c.op==='player'){ if(!cam.free&&cam.z===1) return; Cam.begin(sc); cam.tw={fx:cam.x,fy:cam.y,fz:cam.z,toPlayer:true,z:1,dur:c.frames===0?1:frames,t:0,ease:c.ease}; }
  else { Cam.begin(sc); let tx,ty; if(c.op==='tile'){ tx=c.x; ty=c.y; } else { const ch=sc.getChar(c.ev,ctx)||sc.player; tx=(ch.rx!==undefined?ch.rx:ch.x); ty=(ch.ry!==undefined?ch.ry:ch.y); } if(c.op==='zoom'){ tx=cam.x; ty=cam.y; }
    cam.tw={fx:cam.x,fy:cam.y,fz:cam.z,x:tx,y:ty,z:c.op==='zoom'?z:z,dur:c.frames===0?1:frames,t:0,ease:c.ease}; }
  if(c.wait!==false){ while(cam.tw) yield; } };

/* ================= MEDIA (gambar / video) ================= */
const Media = R.Media = { };
Media.items = sc => sc.media||(sc.media={});
Media.show = function(sc,c){ const m=Media.items(sc); const id=c.id||1; Media.hideNow(sc,id); const srcU=R.assetUrl(c.src||''); const kind=c.kind||((/^data:video/.test(srcU)||/\.(mp4|webm|ogv|mov|m4v)(\?|$)/i.test(srcU))?'video':'image'); c=Object.assign({},c,{kind:kind}); const it={id:id,kind:kind,src:srcU,fit:c.fit||'contain',pos:c.pos||'full',x:c.x||0,y:c.y||0,w:c.w||W,h:c.h||Hh,opacity:(c.opacity===undefined?100:c.opacity)/100,a:0,fadeIn:Math.max(1,c.frames||20),out:0,dim:c.dim!==false&&c.dim!==0,ended:false};
  if(c.kind==='video'){ const v=document.createElement('video'); v.src=it.src; v.loop=!!c.loop; v.muted=!!c.mute; v.playsInline=true; v.volume=clamp((c.vol===undefined?100:c.vol)/100*R.Audio.vol.se/.7,0,1); v.onended=()=>{ it.ended=true; }; const pr=v.play(); if(pr&&pr.catch) pr.catch(()=>{ v.muted=true; v.play().catch(()=>{}); }); it.el=v; if(c.stopBgm) R.Audio.stopBgm(); }
  else it.el=null; m[id]=it; };
Media.hideNow = function(sc,id){ const m=Media.items(sc), it=m[id]; if(it){ if(it.el){ try{ it.el.pause(); it.el.removeAttribute('src'); it.el.load(); }catch(e){} } delete m[id]; } };
Media.hide = function(sc,id,frames){ const m=Media.items(sc); const list=id===0?Object.values(m):[m[id]]; for(const it of list){ if(it){ it.out=Math.max(1,frames||15); it.outT=0; } } };
Media.update = function(sc){ const m=sc.media; if(!m) return; for(const id of Object.keys(m)){ const it=m[id]; if(it.out){ it.outT++; it.a=Math.max(0,1-it.outT/it.out); if(it.outT>=it.out) Media.hideNow(sc,id); } else it.a=Math.min(1,it.a+1/it.fadeIn); } };
Media.draw = function(g,sc){ const m=sc.media; if(!m) return; for(const it of Object.values(m)){ if(it.a<=0) continue; g.save(); g.globalAlpha=it.a*it.opacity; let src=null,iw=0,ih=0;
    if(it.kind==='video'){ src=it.el; if(src&&src.readyState>=2){ iw=src.videoWidth; ih=src.videoHeight; } else src=null; } else { const im=R.loadImage(it.src); if(im){ src=im; iw=im.width; ih=im.height; } }
    if(it.dim&&it.pos==='full'&&false){}
    if(src&&iw){ let x=it.x,y=it.y,w=it.w,h=it.h; if(it.pos==='full'){ x=0;y=0;w=W;h=Hh; } else if(it.pos==='left'){ x=0;y=0;w=W*.5;h=Hh*.7; } else if(it.pos==='right'){ x=W*.5;y=0;w=W*.5;h=Hh*.7; } else if(it.pos==='top'){ x=W*.15;y=10;w=W*.7;h=Hh*.6; }
      if(it.dim&&it.pos!=='full'){ g.fillStyle='rgba(0,0,0,.55)'; g.fillRect(0,0,W,Hh); }
      let dw=w,dh=h,dx=x,dy=y; if(it.fit==='contain'){ const s=Math.min(w/iw,h/ih); dw=iw*s; dh=ih*s; dx=x+(w-dw)/2; dy=y+(h-dh)/2; } else if(it.fit==='cover'){ const s=Math.max(w/iw,h/ih); dw=iw*s; dh=ih*s; g.beginPath(); g.rect(x,y,w,h); g.clip(); dx=x+(w-dw)/2; dy=y+(h-dh)/2; }
      g.drawImage(src,dx,dy,dw,dh); }
    g.restore(); } };
Media.waitEnd = function*(sc,id,skippable){ const it=Media.items(sc)[id]; if(!it||!it.el) return; while(it&&!it.ended&&Media.items(sc)[id]===it){ if(skippable&&(R.Input.pressed('ok')||R.Input.pressed('cancel')||R.Input.clicked())){ R.Input.flush(); break; } yield; } };

/* ================= KONTROL PINTU dari event ================= */
R.doorCmd = function(sc,c,ctx){ const ev=sc.getChar(c.ev,ctx); if(!ev||!ev.door) return; const g=R.$game, D=R.Door, k=(ch)=>ev.map.id+','+ev.id+','+ch; const key=(ch)=>[ev.map.id,ev.id,ch];
  const sw=R.Door.setSw; if(c.op==='open'){ D.setOpen(ev,true,true); } else if(c.op==='close'){ D.setOpen(ev,false,true); } else if(c.op==='lock'){ D.lockSet(ev,true); } else if(c.op==='unlock'){ D.lockSet(ev,false); } else if(c.op==='slam'){ D.setOpen(ev,false,true); D.lockSet(ev,true); sc.shakeFx={p:3,s:6,t:0,dur:14}; R.Audio.se('Crit',.7); } };

/* ================= ANIMASI KUSTOM (sprite sheet) ================= */
const Anim = R.Anim = { list:[] };
Anim.byId = id => id&&R.$db&&R.$db.animations&&R.$db.animations[id-1];
Anim.defaults = ()=>({name:'New Animation',file:'',cols:5,rows:1,frames:0,fps:20,scale:100,offX:0,offY:0,rotate:true,blend:'normal',sound:'',soundFrame:0,loop:false,flip:false});
Anim.nFrames = a => a.frames>0?Math.min(a.frames,a.cols*a.rows):a.cols*a.rows;
Anim.drawFrame = function(g,a,x,y,t,ang){ const im=a.file&&R.loadImage(a.file); if(!im) return false; const n=Anim.nFrames(a), fi=Math.floor(t*(a.fps||20)/60)%n; const fw=im.width/a.cols, fh=im.height/a.rows, cx=(fi%a.cols)*fw, cy=Math.floor(fi/a.cols)*fh; const s=(a.scale||100)/100; g.save(); g.translate(x+(a.offX||0),y+(a.offY||0)); if(a.rotate&&ang) g.rotate(ang); if(a.flip) g.scale(-1,1); if(a.blend==='lighter') g.globalCompositeOperation='lighter'; g.imageSmoothingEnabled=false; g.drawImage(im,cx,cy,fw,fh,-fw*s/2,-fh*s/2,fw*s,fh*s); g.restore(); return true; };
Anim.dur = a => Math.ceil(Anim.nFrames(a)/(a.fps||20)*60);
Anim.playAt = function(sc,id,x,y,dir,ang){ const a=Anim.byId(id); if(!a) return; Anim.list.push({a:a,x:x,y:y,ang:ang!==undefined?ang:({2:Math.PI/2,4:Math.PI,6:0,8:-Math.PI/2}[dir]||0),t:0,dur:a.loop?9999:Anim.dur(a)}); if(a.sound) R.Audio.se(a.sound,.8); };
Anim.playOn = function(sc,id,ch,ang){ const a=Anim.byId(id); if(!a||!ch) return; Anim.list.push({a:a,ch:ch,ang:ang||0,t:0,dur:Anim.dur(a)}); if(a.sound) R.Audio.se(a.sound,.8); };
Anim.update = function(){ for(const o of Anim.list) o.t++; Anim.list=Anim.list.filter(o=>o.t<o.dur); };
Anim.draw = function(g,S){ for(const o of Anim.list){ const x=o.ch?(o.ch.rx!==undefined?o.ch.rx:o.ch.x):o.x, y=o.ch?(o.ch.ry!==undefined?o.ch.ry:o.ch.y):o.y; const c=S(x,y); Anim.drawFrame(g,o.a,c.x+24,c.y+26,o.t,o.ang); } };
Anim.reset = ()=>{ Anim.list=[]; };
/* frame monster dari sheet */
const frameCache=new Map();
Anim.mobFrame = function(en,state,t,dir){ const s=en.sheet; if(!s||!s.file) return null; const im=R.loadImage(s.file); if(!im) return null; const cols=s.cols||4, rows=s.rows||1; const rowOf={idle:s.idleRow,walk:s.walkRow,attack:s.attackRow,hurt:s.hurtRow,die:s.dieRow}; let row=rowOf[state]; if(row===undefined||row===''||row<0||row>=rows) row=(s.idleRow>=0&&s.idleRow<rows)?s.idleRow:0;
  const fi=state==='die'?Math.min(cols-1,Math.floor(t*(s.fps||8)/60)):Math.floor(t*(s.fps||8)/60)%cols; const key=s.file+'|'+cols+'|'+rows+'|'+row+'|'+fi+'|'+(s.flipLeft&&dir===4?1:0); let c=frameCache.get(key); if(c) return c;
  const fw=im.width/cols, fh=im.height/rows; c=document.createElement('canvas'); c.width=Math.round(fw); c.height=Math.round(fh); const g=c.getContext('2d'); g.imageSmoothingEnabled=false; if(s.flipLeft&&dir===4){ g.translate(c.width,0); g.scale(-1,1); } g.drawImage(im,fi*fw,row*fh,fw,fh,0,0,c.width,c.height); frameCache.set(key,c); return c; };

/* ================= KEYBINDS ================= */
const KB = R.Keys = {};
KB.ACTIONS = [['up','Move Up'],['down','Move Down'],['left','Move Left'],['right','Move Right'],['ok','OK / Interact'],['cancel','Cancel / Back'],['menu','Menu'],['shift','Run'],['attack','Attack'],['skill','Use Skill'],['pgup','Previous Skill'],['pgdn','Next Skill']];
KB.defaults = ()=>JSON.parse(JSON.stringify(R.Input.DEFAULT_MAP));
KB.storeKey = ()=>'rpgstudio.keys.'+((R.$db&&R.$db.system&&R.$db.system.title)||'game').replace(/\W/g,'_');
KB.load = function(){ let m=KB.defaults(); const sys=R.$db&&R.$db.system&&R.$db.system.keys; if(sys) for(const a of Object.keys(sys)) if(sys[a]&&sys[a].length) m[a]=sys[a].slice(); try{ const u=JSON.parse(localStorage.getItem(KB.storeKey())||'null'); if(u) for(const a of Object.keys(u)) if(u[a]&&u[a].length) m[a]=u[a].slice(); }catch(e){} R.Input.setMap(m); };
KB.save = function(m){ try{ localStorage.setItem(KB.storeKey(),JSON.stringify(m)); }catch(e){} };
KB.keyName = k=>({' ':'Space','ArrowUp':'↑','ArrowDown':'↓','ArrowLeft':'←','ArrowRight':'→','Escape':'Esc','Enter':'Enter','Shift':'Shift','Control':'Ctrl','Tab':'Tab','Backspace':'Bksp'}[k]||(k.length===1?k.toUpperCase():k));
const B=R.SceneBase||class{};
R.Scene_Keys = class extends B {
  start(){ this.map=JSON.parse(JSON.stringify(R.Input.MAP)); this.sel=0; this.listen=false; this.msg=''; this.co=new R.Co(this.main()); }
  *main(){ const I=R.Input; while(true){ if(this.listen){ yield; continue; } if(I.repeat('down')) { this.sel=(this.sel+1)%(KB.ACTIONS.length+2); R.Audio.se('Cursor'); } if(I.repeat('up')){ this.sel=(this.sel+KB.ACTIONS.length+1)%(KB.ACTIONS.length+2); R.Audio.se('Cursor'); }
      if(I.pressed('cancel')){ R.Audio.se('Cancel'); R.SM.pop(); return; }
      if(I.pressed('ok')||I.clicked()){ if(this.sel<KB.ACTIONS.length){ this.listen=true; this.msg='Press a key for "'+KB.ACTIONS[this.sel][1]+'" (Esc = cancel)'; this.cap=(e)=>{ e.preventDefault(); e.stopPropagation(); window.removeEventListener('keydown',this.cap,true); if(e.key!=='Escape'){ const a=KB.ACTIONS[this.sel][0]; for(const k of Object.keys(this.map)) if(k!==a&&!['menu','cancel'].includes(a)&&!['menu','cancel'].includes(k)) this.map[k]=this.map[k].filter(x=>x!==e.key); this.map[a]=[e.key].concat((this.map[a]||[]).filter(x=>x!==e.key)).slice(0,3); R.Input.setMap(this.map); KB.save(this.map); R.Audio.se('OK'); } this.listen=false; this.msg=''; R.Input.flush(); }; window.addEventListener('keydown',this.cap,true); }
        else if(this.sel===KB.ACTIONS.length){ this.map=KB.defaults(); R.Input.setMap(this.map); try{ localStorage.removeItem(KB.storeKey()); }catch(e){} R.Audio.se('OK'); } else { R.Audio.se('Cancel'); R.SM.pop(); return; } }
      yield; } }
  draw(g){ R.bgMenu(g,this.t); UI.text(g,'Controls',W/2,60,{size:34,align:'center'}); const x=W/2-290; UI.win(g,x,92,580,Hh-150);
    KB.ACTIONS.forEach(([a,n],i)=>{ const y=124+i*36; if(i===this.sel) UI.cursor(g,x+10,y-16,560,32,this.t); UI.text(g,n,x+26,y,{size:20}); const ks=(this.map[a]||[]).map(KB.keyName).join('  /  '); UI.text(g,ks,x+554,y,{size:20,align:'right',color:'#ffe27a'}); });
    const n=KB.ACTIONS.length; [['Reset to defaults',n],['Back',n+1]].forEach(([t,i])=>{ const y=124+i*36+8; if(i===this.sel) UI.cursor(g,x+10,y-16,560,32,this.t); UI.text(g,t,x+290,y,{size:20,align:'center'}); });
    if(this.msg){ UI.win(g,W/2-250,Hh/2-30,500,60); UI.text(g,this.msg,W/2,Hh/2,{size:18,align:'center'}); } }
};

/* ================= BOOT ================= */
R.extrasInit = function(){ R.applyUI(); KB.load(); };
R.extrasReset = function(){ Anim.reset(); };
})();
