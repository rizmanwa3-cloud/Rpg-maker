/* RPG Studio - proses utama Electron */
const { app, BrowserWindow, ipcMain, dialog, shell, Menu } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');

let win = null;
const playWins = new Set();

function createWindow() {
  win = new BrowserWindow({
    width: 1400, height: 880, minWidth: 1000, minHeight: 640,
    backgroundColor: '#1e2230', title: 'RPG Studio',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: false }
  });
  Menu.setApplicationMenu(null);
  win.loadFile(path.join(__dirname, 'editor', 'index.html'));
  win.webContents.on('before-input-event', (e, input) => {
    if (input.type === 'keyDown' && input.key === 'F12' && input.control) win.webContents.toggleDevTools();
  });
  win.on('close', (e) => {
    if (win.__confirmed) return;
    e.preventDefault();
    win.webContents.send('app:before-close');
  });
  win.on('closed', () => { win = null; app.quit(); });
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

/* ---------- util ---------- */
function copyDir(src, dst, skip) {
  fs.mkdirSync(dst, { recursive: true });
  for (const name of fs.readdirSync(src)) {
    if (skip && skip(name)) continue;
    const s = path.join(src, name), d = path.join(dst, name);
    const st = fs.statSync(s);
    if (st.isDirectory()) copyDir(s, d, skip); else fs.copyFileSync(s, d);
  }
}
const runtimeDir = () => path.join(__dirname, 'runtime');
function buildGame(db, projectDir, outDir, opts) {
  opts = opts || {};
  fs.rmSync(outDir, { recursive: true, force: true });
  copyDir(runtimeDir(), outDir, n => n === 'data' || n.startsWith('.'));
  fs.mkdirSync(path.join(outDir, 'data'), { recursive: true });
  fs.writeFileSync(path.join(outDir, 'data', 'project.js'), 'window.PROJECT=' + JSON.stringify(db) + ';');
  if (projectDir) {
    for (const sub of ['img', 'audio']) {
      const p = path.join(projectDir, sub);
      if (fs.existsSync(p)) copyDir(p, path.join(outDir, sub));
    }
  }
  if (opts.standalone) {
    const title = (db.system && db.system.title) || 'RPG Game';
    fs.writeFileSync(path.join(outDir, 'package.json'), JSON.stringify({ name: title.toLowerCase().replace(/[^a-z0-9]+/g, '-') || 'rpg-game', version: '1.0.0', main: 'game-main.js', scripts: { start: 'electron .' }, devDependencies: { electron: '^33.0.0' } }, null, 2));
    fs.writeFileSync(path.join(outDir, 'game-main.js'),
`const { app, BrowserWindow, Menu } = require('electron');
const path = require('path');
app.whenReady().then(() => {
  const w = new BrowserWindow({ width: 816, height: 624, useContentSize: true, backgroundColor: '#000', title: ${JSON.stringify(title)}, autoHideMenuBar: true });
  Menu.setApplicationMenu(null);
  w.loadFile(path.join(__dirname, 'index.html'));
});
app.on('window-all-closed', () => app.quit());
`);
    fs.writeFileSync(path.join(outDir, 'README.txt'), `${title}\n\nHTML5 build: open index.html in any modern browser (Chrome/Edge/Firefox).\nDesktop app: run "npm install" then "npm start" in this folder (needs Node.js).\n`);
  }
}

/* ---------- IPC ---------- */
ipcMain.handle('dlg:pick-dir', async (e, title) => {
  const r = await dialog.showOpenDialog(win, { title: title || 'Select folder', properties: ['openDirectory', 'createDirectory'] });
  return r.canceled ? null : r.filePaths[0];
});
ipcMain.handle('project:open', async (e, dir) => {
  if (!dir) {
    const r = await dialog.showOpenDialog(win, { title: 'Open Project Folder', properties: ['openDirectory'] });
    if (r.canceled) return null; dir = r.filePaths[0];
  }
  const f = path.join(dir, 'project.json');
  if (!fs.existsSync(f)) return { error: 'No project.json found in that folder.' };
  try { return { dir, data: JSON.parse(fs.readFileSync(f, 'utf8')) }; } catch (err) { return { error: 'Cannot read project: ' + err.message }; }
});
ipcMain.handle('project:save', async (e, dir, data) => {
  try {
    fs.mkdirSync(dir, { recursive: true });
    const f = path.join(dir, 'project.json');
    if (fs.existsSync(f)) { try { fs.copyFileSync(f, path.join(dir, 'project.backup.json')); } catch (x) {} }
    fs.writeFileSync(f, JSON.stringify(data));
    for (const sub of ['img/characters', 'img/pictures', 'img/battlers', 'audio']) fs.mkdirSync(path.join(dir, sub), { recursive: true });
    return { ok: true };
  } catch (err) { return { error: err.message }; }
});
ipcMain.handle('asset:import', async (e, dir, kind) => {
  const isAudio = kind === 'audio';
  const r = await dialog.showOpenDialog(win, { title: 'Import ' + kind, properties: ['openFile', 'multiSelections'], filters: isAudio ? [{ name: 'Audio', extensions: ['ogg', 'mp3', 'wav', 'm4a'] }] : [{ name: 'Images', extensions: ['png', 'jpg', 'jpeg', 'gif', 'webp'] }] });
  if (r.canceled) return [];
  const sub = isAudio ? 'audio' : path.join('img', kind);
  const out = [];
  fs.mkdirSync(path.join(dir, sub), { recursive: true });
  for (const f of r.filePaths) { const name = path.basename(f); fs.copyFileSync(f, path.join(dir, sub, name)); out.push(name); }
  return out;
});
ipcMain.handle('asset:list', async (e, dir, kind) => {
  const sub = kind === 'audio' ? 'audio' : path.join('img', kind);
  const p = path.join(dir, sub);
  if (!fs.existsSync(p)) return [];
  return fs.readdirSync(p).filter(n => !n.startsWith('.'));
});
ipcMain.handle('asset:delete', async (e, dir, kind, name) => {
  const sub = kind === 'audio' ? 'audio' : path.join('img', kind);
  try { fs.unlinkSync(path.join(dir, sub, path.basename(name))); return true; } catch (x) { return false; }
});
ipcMain.handle('game:play', async (e, db, dir) => {
  try {
    const out = path.join(os.tmpdir(), 'rpgstudio-play-' + process.pid);
    buildGame(db, dir, out);
    const w = new BrowserWindow({ width: 816, height: 624, useContentSize: true, backgroundColor: '#000', title: (db.system && db.system.title) || 'Playtest', autoHideMenuBar: true, parent: undefined });
    w.setMenuBarVisibility(false);
    w.webContents.on('before-input-event', (ev, input) => { if (input.type === 'keyDown' && input.key === 'F12') w.webContents.toggleDevTools(); });
    playWins.add(w); w.on('closed', () => playWins.delete(w));
    w.loadFile(path.join(out, 'index.html'));
    return { ok: true };
  } catch (err) { return { error: err.message }; }
});
ipcMain.handle('game:deploy', async (e, db, dir, standalone) => {
  const r = await dialog.showOpenDialog(win, { title: 'Choose a folder to place the game build', properties: ['openDirectory', 'createDirectory'] });
  if (r.canceled) return null;
  const title = ((db.system && db.system.title) || 'game').replace(/[^\w\- ]+/g, '').trim() || 'game';
  const out = path.join(r.filePaths[0], title);
  try { buildGame(db, dir, out, { standalone: !!standalone }); shell.showItemInFolder(path.join(out, 'index.html')); return { ok: true, out }; }
  catch (err) { return { error: err.message }; }
});
ipcMain.handle('app:confirm-close', () => { if (win) { win.__confirmed = true; win.close(); } });
ipcMain.handle('app:version', () => app.getVersion());
