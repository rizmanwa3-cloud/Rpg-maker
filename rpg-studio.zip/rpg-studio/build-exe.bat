@echo off
echo === Membangun RPG Studio.exe ===
call npm install || goto :err
call npx electron-builder --win portable --x64 || goto :err
echo.
echo Selesai! File .exe ada di folder "dist".
pause
exit /b 0
:err
echo Gagal. Pastikan Node.js 18+ sudah terpasang.
pause
