/* Editor extras: picker aset, animasi kustom, ikon/sprite kustom, SE remap, UI designer, keybind default */
(function(){
'use strict';
const R = window.RPG, E = window.E, UIx = window.UIx, F = UIx.F, DB = window.DbEdit, Misc = window.Misc;
const db = ()=>App.db, touch = ()=>App.touch();
const isVid = p=>/^video\//.test(p||'')||/\.(mp4|webm|ogv|mov|m4v)$/i.test(p||'');
const srcOf = p=>(db().assets&&db().assets[p])||p;

/* ---------- Day / Night ---------- */
DB.lighting = function(){ const s=db().system; s.clock=Object.assign(R.Light.clockDefaults(),s.clock||{}); const c=s.clock; const f=E('div');
  f.append(E('div',{class:'hint',style:{marginBottom:'8px'},text:'Global clock used by every map set to "Follows time of day". Lamps and torches (Event → Emit light) light up as it gets dark, and shadows follow the sun and each light in real time. Change the time in-game with the Lighting command.'}),
    E('fieldset',null,E('legend',{text:'Clock'}),F.row('',F.chk(c,'auto','Time passes automatically')),F.row('Start hour',E('span',null,F.num(c,'startHour',{min:0,max:23.5,step:.5,float:true,w:65}),' (0–24, 12 = noon)')),F.row('Day length',E('span',null,F.num(c,'dayMinutes',{min:1,max:240,w:65}),' real minutes per game day'))),
    E('fieldset',null,E('legend',{text:'Colors & shadows'}),F.row('Night',F.color(c,'nightColor')),F.row('Dawn',F.color(c,'dawnColor')),F.row('Dusk',F.color(c,'duskColor')),F.row('Sun shadow strength',E('span',null,F.num(c,'shadowStrength',{min:0,max:150,w:65}),' %'))),
    E('div',{class:'hint',text:'Per-map setting: Map Properties → Lighting (Off / Follows time of day / Fixed darkness for caves).'}));
  return f; };

/* ---------- picker aset ---------- */
F.asset = function(o,k,kinds,opts){ opts=opts||{}; kinds=kinds||['pictures']; const wrap=E('span',{style:{display:'inline-flex',gap:'4px',alignItems:'center',flexWrap:'wrap'}});
  const render=()=>{ wrap.innerHTML=''; const options=[{v:'',t:'(none)'}]; for(const kd of kinds) (App.assets&&App.assets[kd]||[]).forEach(n=>options.push({v:App.assetPrefix(kd)+n,t:n})); if(o[k]&&!options.some(x=>x.v===o[k])) options.push({v:o[k],t:String(o[k]).split('/').pop()});
    const s=F.sel(o,k,options,{w:150,change:v=>{ opts.change&&opts.change(v); render(); }}); wrap.append(s);
    if(o[k]&&!isVid(o[k])&&kinds.some(x=>!['audio','videos','fonts'].includes(x))){ wrap.append(E('img',{src:srcOf(o[k]),style:{height:'26px',maxWidth:'44px',objectFit:'contain',imageRendering:'pixelated',background:'#0003',borderRadius:'3px'}})); }
    kinds.forEach(kd=>wrap.append(E('button',{class:'btn sm',text:'⇪ '+({videos:'Video',pictures:'Image',icons:'Icon',anims:'Sheet',faces:'Portrait',battlers:'Battler',ui:'Skin',fonts:'Font',audio:'Audio',characters:'Sheet'}[kd]||kd),title:'Import from this device',onclick:()=>Misc.importAssets(kd,last=>{ if(last){ o[k]=last; touch(); opts.change&&opts.change(last); } render(); })}))); };
  render(); return wrap; };
F.face = function(o,k){ const wrap=E('span',{style:{display:'inline-flex',gap:'4px',alignItems:'center',flexWrap:'wrap'}});
  const render=()=>{ wrap.innerHTML=''; const options=[{v:'',t:'(None)'}].concat(R.CHAR_PRESETS.map(p=>({v:p.name,t:'Preset: '+p.name}))); (App.assets&&App.assets.faces||[]).forEach(n=>options.push({v:'img/faces/'+n,t:'Portrait: '+n})); if(o[k]&&!options.some(x=>x.v===o[k])) options.push({v:o[k],t:String(o[k])});
    wrap.append(F.sel(o,k,options,{w:170,change:()=>render()})); if(/^img\//.test(o[k]||'')) wrap.append(E('img',{src:srcOf(o[k]),style:{height:'34px',maxWidth:'50px',objectFit:'contain'}}));
    wrap.append(E('button',{class:'btn sm',text:'⇪ Import portrait',onclick:()=>Misc.importAssets('faces',last=>{ if(last){ o[k]=last; touch(); } render(); })})); }; render(); return wrap; };

/* ---------- ikon: bawaan atau gambar sendiri ---------- */
F.icon = function(o,k){ const holder=E('span',{style:{display:'inline-flex',gap:'6px',alignItems:'center',flexWrap:'wrap'}});
  const render=()=>{ holder.innerHTML=''; const v=o[k]; if(typeof v==='string'&&v) holder.append(E('img',{src:srcOf(v),style:{width:'32px',height:'32px',objectFit:'contain',imageRendering:'pixelated',background:'#0003',borderRadius:'4px'}}),E('span',{class:'mut',text:v.split('/').pop()}));
    else { const c=UIx.iconCanvas(v,32); c.onclick=()=>UIx.pickIcon(v,n=>{ o[k]=n; touch(); render(); }); holder.append(c,E('span',{class:'mut',text:v&&R.ICONS[v-1]?R.ICONS[v-1].name:'(none)'})); }
    holder.append(E('button',{class:'btn sm',text:'Built-in…',onclick:()=>UIx.pickIcon(typeof v==='number'?v:0,n=>{ o[k]=n; touch(); render(); })}));
    const px={v:typeof v==='string'?v:''}; holder.append(F.asset(px,'v',['icons'],{change:n=>{ o[k]=n||R.iconByName('Star'); touch(); render(); }})); };
  render(); return holder; };

/* ---------- generator animasi prosedural (tanpa hak cipta) ---------- */
const GEN = {
  slash:(g,w,t,col)=>{ const a0=-1.2+t*2.4; g.strokeStyle=col; g.lineCap='round'; for(let i=0;i<5;i++){ g.globalAlpha=(1-t)*(1-i*.18); g.lineWidth=14-i*2.5; g.beginPath(); g.arc(w/2,w/2+10,w*.36,a0-i*.22-1.1,a0-i*.22); g.stroke(); } },
  burst:(g,w,t,col)=>{ g.strokeStyle=col; g.fillStyle=col; g.globalAlpha=1-t; g.lineWidth=8*(1-t)+1; g.beginPath(); g.arc(w/2,w/2,w*.1+t*w*.32,0,6.3); g.stroke(); for(let i=0;i<10;i++){ const a=i*.628, r0=w*.1+t*w*.22, r1=r0+w*.12*(1-t); g.beginPath(); g.moveTo(w/2+Math.cos(a)*r0,w/2+Math.sin(a)*r0); g.lineTo(w/2+Math.cos(a)*r1,w/2+Math.sin(a)*r1); g.lineWidth=4*(1-t)+1; g.stroke(); } },
  fire:(g,w,t,col)=>{ for(let i=0;i<9;i++){ const ph=(i/9+t)%1, x=w/2+Math.sin(i*2.3+t*6)*w*.14*(1-ph*.4), y=w*.85-ph*w*.7, r=w*.13*(1-ph*.8); const gr=g.createRadialGradient(x,y,0,x,y,r); gr.addColorStop(0,'#fff6c0'); gr.addColorStop(.4,col); gr.addColorStop(1,'rgba(255,60,0,0)'); g.globalAlpha=1-ph*.6; g.fillStyle=gr; g.fillRect(x-r,y-r,r*2,r*2); } },
  ice:(g,w,t,col)=>{ g.fillStyle=col; g.strokeStyle='#fff'; g.lineWidth=1.5; const k=Math.min(1,t*1.6), fade=t>.75?1-(t-.75)*4:1; g.globalAlpha=fade; for(let i=0;i<7;i++){ const a=i*.9+.3, L=w*.34*k*(.6+(i%3)*.2), bx=w/2+Math.cos(a)*w*.08, by=w/2+Math.sin(a)*w*.08; g.beginPath(); g.moveTo(bx+Math.cos(a+1.57)*5,by+Math.sin(a+1.57)*5); g.lineTo(bx+Math.cos(a)*L,by+Math.sin(a)*L); g.lineTo(bx+Math.cos(a-1.57)*5,by+Math.sin(a-1.57)*5); g.closePath(); g.fill(); g.stroke(); } },
  lightning:(g,w,t,col)=>{ g.strokeStyle=col; g.shadowColor=col; g.shadowBlur=12; g.lineJoin='round'; let s=Math.floor(t*100)+7; const rnd=()=>{ s=(s*9301+49297)%233280; return s/233280; }; g.globalAlpha=t>.8?(1-t)*5:1; for(let b=0;b<2;b++){ g.lineWidth=b?2:5; g.beginPath(); let x=w*.5+(b?6:0), y=4; g.moveTo(x,y); while(y<w-8){ y+=w*.1; x+=(rnd()-.5)*w*.22; g.lineTo(x,y); } g.stroke(); } },
  sparkle:(g,w,t,col)=>{ g.fillStyle=col; for(let i=0;i<8;i++){ const ph=(i/8+t)%1, x=w*.2+((i*37)%60)/60*w*.6, y=w*.85-ph*w*.7, r=(1-Math.abs(ph-.5)*2)*w*.07; g.globalAlpha=.9; g.beginPath(); g.moveTo(x,y-r*1.6); g.lineTo(x+r*.4,y-r*.4); g.lineTo(x+r*1.6,y); g.lineTo(x+r*.4,y+r*.4); g.lineTo(x,y+r*1.6); g.lineTo(x-r*.4,y+r*.4); g.lineTo(x-r*1.6,y); g.lineTo(x-r*.4,y-r*.4); g.closePath(); g.fill(); } },
  wave:(g,w,t,col)=>{ g.strokeStyle=col; for(let i=0;i<3;i++){ const k=Math.max(0,Math.min(1,t*1.4-i*.18)); g.globalAlpha=(1-k)*.9; g.lineWidth=7*(1-k)+1; g.beginPath(); g.ellipse(w/2,w/2+8,w*.08+k*w*.4,(w*.08+k*w*.4)*.5,0,0,6.3); g.stroke(); } },
  claw:(g,w,t,col)=>{ g.strokeStyle=col; g.lineCap='round'; const k=Math.min(1,t*1.5); g.globalAlpha=t>.7?(1-t)*3.3:1; for(let i=0;i<3;i++){ g.lineWidth=7-i; g.beginPath(); const ox=(i-1)*w*.16; g.moveTo(w*.3+ox,w*.2); g.lineTo(w*.3+ox+w*.3*k,w*.2+w*.6*k); g.stroke(); } }
};
R.ANIM_PRESETS = Object.keys(GEN);
function genSheet(type,col,frames,size){ const c=document.createElement('canvas'); c.width=size*frames; c.height=size; const g=c.getContext('2d'); for(let i=0;i<frames;i++){ g.save(); g.translate(i*size,0); g.beginPath(); g.rect(0,0,size,size); g.clip(); g.lineCap='round'; GEN[type](g,size,i/(frames-1||1),col); g.restore(); } return c; }

/* ---------- tab Animations ---------- */
DB.animations = function(o){ const f=E('div'); const prev=E('canvas',{width:200,height:200,style:{background:'#101624',border:'1px solid var(--line)',borderRadius:'6px'}});
  let raf=0, t0=performance.now(); const loop=()=>{ if(!prev.isConnected){ return; } const g=prev.getContext('2d'); g.clearRect(0,0,200,200); g.fillStyle='#1b2438'; g.fillRect(0,0,200,200); const t=(performance.now()-t0)/1000*60; const a=Object.assign({},o,{offX:0,offY:0}); const dur=Math.max(20,R.Anim.dur(o)); R.Anim.drawFrame(g,a,100,100,t%(dur+25),0); raf=requestAnimationFrame(loop); }; setTimeout(loop,50);
  const gen={type:'slash',color:'#9fd4ff',frames:8,size:96};
  const genBox=E('fieldset',null,E('legend',{text:'Generate sprite sheet (no art needed)'}),E('div',{class:'row'},F.sel(gen,'type',R.ANIM_PRESETS,{w:110}),F.color(gen,'color'),'Frames ',F.num(gen,'frames',{min:3,max:16,w:50}),' Size ',F.num(gen,'size',{min:32,max:192,w:60}),E('button',{class:'btn',text:'Generate & use',onclick:()=>{ const c=genSheet(gen.type,gen.color,gen.frames,gen.size); const key='img/anims/'+gen.type+'_'+Date.now().toString(36)+'.png'; db().assets=db().assets||{}; db().assets[key]=c.toDataURL('image/png'); o.file=key; o.cols=gen.frames; o.rows=1; o.frames=0; o.fps=Math.round(gen.frames*2.2); o.blend=['burst','fire','lightning','sparkle','wave'].includes(gen.type)?'lighter':'normal'; if(!o.name||/^New Animation/.test(o.name)) o.name=gen.type[0].toUpperCase()+gen.type.slice(1)+' FX'; touch(); App.refreshAssets().then(()=>{ const par=f.parentElement; if(par){ const nf=DB.animations(o); par.replaceChild(nf,f); } }); }}),E('div',{class:'hint',text:'Or import your own sheet below (frames laid out in a grid, left→right then top→bottom).'})));
  f.append(E('div',{class:'row'},E('label',{text:'Name'}),F.text(o,'name',{w:200})),E('div',{style:{display:'flex',gap:'16px',alignItems:'flex-start',margin:'8px 0'}},prev,E('div',{style:{flex:1}},
    F.row('Sheet image',F.asset(o,'file',['anims','pictures'],{change:()=>{ t0=performance.now(); }})),F.row('Columns × Rows',E('span',null,F.num(o,'cols',{min:1,max:64,w:55}),' × ',F.num(o,'rows',{min:1,max:64,w:55}))),F.row('Frames (0 = all)',F.num(o,'frames',{min:0,max:999,w:70})),F.row('Speed (fps)',F.num(o,'fps',{min:1,max:60,w:70})),F.row('Scale %',F.num(o,'scale',{min:10,max:600,w:70})),F.row('Offset X / Y',E('span',null,F.num(o,'offX',{min:-300,max:300,w:60}),' ',F.num(o,'offY',{min:-300,max:300,w:60}))),F.row('Blend',F.sel(o,'blend',[{v:'normal',t:'Normal'},{v:'lighter',t:'Additive (glow)'}],{w:130})),F.row('',F.chk(o,'rotate','Rotate toward attack direction (sheet drawn facing right)')),F.row('',F.chk(o,'flip','Mirror horizontally')),F.row('Sound',F.se(o,'sound')))),genBox,
    E('div',{class:'hint',text:'Use this animation in: Weapons (swing / hit animation), Skills (cast / hit / projectile), Enemies (attack animation).'}));
  return f; };
const animRef=(o,k)=>F.ref(o,k,db().animations||[],{none:true,noneLabel:'(default effect)',w:200});
function fxRow(label,ctl,hint){ return F.row(label,ctl,hint?E('span',{class:'hint',text:'  '+hint}):null); }

/* ---------- tambahan form: senjata / skill / item / musuh ---------- */
const wrapForm=(name,fn)=>{ const orig=DB[name]; DB[name]=function(o){ const f=orig.apply(this,arguments); try{ f.append(fn(o)); }catch(e){ console.error(e); } return f; }; };
wrapForm('weapons',o=>E('fieldset',null,E('legend',{text:'Custom sprite & effects'}),
  fxRow('Swing sprite',E('span',null,F.asset(o,'sprite',['icons'])),'image drawn in the swing (default: the icon)'),
  fxRow('Swing animation',animRef(o,'animId'),'plays in front of the player'),
  fxRow('Hit animation',animRef(o,'hitAnim'),'plays on the enemy that is hit'),
  F.row('',F.chk(o,'hideArc','Hide the default white slash arc (when using a custom animation)'))));
wrapForm('skills',o=>E('fieldset',null,E('legend',{text:'Custom animation (action combat)'}),
  fxRow('Cast animation',animRef(o,'castAnim'),'on the caster'),fxRow('Hit animation',animRef(o,'animId'),'on the target'),fxRow('Projectile',animRef(o,'projAnim'),'sprite that flies toward enemies')));
wrapForm('items',o=>E('fieldset',null,E('legend',{text:'Custom animation'}),fxRow('Use animation',animRef(o,'animId'))));
wrapForm('enemies',o=>{ o.sheet=o.sheet||{file:'',cols:4,rows:3,fps:8,idleRow:0,walkRow:1,attackRow:2,hurtRow:-1,dieRow:-1,flipLeft:false}; const s=o.sheet; const prev=E('canvas',{width:96,height:96,style:{background:'#101624',borderRadius:'6px',border:'1px solid var(--line)'}}); let st='idle', tt=0; const states=['idle','walk','attack','hurt','die'];
  const loop=()=>{ if(!prev.isConnected) return; const g=prev.getContext('2d'); g.clearRect(0,0,96,96); g.fillStyle='#1b2438'; g.fillRect(0,0,96,96); const fr=s.file&&R.Anim.mobFrame(o,st,tt++,6); if(fr){ const k=Math.min(88/fr.width,88/fr.height); g.imageSmoothingEnabled=false; g.drawImage(fr,(96-fr.width*k)/2,(96-fr.height*k)/2,fr.width*k,fr.height*k); } requestAnimationFrame(loop); }; setTimeout(loop,60);
  return E('fieldset',null,E('legend',{text:'Animated sprite sheet (overrides the generated look)'}),
    E('div',{style:{display:'flex',gap:'14px'}},prev,E('div',{style:{flex:1}},F.row('Sheet',F.asset(s,'file',['battlers','anims'],{change:()=>{ if(s.file) o.kind=o.kind; tt=0; }})),F.row('Columns × Rows',E('span',null,F.num(s,'cols',{min:1,max:32,w:55}),' × ',F.num(s,'rows',{min:1,max:32,w:55}),'  fps ',F.num(s,'fps',{min:1,max:30,w:50}))),
      F.row('Row: idle / walk',E('span',null,F.num(s,'idleRow',{min:0,max:31,w:50}),' ',F.num(s,'walkRow',{min:-1,max:31,w:50}))),F.row('Row: attack / hurt / die',E('span',null,F.num(s,'attackRow',{min:-1,max:31,w:50}),' ',F.num(s,'hurtRow',{min:-1,max:31,w:50}),' ',F.num(s,'dieRow',{min:-1,max:31,w:50}),E('span',{class:'hint',text:'  (-1 = use idle)'}))),
      F.row('',F.chk(s,'flipLeft','Mirror when facing left (sheet faces right)')),F.row('Preview',E('span',null,...states.map(x=>E('button',{class:'btn sm',text:x,onclick:()=>{ st=x; tt=0; }})))))),
    E('div',{style:{marginTop:'6px'}},fxRow('Size %',F.num(o,'scale',{min:30,max:400,w:70}),'(0/100 = normal)'),fxRow('Attack animation',animRef(o,'attackAnim'),'plays on the player when hit'),
      E('div',{class:'hint',text:'Each row of the sheet is one state; each column is a frame. Leave Sheet empty to keep the generated monster (which now bobs, squashes and hops).'}))); });

/* ---------- Sound Effects: ganti SE bawaan dengan audio sendiri ---------- */
DB.sounds = function(){ const f=E('div'); const s=db().system; s.seMap=s.seMap||{}; f.append(E('div',{class:'hint',style:{marginBottom:'8px'},text:'Replace any built-in sound effect with your own audio (Import audio…). Applies everywhere: combat, menus, doors, events. Leave “(default)” to keep the generated sound.'}));
  const bar=E('div',{class:'row'},E('button',{class:'btn',text:'⇪ Import audio…',onclick:()=>Misc.importAssets('audio',()=>{ const nf=DB.sounds(); f.parentElement.replaceChild(nf,f); })}),E('button',{class:'btn',text:'Reset all',onclick:()=>{ s.seMap={}; touch(); const nf=DB.sounds(); f.parentElement.replaceChild(nf,f); }})); f.append(bar);
  const main=['Step','Magic','Hit','Crit','Door','Chest','Buzzer','Cursor','OK','Cancel','Level Up','Victory','Encounter','Heal']; const names=main.concat(R.SE_LIST.filter(n=>!main.includes(n)));
  const aud=(App.assets&&App.assets.audio||[]).map(n=>({v:'audio/'+n,t:'♪ '+n})); const tbl=E('div',{style:{maxHeight:'420px',overflow:'auto',marginTop:'6px'}});
  names.forEach(n=>{ const px={v:s.seMap[n]||''}; const opts=[{v:'',t:'(default)'}].concat(aud).concat(R.SE_LIST.filter(x=>x!==n).map(x=>({v:x,t:x}))); tbl.append(E('div',{class:'row',style:{margin:'2px 0'}},E('span',{style:{minWidth:'110px',fontWeight:main.includes(n)?'600':'400'},text:n}),E('button',{class:'btn sm',text:'▶',onclick:()=>{ R.Audio.init(); R.Audio.se(n); }}),F.sel(px,'v',opts,{w:220,change:v=>{ if(v) s.seMap[n]=v; else delete s.seMap[n]; touch(); }}))); });
  f.append(tbl); return f; };

/* ---------- UI & Controls ---------- */
DB.uiTab = function(){ const s=db().system; const ui=(s.ui=s.ui||{}); const f=E('div'); const apply=()=>{ R.applyUI(); touch(); };
  const fonts=['','Georgia','Times New Roman','Courier New','Verdana','Trebuchet MS','Comic Sans MS','Impact','Palatino Linotype','Arial Black','monospace','serif','sans-serif','cursive','fantasy'].map(x=>({v:x,t:x||'(default)'}));
  const C=(k,def)=>{ if(ui[k]===undefined) ui[k]=def; return ui[k]; }; Object.keys(R.UIDEF).forEach(k=>{ if(k!=='layout'&&k!=='touch'&&ui[k]===undefined) ui[k]=R.UIDEF[k]; });
  const cc=(k)=>{ const c=F.color(ui,k); c.addEventListener('input',apply); return c; };
  const nn=(k,o)=>F.num(ui,k,Object.assign({change:apply},o));
  f.append(E('div',{class:'row'},E('button',{class:'btn pri',text:'🖼 Open UI Designer (drag windows & buttons)',onclick:()=>Misc.uiDesigner()}),E('span',{class:'hint',text:'  Move the message window, HP box, boss bar, map name and touch buttons visually.'})),
    E('fieldset',null,E('legend',{text:'Look & feel'}),
      F.row('Font',E('span',null,F.sel(ui,'font',fonts,{w:170,change:apply}),E('span',{class:'hint',text:'  or custom font file:'}),F.asset(ui,'fontFile',['fonts'],{change:apply}))),F.row('Text size',nn('fontSize',{min:14,max:40,w:60})),F.row('Text color',cc('textColor')),
      F.row('Window color',cc('skinColor')),F.row('Border colors',E('span',null,cc('borderColor'),' ',cc('borderColor2'))),F.row('Window opacity %',E('span',null,F.num(ui,'alphaPct',{min:10,max:100,w:60,change:v=>{ ui.alpha=v/100; apply(); }}))),F.row('Corner radius',nn('radius',{min:0,max:30,w:60})),F.row('Cursor color',cc('cursorColor')),
      F.row('Window skin image',E('span',null,F.asset(ui,'skinImage',['ui'],{change:apply}),E('span',{class:'hint',text:'  9-slice: corner size '}),nn('skinSlice',{min:4,max:64,w:55}))),F.row('Touch button size',F.num(ui,'touchScale',{min:.5,max:2,step:.1,float:true,w:60,change:apply}))),
    E('fieldset',null,E('legend',{text:'Default keybinds (desktop)'}),E('div',{class:'hint',text:'Click a key box, then press the key you want. Players can also rebind in the game: Options → Controls (saved on their device).'}),keyTable(s)));
  ui.alphaPct=Math.round((ui.alpha===undefined?.93:ui.alpha)*100); return f; };
function keyTable(s){ s.keys=s.keys||JSON.parse(JSON.stringify(R.Input.DEFAULT_MAP)); const box=E('div'); const acts=R.Keys.ACTIONS; const render=()=>{ box.innerHTML=''; acts.forEach(([a,n])=>{ const row=E('div',{class:'row',style:{margin:'2px 0'}},E('span',{style:{minWidth:'140px'},text:n})); (s.keys[a]||[]).forEach((k,i)=>{ row.append(E('button',{class:'btn sm',text:R.Keys.keyName(k)+' ✕',title:'Remove',onclick:()=>{ s.keys[a].splice(i,1); if(!s.keys[a].length) s.keys[a]=[R.Input.DEFAULT_MAP[a][0]]; touch(); render(); }})); });
      row.append(E('button',{class:'btn sm',text:'＋ key…',onclick:(ev)=>{ const b=ev.target; b.textContent='press a key…'; const h=e=>{ e.preventDefault(); e.stopPropagation(); window.removeEventListener('keydown',h,true); if(e.key!=='Escape'&&!(s.keys[a]||[]).includes(e.key)){ (s.keys[a]=s.keys[a]||[]).push(e.key); touch(); } render(); }; window.addEventListener('keydown',h,true); }})); box.append(row); });
    box.append(E('button',{class:'btn',text:'Reset to defaults',onclick:()=>{ s.keys=JSON.parse(JSON.stringify(R.Input.DEFAULT_MAP)); touch(); render(); }})); }; render(); return box; }

/* ---------- UI Designer visual ---------- */
Misc.uiDesigner = function(){ const s=db().system; const ui=(s.ui=s.ui||{}); ui.layout=ui.layout||{}; const K=.88, W=816, H=624; const cv=E('canvas',{width:W,height:H,style:{width:Math.round(W*K)+'px',height:Math.round(H*K)+'px',background:'#10141f',borderRadius:'6px',cursor:'default',touchAction:'none'}});
  const LD=()=>R.uiCfg().layout; const TOUCH_DEF={pad:{x:.12,y:.82},ok:{x:.92,y:.80},cancel:{x:.84,y:.90},shift:{x:.92,y:.64},attack:{x:.80,y:.72},skill:{x:.68,y:.84}};
  const touchPos=()=>Object.assign({},TOUCH_DEF,ui.touch||{});
  const rects=()=>{ const L=LD(); const msg=L.msg; const my=msg.y>=0?msg.y:H-msg.h-8; const list=[{k:'msg',n:'Message window',x:msg.x,y:my,w:msg.w,h:msg.h},{k:'hud',n:'HP / MP box',x:L.hud.x,y:L.hud.y,w:236,h:76},{k:'boss',n:'Boss bar',x:(W-436)/2+L.boss.x,y:14+L.boss.y,w:436,h:36},{k:'mapName',n:'Map name',x:(W-380)/2+L.mapName.x,y:16+L.mapName.y,w:380,h:52}];
    const tp=touchPos(), sc=ui.touchScale||1; for(const k of Object.keys(TOUCH_DEF)){ const r=k==='pad'?75:(k==='attack'?40:34); list.push({k:'t:'+k,n:'Touch: '+k,x:tp[k].x*W-r*sc,y:tp[k].y*H-r*sc,w:r*2*sc,h:r*2*sc,round:true,label:k}); } return list; };
  let sel='msg', drag=null; const info=E('div',{class:'hint',style:{margin:'6px 0'}});
  const draw=()=>{ const g=cv.getContext('2d'); g.clearRect(0,0,W,H); const gr=g.createLinearGradient(0,0,0,H); gr.addColorStop(0,'#3d6a4a'); gr.addColorStop(1,'#2a4a38'); g.fillStyle=gr; g.fillRect(0,0,W,H); g.strokeStyle='rgba(255,255,255,.06)'; for(let x=0;x<W;x+=48){ g.beginPath(); g.moveTo(x,0); g.lineTo(x,H); g.stroke(); } for(let y=0;y<H;y+=48){ g.beginPath(); g.moveTo(0,y); g.lineTo(W,y); g.stroke(); }
    const L=LD(); const rs=rects(); const R_=k=>rs.find(r=>r.k===k);
    { const m=R_('msg'); R.UI.win(g,m.x,m.y,m.w,m.h); R.UI.text(g,'Message window — Hello, adventurer!',m.x+24,m.y+40,{size:R.UI.fs}); R.UI.text(g,'Second line of dialog text.',m.x+24,m.y+76,{size:R.UI.fs}); }
    { const h=R_('hud'); g.fillStyle='rgba(8,12,30,.72)'; g.fillRect(h.x,h.y,h.w,h.h); R.UI.text(g,'Hero  Lv1',h.x+46,h.y+16,{size:17}); g.fillStyle='#d94a4a'; g.fillRect(h.x+46,h.y+30,150,11); g.fillStyle='#3f7fe0'; g.fillRect(h.x+46,h.y+44,120,11); }
    { const b=R_('boss'); g.fillStyle='rgba(8,12,30,.78)'; g.fillRect(b.x,b.y,b.w,b.h); R.UI.text(g,'Boss name',b.x+b.w/2,b.y+10,{size:15,align:'center'}); g.fillStyle='#d94a4a'; g.fillRect(b.x+8,b.y+20,b.w-16,10); }
    { const m=R_('mapName'); R.UI.win(g,m.x,m.y,m.w,m.h); R.UI.text(g,'Map Name',m.x+m.w/2,m.y+m.h/2,{size:24,align:'center'}); }
    for(const r of rs.filter(r=>r.round)){ g.fillStyle='rgba(255,255,255,.16)'; g.strokeStyle='rgba(255,255,255,.5)'; g.lineWidth=2; g.beginPath(); g.arc(r.x+r.w/2,r.y+r.h/2,r.w/2,0,6.3); g.fill(); g.stroke(); R.UI.text(g,r.label.toUpperCase(),r.x+r.w/2,r.y+r.h/2,{size:13,align:'center'}); }
    const cur=rs.find(r=>r.k===sel); if(cur){ g.strokeStyle='#4f8cff'; g.lineWidth=3; g.setLineDash([6,4]); if(cur.round){ g.beginPath(); g.arc(cur.x+cur.w/2,cur.y+cur.h/2,cur.w/2+4,0,6.3); g.stroke(); } else g.strokeRect(cur.x-3,cur.y-3,cur.w+6,cur.h+6); g.setLineDash([]); }
    info.textContent='Selected: '+(cur?cur.n:'-')+'  ·  drag elements to move them. Message window size: use the fields on the right.'; };
  const pos=e=>{ const r=cv.getBoundingClientRect(); return {x:(e.clientX-r.left)/K,y:(e.clientY-r.top)/K}; };
  const setPos=(k,x,y,r)=>{ const L=ui.layout; if(k==='msg'){ L.msg=Object.assign({},LD().msg,{x:Math.round(x),y:Math.round(y)}); } else if(k==='hud'){ L.hud={x:Math.round(x),y:Math.round(y)}; } else if(k==='boss'){ L.boss={x:Math.round(x-(W-436)/2),y:Math.round(y-14)}; } else if(k==='mapName'){ L.mapName={x:Math.round(x-(W-380)/2),y:Math.round(y-16)}; } else if(k.startsWith('t:')){ ui.touch=Object.assign({},touchPos()); ui.touch[k.slice(2)]={x:+((x+r.w/2)/W).toFixed(3),y:+((y+r.h/2)/H).toFixed(3)}; } };
  cv.addEventListener('pointerdown',e=>{ const p=pos(e); const rs=rects().reverse(); const hit=rs.find(r=>r.round?Math.hypot(p.x-(r.x+r.w/2),p.y-(r.y+r.h/2))<=r.w/2:(p.x>=r.x&&p.x<=r.x+r.w&&p.y>=r.y&&p.y<=r.y+r.h)); if(hit){ sel=hit.k; drag={dx:p.x-hit.x,dy:p.y-hit.y,r:hit}; try{ cv.setPointerCapture(e.pointerId); }catch(x){} renderSide(); } draw(); });
  cv.addEventListener('pointermove',e=>{ if(!drag) return; const p=pos(e); setPos(drag.r.k,Math.max(-200,Math.min(W-20,p.x-drag.dx)),Math.max(-50,Math.min(H-20,p.y-drag.dy)),drag.r); draw(); touch(); });
  cv.addEventListener('pointerup',()=>{ if(drag){ drag=null; R.applyUI(); touch(); } });
  const side=E('div',{style:{width:'300px',marginLeft:'14px',overflow:'auto',maxHeight:'560px'}});
  function renderSide(){ side.innerHTML=''; const L=LD(); const msg={w:L.msg.w,h:L.msg.h}; const px={w:msg.w,h:msg.h};
    side.append(E('div',{class:'row'},E('b',{text:'Message window size'})),F.row('Width',F.num(px,'w',{min:200,max:816,w:70,change:v=>{ ui.layout.msg=Object.assign({},LD().msg,{w:v}); R.applyUI(); draw(); touch(); }})),F.row('Height',F.num(px,'h',{min:80,max:400,w:70,change:v=>{ ui.layout.msg=Object.assign({},LD().msg,{h:v}); R.applyUI(); draw(); touch(); }})),
      F.row('',E('button',{class:'btn sm',text:'Message: back to auto bottom',onclick:()=>{ ui.layout.msg=Object.assign({},R.UIDEF.layout.msg); R.applyUI(); draw(); renderSide(); touch(); }})),
      E('hr'),E('div',{class:'row'},E('b',{text:'Theme (live)'})));
    const ap=()=>{ R.applyUI(); draw(); touch(); }; const fonts=['','Georgia','Times New Roman','Courier New','Verdana','Trebuchet MS','Comic Sans MS','Impact','monospace','serif','cursive'].map(x=>({v:x,t:x||'(default)'}));
    const col=k=>{ const c=F.color(ui,k); c.addEventListener('input',ap); return c; };
    if(ui.skinColor===undefined) Object.keys(R.UIDEF).forEach(k=>{ if(k!=='layout'&&k!=='touch'&&ui[k]===undefined) ui[k]=R.UIDEF[k]; });
    side.append(F.row('Font',F.sel(ui,'font',fonts,{w:130,change:ap})),F.row('Font file',F.asset(ui,'fontFile',['fonts'],{change:ap})),F.row('Text size',F.num(ui,'fontSize',{min:14,max:40,w:60,change:ap})),F.row('Text color',col('textColor')),F.row('Window color',col('skinColor')),F.row('Borders',E('span',null,col('borderColor'),' ',col('borderColor2'))),F.row('Corner radius',F.num(ui,'radius',{min:0,max:30,w:60,change:ap})),
      F.row('Skin image',F.asset(ui,'skinImage',['ui'],{change:ap})),F.row('Touch size',F.num(ui,'touchScale',{min:.5,max:2,step:.1,float:true,w:60,change:ap})),
      F.row('',E('button',{class:'btn danger sm',text:'Reset ALL layout',onclick:()=>{ ui.layout={}; ui.touch=null; R.applyUI(); renderSide(); draw(); touch(); }}))); }
  renderSide(); draw(); const wrap=E('div',{style:{display:'flex'}},E('div',null,cv,info),side);
  UIx.dialog({title:'UI Designer',width:1220,body:wrap,focus:false,buttons:[{text:'Close',primary:true}],onClose:()=>{ R.applyUI(); touch(); }}); };
})();
