/* Dialog tambahan: properti peta, resource manager, about */
(function(){
'use strict';
const R = window.RPG, F = UIx.F;
const Misc = window.Misc = {};

Misc.mapProps = function(map,done){
  const db=App.db; const f=E('div'); const size={w:map.w,h:map.h};
  const enc=E('div'); const rEnc=()=>{ enc.innerHTML=''; map.encounters.forEach((e,i)=>{ enc.append(E('div',{class:'row'},F.ref(e,'troop',db.troops,{none:false,w:220}),E('span',{text:'Weight'}),F.num(e,'weight',{min:1,max:99,w:55}),E('button',{class:'btn sm danger',text:'✕',onclick:()=>{ map.encounters.splice(i,1); rEnc(); }}))); }); enc.append(E('button',{class:'btn sm',text:'＋ Add troop',onclick:()=>{ map.encounters.push({troop:1,weight:5}); rEnc(); }})); }; rEnc();
  f.append(F.row('Name',F.text(map,'name',{w:240})),F.row('Size',E('span',null,F.num(size,'w',{min:1,max:256,w:70}),' × ',F.num(size,'h',{min:1,max:256,w:70}),E('span',{class:'hint',text:'  tiles (shrinking cuts off the edges)'}))),F.row('Music',F.bgm(map,'bgm')),F.row('Battle back',F.sel(map,'battleBg',R.BATTLE_BGS,{w:130})),F.row('',F.chk(map,'disableDash','Disable dashing')),F.row('Encounter steps',E('span',null,F.num(map,'encounterStep',{min:1,max:999,w:70}),' steps on average')),E('fieldset',null,E('legend',{text:'Random Encounters'}),enc),Misc.lightBox(map),F.row('Note',F.area(map,'note',3)));
  UIx.dialog({title:'Map Properties — '+UIx.fmt3(map.id),width:520,body:f,buttons:[{text:'Cancel'},{text:'OK',primary:true,fn:()=>{ if(size.w!==map.w||size.h!==map.h) MapView.resizeMap(map,size.w,size.h); App.touch(); done&&done(); }}]});
};

Misc.assetKey = function(kind,name){ if(kind==='pictures') name=name.replace(/\.[^.]+$/,'')+'.png'; return App.assetPrefix(kind)+name; };
Misc.importAssets = function(kind,done){
  const inp=document.createElement('input'); inp.type='file'; inp.multiple=true; inp.accept=kind==='audio'?'audio/*,.ogg,.mp3,.wav,.m4a':kind==='videos'?'video/*,.mp4,.webm':kind==='fonts'?'.ttf,.otf,.woff,.woff2':'image/*';
  inp.onchange=async()=>{ const db=App.db; db.assets=db.assets||{}; let n=0, last=''; const keys=[];
    for(const f of Array.from(inp.files)){ const lim=(kind==='videos'?30:kind==='fonts'?6:8)*1024*1024; if(f.size>lim){ UIx.alert(f.name+' > '+(lim>>20)+' MB, skipped.'); continue; }
      const url=await new Promise(res=>{ const r=new FileReader(); r.onload=()=>res(r.result); r.onerror=()=>res(null); r.readAsDataURL(f); }); if(!url) continue;
      last=Misc.assetKey(kind,f.name.replace(/[^\w.\- ]/g,'_')); db.assets[last]=url; keys.push(last); n++; }
    if(n){ App.touch(); await App.refreshAssets(); if(R.clearTileCache) R.clearTileCache(); UIx.toast(n+' file(s) imported'); } done&&done(last,keys); };
  inp.click(); };
Misc.resources = function(){
  const kinds=[['characters','Characters','3×4 sprite sheet PNG (Down, Left, Right, Up)'],['pictures','Pictures','Any image, used by Show Picture'],['battlers','Battlers','Enemy images'],['faces','Portraits','Dialog portraits (any size; use Show Text → Face)'],['icons','Icons / Sprites','Item, weapon & skill icons or swing sprites (square PNG)'],['anims','Animation Sheets','Attack / effect sprite sheets (frames in a grid)'],['ui','UI Skins','Window skin images (9-slice) & misc UI'],['videos','Videos','mp4 / webm for cutscenes (max 30 MB)'],['fonts','Fonts','ttf / otf / woff'],['audio','Audio','ogg / mp3 / wav / m4a (BGM, SE)']]; let kind='characters';
  const body=E('div',{style:{width:'620px',minHeight:'320px'}}); const tabs=E('div',{class:'tabs'}); const list=E('div',{class:'list',style:{height:'240px'}}); const hint=E('div',{class:'hint',style:{margin:'6px 0'}});
  const render=()=>{ tabs.innerHTML=''; kinds.forEach(([k,n])=>tabs.append(E('div',{class:'tab'+(k===kind?' on':''),text:n,onclick:()=>{ kind=k; render(); }}))); hint.textContent=kinds.find(x=>x[0]===kind)[2]+' — stored inside the project (no desktop app needed).'; list.innerHTML=''; const items=(App.assets&&App.assets[kind])||[]; if(!items.length) list.append(E('div',{class:'hint',style:{padding:'10px'},text:'(empty)'})); items.forEach(n=>{ const key=Misc.assetKey(kind,n); const row=E('div',{class:'li'}); if(!['audio','videos','fonts'].includes(kind)&&App.db.assets&&App.db.assets[key]){ const im=E('img',{src:App.db.assets[key],style:{height:'28px',maxWidth:'40px',objectFit:'contain',marginRight:'6px',imageRendering:'pixelated'}}); row.append(im); } row.append(E('span',{text:n,style:{flex:1}}),E('button',{class:'btn sm danger',text:'Delete',onclick:async()=>{ if(App.db.assets&&App.db.assets[key]){ delete App.db.assets[key]; App.touch(); } else if(window.api&&App.dir){ await window.api.deleteAsset(App.dir,kind,n); } await App.refreshAssets(); render(); }})); list.append(row); }); };
  body.append(tabs,hint,E('div',{class:'row',style:{margin:'4px 0 8px'}},E('button',{class:'btn primary',text:'⇪ Import files…',onclick:()=>Misc.importAssets(kind,render)})),list);
  UIx.dialog({title:'Resource Manager',width:600,body:body,buttons:[{text:'Close',primary:true}]}); render(); };



/* ---------- impor gambar sebagai data URL (tanpa folder, jalan di browser maupun desktop) ---------- */
Misc.pickImageFile = function(cb){ const inp=E('input',{type:'file',accept:'image/png,image/jpeg,image/gif,image/webp'}); inp.onchange=()=>{ const f=inp.files[0]; if(!f) return; if(f.size>6*1024*1024){ UIx.alert('Image is larger than 6 MB. Please use a smaller file.'); return; } const rd=new FileReader(); rd.onload=()=>{ const im=new Image(); im.onload=()=>cb(rd.result,im,f.name.replace(/\.[^.]+$/,'')); im.src=rd.result; }; rd.readAsDataURL(f); }; inp.click(); };
Misc.afterTileChange = function(){ R.registerCustomTiles(App.db); const keep=Palette.tab; if(!R.TILE_TABS.some(t=>t[0]===keep)) Palette.tab='A'; Palette.init(); if(window.MapView) MapView.draw(); App.touch(); };

Misc.tilesets = function(){
  const db=App.db; db.tilesets=db.tilesets||[]; db.customTiles=db.customTiles||[];
  let si=db.tilesets.length?0:-1, sel=null; const ZOOM=1;
  const body=E('div',{style:{display:'flex',gap:'14px',width:'900px',height:'560px'}}); const left=E('div',{style:{flex:1,minWidth:0,display:'flex',flexDirection:'column'}}); const right=E('div',{style:{width:'260px',overflow:'auto'}});
  const top=E('div',{class:'row'}); const scroll=E('div',{style:{flex:1,overflow:'auto',background:'#10131c',marginTop:'8px',border:'1px solid var(--line)'}}); const cv=E('canvas'); scroll.append(cv); left.append(top,scroll,E('div',{class:'hint',style:{marginTop:'6px'},text:'Click a cell to add it as a tile or edit its properties. Imported tiles appear in palette tab "F".'}));
  const tileAt=(x,y)=>db.customTiles.findIndex(t=>t.set===si&&t.x===x&&t.y===y&&!t.removed);
  const cellEmpty=(im,x,y,sz)=>{ const c=document.createElement('canvas'); c.width=sz; c.height=sz; const g=c.getContext('2d'); g.drawImage(im,x*sz,y*sz,sz,sz,0,0,sz,sz); const d=g.getImageData(0,0,sz,sz).data; for(let i=3;i<d.length;i+=4) if(d[i]>8) return false; return true; };
  const drawSheet=()=>{ const set=db.tilesets[si]; if(!set){ cv.width=10; cv.height=10; return; } const im=R.loadImage(set.data); const sz=set.size; if(!im){ setTimeout(drawSheet,100); return; } cv.width=im.width*ZOOM; cv.height=im.height*ZOOM; const g=cv.getContext('2d'); g.imageSmoothingEnabled=false; for(let y=0;y<cv.height;y+=16) for(let x=0;x<cv.width;x+=16){ g.fillStyle=((x+y)/16)%2?'#232838':'#1b1f2c'; g.fillRect(x,y,16,16); } g.drawImage(im,0,0,cv.width,cv.height); const cs=sz*ZOOM; g.lineWidth=1; g.strokeStyle='rgba(255,255,255,.12)'; for(let x=0;x<=cv.width;x+=cs){ g.beginPath(); g.moveTo(x+.5,0); g.lineTo(x+.5,cv.height); g.stroke(); } for(let y=0;y<=cv.height;y+=cs){ g.beginPath(); g.moveTo(0,y+.5); g.lineTo(cv.width,y+.5); g.stroke(); } db.customTiles.forEach(t=>{ if(t.set!==si||t.removed) return; g.strokeStyle='#4cc38a'; g.lineWidth=2; g.strokeRect(t.x*cs+1,t.y*cs+1,cs-2,cs-2); if(!t.pass){ g.fillStyle='rgba(255,60,60,.9)'; g.fillRect(t.x*cs+2,t.y*cs+2,6,6); } }); if(sel){ g.strokeStyle='#4f8cff'; g.lineWidth=3; g.strokeRect(sel.x*cs+1.5,sel.y*cs+1.5,cs-3,cs-3); } };
  cv.onmousedown=e=>{ const set=db.tilesets[si]; if(!set) return; const r=cv.getBoundingClientRect(); const x=Math.floor((e.clientX-r.left)/(set.size*ZOOM)), y=Math.floor((e.clientY-r.top)/(set.size*ZOOM)); sel={x:x,y:y}; renderRight(); drawSheet(); };
  const renderTop=()=>{ top.innerHTML=''; const opts=db.tilesets.map((t,i)=>({v:i,t:(i+1)+': '+t.name+' ('+t.size+'px)'})); const holder={v:si}; if(opts.length) top.append(UIx.F.sel(holder,'v',opts,{w:240,change:v=>{ si=v; sel=null; renderRight(); drawSheet(); }})); top.append(E('button',{class:'btn',text:'Import tileset…',onclick:()=>{ const size={v:48}; UIx.dialog({title:'Tile size in the image',width:360,body:E('div',null,E('div',{class:'hint',text:'Pixel size of one tile cell in your image. It is scaled to 48×48 in the game.',style:{marginBottom:'8px'}}),UIx.F.sel(size,'v',[16,24,32,48,64,96].map(n=>({v:n,t:n+' × '+n})),{w:120})),buttons:[{text:'Cancel'},{text:'Choose file…',primary:true,fn:()=>Misc.pickImageFile((data,im,name)=>{ db.tilesets.push({name:name,data:data,size:+size.v,w:im.width,h:im.height}); si=db.tilesets.length-1; sel=null; renderTop(); renderRight(); R.loadImage(data); setTimeout(drawSheet,50); App.touch(); })}]}); }}),E('button',{class:'btn',text:'Add all non-empty cells',onclick:()=>{ const set=db.tilesets[si]; if(!set) return; const im=R.loadImage(set.data); if(!im) return; let n=0; for(let y=0;y<Math.floor(im.height/set.size);y++) for(let x=0;x<Math.floor(im.width/set.size);x++){ if(tileAt(x,y)<0&&!cellEmpty(im,x,y,set.size)){ db.customTiles.push({name:'',set:si,x:x,y:y,layer:0,pass:true}); n++; } } Misc.afterTileChange(); drawSheet(); UIx.toast(n+' tiles added'); }})); };
  const renderRight=()=>{ right.innerHTML=''; const set=db.tilesets[si]; if(!set){ right.append(E('div',{class:'hint',text:'Import a PNG/JPG tileset to begin.'})); return; } if(!sel){ right.append(E('div',{class:'hint',text:'Select a cell.'}),E('button',{class:'btn sm danger',text:'Delete this tileset',onclick:()=>UIx.confirm('Remove all tiles from this tileset? Placed tiles will turn blank.',()=>{ db.customTiles.forEach(t=>{ if(t.set===si) t.removed=true; }); set.data='data:,'; Misc.afterTileChange(); renderRight(); drawSheet(); })})); return; } const i=tileAt(sel.x,sel.y); const pv=E('canvas',{width:96,height:96,class:'thumb',style:{width:'96px',height:'96px',cursor:'default'}}); const im=R.loadImage(set.data); if(im){ const g=pv.getContext('2d'); g.imageSmoothingEnabled=false; g.drawImage(im,sel.x*set.size,sel.y*set.size,set.size,set.size,0,0,96,96); } right.append(E('div',{class:'mut',text:'Cell ('+sel.x+','+sel.y+')'}),pv);
    if(i<0){ right.append(E('button',{class:'btn',text:'＋ Add as tile',onclick:()=>{ db.customTiles.push({name:'',set:si,x:sel.x,y:sel.y,layer:0,pass:true}); Misc.afterTileChange(); renderRight(); drawSheet(); }})); return; }
    const t=db.customTiles[i]; const F=UIx.F; const chg={change:()=>{ Misc.afterTileChange(); drawSheet(); }};
    const sh={get castShadow(){ return t.castShadow===undefined?true:t.castShadow; },set castShadow(v){ t.castShadow=v; }}; right.append(F.row('Name',F.text(t,'name',{w:140,change:()=>Misc.afterTileChange()})),F.row('Layer',F.sel(t,'layer',[{v:0,t:'1: Ground'},{v:1,t:'2: Walls / roofs'},{v:2,t:'3: Objects'},{v:3,t:'4: Overhead'}],Object.assign({w:140},chg))),F.row('',F.chk(t,'pass','Passable',chg)),F.row('',F.chk(sh,'castShadow','☀ Casts a shadow (when placed on map layer 2 or 3)',chg)),F.row('',F.chk(t,'star','★ Star (drawn above player, no collision)',chg)),F.row('',F.chk(t,'bush','Bush (half-hides characters)',chg)),F.row('',F.chk(t,'counter','Counter (talk over it)',chg)),F.row('',F.chk(t,'damage','Damage floor',chg)),E('button',{class:'btn sm danger',text:'Remove tile',onclick:()=>{ t.removed=true; Misc.afterTileChange(); renderRight(); drawSheet(); }})); };
  body.append(left,right); renderTop(); renderRight(); drawSheet();
  UIx.dialog({title:'Tileset Manager',width:960,body:body,buttons:[{text:'Close',primary:true}],onClose:()=>{ Palette.init(); }});
};

Misc.about = function(){ UIx.alert('RPG Studio 1.0\n\nA desktop editor and HTML5 runtime for making classic turn-based RPGs.\nAll graphics, sounds and data are generated by code — no third-party assets.\n\nUse it freely for non-commercial projects.','About'); };

Misc.help = function(){ UIx.dialog({title:'Quick Guide',width:620,body:E('div',{style:{lineHeight:'1.6',whiteSpace:'pre-wrap'},text:'1. Pick tiles in the palette (drag for multi-select) and draw on the map. Layer "Auto" puts each tile on its natural layer.\n2. Switch to Event mode (F6 or toolbar) to place NPCs, chests and doors: double-click a cell, or right-click for Quick Events.\n3. Database (F9) holds actors, classes, skills, items, equipment, enemies, troops, states and common events.\n4. Right-click a tile in Map mode → "Set Player Start Position here".\n5. Press F12 (or the ▶ button) to playtest. Tools → Deploy builds a folder you can zip and share.\n\nGame controls: Arrows/WASD move · Z/Enter OK · X/Esc cancel/menu · Shift dash · F11 fullscreen.'}),buttons:[{text:'Close',primary:true}]}); };
})();

/* ---------- editor bos: phase & skill ---------- */
(function(){
const R=window.RPG, F=UIx.F;
const TYPES=[['slam','Slam (area around boss)'],['charge','Charge (dash in a line)'],['fan','Fan shots (toward player)'],['ring','Ring of shots'],['meteor','Meteor (marked ground spots)'],['summon','Summon minions'],['blink','Blink (teleport near player)']];
window.Misc.bossEditor=function(m){
  const db=App.db; m.phases=m.phases||[]; const box=E('div',{style:{width:'860px',maxHeight:'560px',overflow:'auto'}});
  const sw=[{v:0,t:'(none)'}].concat(db.system.switches.map((n,i)=>({v:i+1,t:UIx.fmt3(i+1)+': '+(n||'')})));
  const render=()=>{ box.innerHTML='';
    box.append(E('div',{class:'row'},E('button',{class:'btn sm',text:'Preset: Dark Knight',onclick:()=>{ m.phases=JSON.parse(JSON.stringify(R.BOSS_PRESETS.knight)); render(); }}),E('button',{class:'btn sm',text:'Preset: Dragon',onclick:()=>{ m.phases=JSON.parse(JSON.stringify(R.BOSS_PRESETS.dragon)); render(); }}),E('button',{class:'btn sm',text:'＋ Add phase',onclick:()=>{ m.phases.push({hp:m.phases.length?Math.max(5,(m.phases[m.phases.length-1].hp||100)-30):100,name:'Phase '+(m.phases.length+1),cd:50,moves:[{type:'slam',name:'Slam',w:2,windup:30,radius:2,max:3,cd:80}]}); render(); }}),E('span',{class:'hint',text:'A phase starts when boss HP% drops to its value. Each phase has its own skills.'})));
    m.phases.forEach((ph,pi)=>{
      const fs=E('fieldset',null,E('legend',{text:'Phase '+(pi+1)}));
      fs.append(E('div',{class:'row wrap'},E('span',{text:'Starts at HP ≤'}),F.num(ph,'hp',{min:1,max:100,w:55}),E('span',{text:'%  Name'}),F.text(ph,'name',{w:130}),E('span',{text:'Speed +'}),F.num(ph,'speed',{min:-2,max:2,w:50}),E('span',{text:'Damage %'}),F.num(ph,'dmg',{min:10,max:500,w:60}),E('span',{text:'Pause'}),F.num(ph,'cd',{min:5,max:300,w:55}),E('button',{class:'btn sm danger',text:'Remove phase',onclick:()=>{ m.phases.splice(pi,1); render(); }})));
      ph.moves=ph.moves||[]; const sm=ph.summon||(ph.summon=null);
      fs.append(E('div',{class:'row wrap'},E('span',{text:'On entering: message'}),F.text(ph,'enter',{w:210}),E('span',{text:'heal %'}),F.num(ph,'heal',{min:0,max:100,w:55}),E('span',{text:'switch ON'}),F.sel(ph,'switch',sw,{w:140})));
      ph.moves.forEach((mv,mi)=>{
        const row=E('div',{class:'row wrap',style:{borderTop:'1px solid var(--line)',paddingTop:'4px'}},F.sel(mv,'type',TYPES.map(t=>({v:t[0],t:t[1]})),{w:210,change:()=>render()}),E('span',{text:'Name'}),F.text(mv,'name',{w:110}),E('span',{text:'Weight'}),F.num(mv,'w',{min:1,max:20,w:45}),E('span',{text:'Windup'}),F.num(mv,'windup',{min:8,max:200,w:55}),E('span',{text:'Cooldown'}),F.num(mv,'cd',{min:0,max:600,w:55}),E('span',{text:'Dist'}),F.num(mv,'min',{min:0,max:30,w:42}),E('span',{text:'–'}),F.num(mv,'max',{min:0,max:99,w:42}),E('span',{text:'Dmg %'}),F.num(mv,'dmg',{min:10,max:500,w:55}));
        const t=mv.type; if(t==='slam'||t==='meteor') row.append(E('span',{text:'Radius'}),F.num(mv,'radius',{min:.5,max:8,float:true,step:.1,w:55}));
        if(t==='fan'||t==='ring'||t==='meteor'||t==='summon') row.append(E('span',{text:'Count'}),F.num(mv,'count',{min:1,max:30,w:50}));
        if(t==='fan') row.append(E('span',{text:'Spread°'}),F.num(mv,'spread',{min:5,max:360,w:55}));
        if(t==='charge') row.append(E('span',{text:'Tiles'}),F.num(mv,'dist',{min:2,max:15,w:50}));
        if(t==='summon') row.append(F.ref(mv,'enemy',db.enemies,{none:false,w:150}));
        row.append(E('button',{class:'btn sm danger',text:'✕',onclick:()=>{ ph.moves.splice(mi,1); render(); }})); fs.append(row);
      });
      fs.append(E('button',{class:'btn sm',text:'＋ Add skill',onclick:()=>{ ph.moves.push({type:'slam',name:'Slam',w:2,windup:30,radius:2,max:3,cd:80}); render(); }}));
      box.append(fs);
    });
    if(!m.phases.length) box.append(E('div',{class:'hint',text:'No phases: the boss only uses normal melee attacks. Add a phase or choose a preset.'}));
  };
  render(); UIx.dialog({title:'Boss moves & phases',width:920,body:box,buttons:[{text:'Close',primary:true,fn:()=>{ App.touch(); }}]});
};
})();

/* ---------- Lighting per peta ---------- */
Misc.lightBox = function(map){ const R=window.RPG, F=UIx.F; map.light=Object.assign(R.Light.mapDefaults(),map.light||{}); const l=map.light; const box=E('div');
  const render=()=>{ box.innerHTML=''; const rows=[F.row('Lighting',F.sel(l,'mode',R.Light.MAP_MODES,{w:240,change:render}))];
    if(l.mode==='fixed') rows.push(F.row('Darkness color',E('span',null,F.color(l,'ambient'),E('span',{class:'hint',text:'  darker = more shadow (e.g. #1c2246)'}))));
    if(l.mode==='time') rows.push(F.row('',F.chk(l,'sun','Sun shadows from walls / trees / objects')));
    if(l.mode!=='off'){ rows.push(F.row('',F.chk(l,'shadows','Lights cast real-time shadows')),F.row('Player light',E('span',null,F.num(l,'playerLight',{min:0,max:600,w:70}),' radius px (0 = none)  ',F.color(l,'playerColor')))); }
    box.append(E('fieldset',null,E('legend',{text:'💡 Lighting / Day-Night'}),...rows,E('div',{class:'hint',text:'Add lamps/torches: Event Mode → event page → "Emit light". Time of day is set in Database → Day / Night or with the Lighting command.'}))); };
  render(); return box; };
