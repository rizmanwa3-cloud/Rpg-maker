/* Aplikasi editor: menu, toolbar, proyek, pohon peta, playtest */
(function(){
'use strict';
const R = window.RPG, MV = window.MapView;
const api = window.api || null;
const LS_KEY = 'rpgstudio.project';
const App = window.App = { db:null, dir:null, dirty:false, assets:{characters:[],pictures:[],battlers:[],audio:[]} };

App.touch = function(){ if(!App.dirty){ App.dirty=true; App.updateTitle(); } };
App.updateTitle = function(){ const t=(App.db&&App.db.system.title)||'Untitled'; document.title=(App.dirty?'* ':'')+t+' — RPG Studio'; const el=document.getElementById('st-info'); if(el) el.textContent=App.dir?App.dir:(api?'(unsaved project)':'(browser storage)'); };
App.curMap = ()=>MV.map;
App.refreshAssets = async function(){ const K=['characters','pictures','battlers','audio']; App.assets={}; for(const k of K){ let l=[]; if(api&&App.dir){ try{ l=(await api.listAssets(App.dir,k))||[]; }catch(e){} } const pre=k==='audio'?'audio/':'img/'+k+'/'; const A=(App.db&&App.db.assets)||{}; Object.keys(A).forEach(p=>{ if(p.startsWith(pre)){ const n=p.slice(pre.length); if(!l.includes(n)) l.push(n); } }); App.assets[k]=l; } };
App.refreshAll = function(){ App.refreshTree(); MV.draw(); App.updateToolbar(); App.updateTitle(); };

/* ------------- proyek ------------- */
App.setProject = function(db,dir){ App.db=db; R.$db=db; if(!db.assets) db.assets={}; App.dir=dir||null; R.assetBase=dir?('file://'+(dir.startsWith('/')?'':'/')+dir.replace(/\\/g,'/')+'/'):''; R.registerCustomTiles(db); try{ Palette.init(); }catch(e){} App.dirty=false; db.maps=db.maps||[]; if(!db.mapTree) db.mapTree=db.maps.map(m=>({id:m.id,parent:m.parent||0})); App.refreshAssets().then(()=>{}); const first=db.maps.find(m=>m.id===db.system.startMap)||db.maps[0]; App.openMap(first?first.id:null); App.refreshAll(); };
App.newProject = function(){ const go=()=>{ const db=R.newProject(); const m=R.newMap(1,'MAP001',20,15,R.TILE_BY_NAME['Grass'].id); db.maps=[m]; db.mapTree=[{id:1,parent:0}]; db.system.startMap=1; db.system.startX=10; db.system.startY=7; db.system.party=[1]; App.setProject(db,null); }; if(App.dirty) UIx.confirm('Discard unsaved changes?',go,'Discard'); else go(); };
App.loadDemo = function(){ const go=()=>App.setProject(R.buildDemo(),null); if(App.dirty) UIx.confirm('Discard unsaved changes?',go,'Discard'); else go(); };
App.open = async function(){ const go=async()=>{ if(api){ const r=await api.openProject(); if(!r) return; if(r.error){ UIx.alert(r.error); return; } App.setProject(r.data,r.dir); UIx.toast('Opened '+r.dir); } else { const s=localStorage.getItem(LS_KEY); if(!s){ UIx.alert('No project stored in this browser yet.'); return; } App.setProject(JSON.parse(s),null); } }; if(App.dirty) UIx.confirm('Discard unsaved changes?',go,'Discard'); else go(); };
App.save = async function(forceAs){ if(api){ let dir=App.dir; if(!dir||forceAs){ dir=await api.pickDir('Choose a project folder'); if(!dir) return false; } const r=await api.saveProject(dir,App.db); if(r&&r.error){ UIx.alert('Save failed: '+r.error); return false; } App.dir=dir; await App.refreshAssets(); } else { try{ localStorage.setItem(LS_KEY,JSON.stringify(App.db)); }catch(e){ UIx.alert('Save failed: '+e.message); return false; } } App.dirty=false; App.updateTitle(); UIx.toast('Project saved'); return true; };

/* ------------- peta ------------- */
App.openMap = function(id){ const m=App.db.maps.find(x=>x.id===id)||null; MV.load(m); const st=document.getElementById('st-map'); if(st) st.textContent=m?UIx.fmt3(m.id)+': '+m.name+'  ('+m.w+'×'+m.h+')':'(no map)'; App.refreshTree(); };
App.newMap = function(parent){ const o={name:'MAP'+String(Math.max(0,...App.db.maps.map(m=>m.id))+1).padStart(3,'0'),w:20,h:15}; const F=UIx.F; const f=E('div'); f.append(F.row('Name',F.text(o,'name',{w:220})),F.row('Size',E('span',null,F.num(o,'w',{min:1,max:256,w:70}),' × ',F.num(o,'h',{min:1,max:256,w:70})))); UIx.dialog({title:'New Map',width:380,body:f,buttons:[{text:'Cancel'},{text:'Create',primary:true,fn:()=>{ const id=Math.max(0,...App.db.maps.map(m=>m.id))+1; const m=R.newMap(id,o.name,o.w,o.h,R.TILE_BY_NAME['Grass'].id); m.parent=parent||0; App.db.maps.push(m); App.db.mapTree.push({id:id,parent:parent||0}); App.touch(); App.openMap(id); }}]}); };
App.deleteMap = function(id){ if(App.db.maps.length<=1){ UIx.alert('A project needs at least one map.'); return; } const m=App.db.maps.find(x=>x.id===id); UIx.confirm('Delete map "'+m.name+'"? This cannot be undone.',()=>{ const ids=new Set([id]); let ch=true; while(ch){ ch=false; App.db.mapTree.forEach(n=>{ if(ids.has(n.parent)&&!ids.has(n.id)){ ids.add(n.id); ch=true; } }); } App.db.maps=App.db.maps.filter(x=>!ids.has(x.id)); App.db.mapTree=App.db.mapTree.filter(n=>!ids.has(n.id)); if(ids.has(App.db.system.startMap)) App.db.system.startMap=App.db.maps[0].id; App.touch(); App.openMap(App.db.maps[0].id); },'Delete'); };
App.copyMap = function(id){ const src=App.db.maps.find(x=>x.id===id); const c=JSON.parse(JSON.stringify(src)); c.id=Math.max(0,...App.db.maps.map(m=>m.id))+1; c.name=src.name+' (copy)'; App.db.maps.push(c); App.db.mapTree.push({id:c.id,parent:src.parent||0}); App.touch(); App.openMap(c.id); };
App.refreshTree = function(){ const box=document.getElementById('maptree'); if(!box||!App.db) return; box.innerHTML=''; const cur=MV.map&&MV.map.id; const rec=(parent,depth)=>{ App.db.mapTree.filter(n=>(n.parent||0)===parent).forEach(n=>{ const m=App.db.maps.find(x=>x.id===n.id); if(!m) return; const el=E('div',{class:'tnode'+(m.id===cur?' on':''),style:{paddingLeft:(10+depth*14)+'px'},onclick:()=>App.openMap(m.id),ondblclick:()=>Misc.mapProps(m,()=>{ App.openMap(m.id); MV.draw(); }),oncontextmenu:e=>{ e.preventDefault(); UIx.ctxMenu(e.clientX,e.clientY,[{text:'Map Properties…',fn:()=>Misc.mapProps(m,()=>{ App.openMap(m.id); })},{text:'New Map (child)…',fn:()=>App.newMap(m.id)},{text:'Duplicate',fn:()=>App.copyMap(m.id)},'-',{text:'Delete',fn:()=>App.deleteMap(m.id)}]); }},E('span',{class:'id',text:UIx.fmt3(m.id)}),E('span',{text:m.name})); box.append(el); rec(m.id,depth+1); }); }; rec(0,0); };

/* ------------- playtest / deploy ------------- */
App.play = async function(){ if(!MV.map){ return; } const db=JSON.parse(JSON.stringify(App.db)); if(api){ const r=await api.play(db,App.dir); if(r&&r.error) UIx.alert('Playtest failed: '+r.error); } else { try{ localStorage.setItem('rpgstudio.play',JSON.stringify(db)); }catch(e){ UIx.alert('Cannot start playtest: '+e.message); return; } window.open('../runtime/index.html?play=1','rpgplay','width=832,height=663'); } };
App.playHere = async function(){ if(!MV.map) return; const db=JSON.parse(JSON.stringify(App.db)); const c=MV.selCell||{x:0,y:0}; db.system.startMap=MV.map.id; db.system.startX=c.x; db.system.startY=c.y; if(api){ const r=await api.play(db,App.dir); if(r&&r.error) UIx.alert('Playtest failed: '+r.error); } else { localStorage.setItem('rpgstudio.play',JSON.stringify(db)); window.open('../runtime/index.html?play=2','rpgplay','width=832,height=663'); } };
App.deploy = async function(standalone){ if(!api){ UIx.alert('Deploy is available in the desktop app.'); return; } const r=await api.deploy(JSON.parse(JSON.stringify(App.db)),App.dir,standalone); if(!r) return; if(r.error) UIx.alert('Deploy failed: '+r.error); else UIx.alert('Game built at:\n'+r.out+(standalone?'':'\n\nOpen index.html in a browser, or zip the folder to share it.')); };

/* ------------- menu & toolbar ------------- */
const setMode=m=>{ MV.mode=m; MV.sel=null; MV.draw(); App.updateToolbar(); };
const setTool=t=>{ MV.tool=t; if(MV.mode!=='map') MV.mode='map'; MV.draw(); App.updateToolbar(); };
const setLayer=l=>{ MV.layer=l; App.updateToolbar(); };
const hasMap=()=>!!MV.map;
const MENUS = ()=>[
  ['File',[{text:'New Project',fn:App.newProject},{text:'Load Demo Game',fn:App.loadDemo},{text:'Open Project…',key:'Ctrl+O',fn:App.open},{text:'Save Project',key:'Ctrl+S',fn:()=>App.save(false)},{text:'Save Project As…',fn:()=>App.save(true)},'-',{text:'Deploy (HTML5 build)…',fn:()=>App.deploy(false)},{text:'Deploy (Desktop package)…',fn:()=>App.deploy(true)}]],
  ['Edit',[{text:'Undo',key:'Ctrl+Z',fn:MV.doUndo},{text:'Redo',key:'Ctrl+Y',fn:MV.doRedo},'-',{text:'Delete Event',key:'Del',fn:MV.deleteSel},{text:'Copy Event',key:'Ctrl+C',fn:MV.copySel},{text:'Paste Event',key:'Ctrl+V',fn:()=>MV.paste()}]],
  ['Mode',[{text:'Map Mode',key:'F5',fn:()=>setMode('map')},{text:'Event Mode',key:'F6',fn:()=>setMode('event')}]],
  ['Draw',[{text:'Pencil',fn:()=>setTool('pencil')},{text:'Rectangle',fn:()=>setTool('rect')},{text:'Ellipse',fn:()=>setTool('ellipse')},{text:'Flood Fill',fn:()=>setTool('fill')},{text:'Eraser',fn:()=>setTool('erase')}]],
  ['Scale',[{text:'Zoom In',fn:()=>MV.setZoom(MV.zoom*1.25)},{text:'Zoom Out',fn:()=>MV.setZoom(MV.zoom/1.25)},{text:'100%',fn:()=>MV.setZoom(1)},{text:'50%',fn:()=>MV.setZoom(.5)},{text:'25%',fn:()=>MV.setZoom(.25)},'-',{text:'Toggle Grid',fn:()=>{ MV.grid=!MV.grid; MV.draw(); }},{text:'Show Passability',fn:()=>{ MV.showPass=!MV.showPass; MV.draw(); }}]],
  ['Tools',[{text:'Database…',key:'F9',fn:()=>DbEdit.open()},{text:'Map Properties…',fn:()=>MV.map&&Misc.mapProps(MV.map,()=>App.openMap(MV.map.id))},{text:'Resource Manager…',key:'F10',fn:Misc.resources},{text:'Tileset Manager…',fn:Misc.tilesets},{text:'Character Generator…',fn:()=>CharPick.standalone()},{text:'New Map…',fn:()=>App.newMap(0)}]],
  ['Game',[{text:'Playtest',key:'F12',fn:App.play},{text:'Playtest from selected cell',key:'Ctrl+F12',fn:App.playHere}]],
  ['Help',[{text:'Quick Guide',fn:Misc.help},{text:'About',fn:Misc.about}]]
];
function buildMenus(){ const bar=document.getElementById('menubar'); bar.innerHTML=''; let openEl=null; const closeAll=()=>{ document.querySelectorAll('.dropdown').forEach(d=>d.remove()); document.querySelectorAll('.menu.open').forEach(m=>m.classList.remove('open')); openEl=null; };
  MENUS().forEach(([name,items])=>{ const m=E('div',{class:'menu',text:name}); const show=()=>{ closeAll(); m.classList.add('open'); const dd=E('div',{class:'dropdown'}); items.forEach(it=>{ if(it==='-'){ dd.append(E('div',{class:'dd-sep'})); return; } dd.append(E('div',{class:'dd-item',onclick:e=>{ e.stopPropagation(); closeAll(); it.fn&&it.fn(); }},E('span',{text:it.text}),E('span',{class:'k',text:it.key||''}))); }); m.append(dd); openEl=m; }; m.onclick=e=>{ if(m.classList.contains('open')) closeAll(); else show(); e.stopPropagation(); }; m.onmouseenter=()=>{ if(openEl&&openEl!==m) show(); }; bar.append(m); });
  document.addEventListener('click',closeAll); window.addEventListener('blur',closeAll); }
const TB=[]; function tb(id,icon,title,fn,grp){ TB.push({id:id,icon:icon,title:title,fn:fn,grp:grp}); }
function buildToolbar(){ const bar=document.getElementById('toolbar'); bar.innerHTML=''; const sep=()=>bar.append(E('div',{class:'tb-sep'}));
  const btn=(id,txt,title,fn)=>{ const b=E('button',{class:'tb',title:title,'data-id':id,text:txt,onclick:fn}); bar.append(b); return b; };
  btn('new','📄','New Project',App.newProject); btn('open','📂','Open Project (Ctrl+O)',App.open); btn('save','💾','Save Project (Ctrl+S)',()=>App.save(false)); sep();
  btn('undo','↶','Undo (Ctrl+Z)',MV.doUndo); btn('redo','↷','Redo (Ctrl+Y)',MV.doRedo); sep();
  btn('mode-map','🗺 Map','Map mode (F5)',()=>setMode('map')); btn('mode-event','⚑ Event','Event mode (F6)',()=>setMode('event')); sep();
  [['pencil','✎','Pencil'],['rect','▭','Rectangle'],['ellipse','◯','Ellipse'],['fill','🪣','Flood fill'],['erase','⌫','Eraser']].forEach(([k,i,n])=>btn('tool-'+k,i,n,()=>setTool(k))); sep();
  bar.append(E('span',{class:'tb-lbl',text:'Layer'})); [['auto','Auto'],[0,'1'],[1,'2'],[2,'3'],[3,'4']].forEach(([k,n])=>btn('layer-'+k,n,k==='auto'?'Automatic layer':'Layer '+n,()=>setLayer(k))); sep();
  btn('zin','＋','Zoom in',()=>MV.setZoom(MV.zoom*1.25)); btn('zout','－','Zoom out',()=>MV.setZoom(MV.zoom/1.25)); sep();
  btn('db','🗃','Database (F9)',()=>DbEdit.open()); btn('res','🖼','Resource Manager (F10)',Misc.resources); btn('tiles','🧱','Tileset Manager',Misc.tilesets); btn('chargen','🧑','Character Generator',CharPick.standalone); sep();
  btn('play','▶','Playtest (F12)',App.play); }
App.updateToolbar = function(){ document.querySelectorAll('#toolbar .tb').forEach(b=>{ const id=b.dataset.id; let on=false; if(id==='mode-map') on=MV.mode==='map'; else if(id==='mode-event') on=MV.mode==='event'; else if(id.startsWith('tool-')) on=MV.mode==='map'&&MV.tool===id.slice(5); else if(id.startsWith('layer-')){ const v=id.slice(6); on=String(MV.layer)===v; } b.classList.toggle('on',!!on); if(id==='undo') b.classList.toggle('dis',!MV.undo.length); if(id==='redo') b.classList.toggle('dis',!MV.redo.length); }); };

window.addEventListener('keydown',e=>{ if(document.getElementById('modal-root').children.length) return; const tg=e.target.tagName; const typing=tg==='INPUT'||tg==='TEXTAREA'||tg==='SELECT';
  if(e.ctrlKey&&e.key==='s'){ e.preventDefault(); App.save(false); } else if(e.ctrlKey&&e.key==='o'){ e.preventDefault(); App.open(); }
  else if(e.key==='F5'){ e.preventDefault(); setMode('map'); } else if(e.key==='F6'){ e.preventDefault(); setMode('event'); } else if(e.key==='F9'){ e.preventDefault(); DbEdit.open(); } else if(e.key==='F10'){ e.preventDefault(); Misc.resources(); }
  else if(e.key==='F12'&&e.ctrlKey){ e.preventDefault(); App.playHere(); } else if(e.key==='F12'){ e.preventDefault(); App.play(); } },true);

function boot(){ R.onImageLoad=()=>{ try{ MV.draw(); Palette.draw(); }catch(e){} }; buildMenus(); buildToolbar(); Palette.init(); MV.init(); document.getElementById('tree-add').onclick=()=>App.newMap(0);
  App.setProject(R.buildDemo(),null);
  if(api&&api.onBeforeClose) api.onBeforeClose(()=>{ if(!App.dirty){ api.confirmClose(); return; } UIx.confirm('You have unsaved changes. Close anyway?',()=>api.confirmClose(),'Close without saving'); });
  window.addEventListener('beforeunload',e=>{ if(!api&&App.dirty){ e.preventDefault(); e.returnValue=''; } });
  App.updateToolbar(); }
if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot); else boot();
})();
