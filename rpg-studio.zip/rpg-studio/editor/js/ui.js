/* Helper UI editor: elemen, dialog, menu konteks, field terikat data */
(function(){
'use strict';
const R = window.RPG;
const E = window.E = function(tag, attrs){ const el=document.createElement(tag); if(attrs){ for(const k of Object.keys(attrs)){ const v=attrs[k]; if(v==null||v===false) continue; if(k==='class') el.className=v; else if(k==='style'&&typeof v==='object') Object.assign(el.style,v); else if(k==='text') el.textContent=v; else if(k==='html') el.innerHTML=v; else if(k.startsWith('on')) el.addEventListener(k.slice(2),v); else if(k==='value') el.value=v; else el.setAttribute(k,v===true?'':v); } }
  for(let i=2;i<arguments.length;i++){ const c=arguments[i]; if(c==null||c===false) continue; if(Array.isArray(c)) c.forEach(x=>x&&el.append(x)); else el.append(c instanceof Node?c:document.createTextNode(String(c))); } return el; };
const UIx = window.UIx = {};
UIx.toast = (msg,ms)=>{ const t=document.getElementById('toast'); t.textContent=msg; t.classList.add('show'); clearTimeout(UIx._tt); UIx._tt=setTimeout(()=>t.classList.remove('show'),ms||1800); };
/* ---- dialog ---- */
UIx.dialog = function(o){ const root=document.getElementById('modal-root'); const ov=E('div',{class:'overlay'}); const body=E('div',{class:'dlg-b'}); if(o.body) body.append(o.body); const dlg=E('div',{class:'dlg',style:{width:(o.width||600)+'px',height:o.height?o.height+'px':null}});
  const close=(r)=>{ if(o.onClose&&o.onClose(r)===false) return; ov.remove(); document.removeEventListener('keydown',kd,true); };
  const hd=E('div',{class:'dlg-h'},E('span',{text:o.title||''}),E('span',{class:'dlg-x',text:'✕',onclick:()=>close('x')})); dlg.append(hd,body);
  const ft=E('div',{class:'dlg-f'}); (o.buttons||[{text:'OK',primary:true}]).forEach(b=>{ ft.append(E('button',{class:'btn'+(b.primary?' pri':'')+(b.danger?' danger':''),text:b.text,onclick:()=>{ if(b.fn&&b.fn(api)===false) return; close(b.text); }})); }); if(o.buttons!==false) dlg.append(ft);
  ov.append(dlg); root.append(ov); const api={el:dlg,body:body,close:close,overlay:ov}; const kd=e=>{ if(e.key==='Escape'&&ov===root.lastElementChild){ const t=e.target; if(t&&t.closest&&t.closest('.ctx')) return; e.stopPropagation(); close('esc'); } }; document.addEventListener('keydown',kd,true);
  ov.addEventListener('mousedown',e=>{ if(e.target===ov&&o.modalClose) close('bg'); }); setTimeout(()=>{ const f=body.querySelector('input[type=text],textarea'); if(f&&o.focus!==false) f.focus(); },30); return api; };
UIx.confirm = function(msg,fn,yes){ UIx.dialog({title:'Confirm',width:420,body:E('div',{text:msg,style:{padding:'8px 0',lineHeight:'1.5'}}),buttons:[{text:'Cancel'},{text:yes||'OK',primary:true,fn:()=>{ fn(); }}]}); };
UIx.prompt = function(title,val,fn,label){ const inp=E('input',{type:'text',value:val||'',style:{width:'100%'}}); const d=UIx.dialog({title:title,width:380,body:E('div',null,label?E('div',{class:'mut',text:label,style:{marginBottom:'6px'}}):null,inp),buttons:[{text:'Cancel'},{text:'OK',primary:true,fn:()=>{ fn(inp.value); }}]}); inp.addEventListener('keydown',e=>{ if(e.key==='Enter'){ fn(inp.value); d.close(); } }); setTimeout(()=>{ inp.focus(); inp.select(); },40); };
UIx.alert = (msg,title)=>UIx.dialog({title:title||'RPG Studio',width:420,body:E('div',{text:msg,style:{lineHeight:'1.5',whiteSpace:'pre-wrap'}})});
/* ---- context / dropdown menu ---- */
UIx.ctxMenu = function(x,y,items){ const root=document.getElementById('ctx-root'); root.innerHTML=''; const m=E('div',{class:'ctx'}); items.forEach(it=>{ if(it==='-'){ m.append(E('div',{class:'dd-sep'})); return; } m.append(E('div',{class:'dd-item'+(it.dis?' dis':''),onclick:()=>{ root.innerHTML=''; it.fn&&it.fn(); }},E('span',{text:it.text}),E('span',{class:'k',text:it.key||''}))); }); root.append(m); const r=m.getBoundingClientRect(); m.style.left=Math.min(x,innerWidth-r.width-4)+'px'; m.style.top=Math.min(y,innerHeight-r.height-4)+'px'; const off=e=>{ if(!m.contains(e.target)){ root.innerHTML=''; document.removeEventListener('mousedown',off,true); } }; setTimeout(()=>document.addEventListener('mousedown',off,true),0); };
/* ---- field builders (terikat ke obj[key]) ---- */
const touch = ()=>{ if(window.App) App.touch(); };
const F = UIx.F = {};
F.text=(o,k,opts)=>{ opts=opts||{}; const i=E('input',{type:'text',value:o[k]==null?'':o[k],style:opts.style||{width:(opts.w||180)+'px'},oninput:()=>{ o[k]=i.value; touch(); opts.change&&opts.change(i.value); }}); return i; };
F.num=(o,k,opts)=>{ opts=opts||{}; const i=E('input',{type:'number',value:o[k]==null?0:o[k],min:opts.min,max:opts.max,step:opts.step||1,style:{width:(opts.w||80)+'px'},oninput:()=>{ let v=opts.float?parseFloat(i.value):parseInt(i.value,10); if(isNaN(v)) v=opts.min||0; o[k]=v; touch(); opts.change&&opts.change(v); }}); return i; };
F.sel=(o,k,options,opts)=>{ opts=opts||{}; const s=E('select',{style:{width:opts.w?(opts.w+'px'):null}}); const norm=options.map((x,i)=>typeof x==='object'?x:{v:opts.idx?i:x,t:String(x)}); norm.forEach(x=>{ const op=E('option',{value:String(x.v),text:x.t}); s.append(op); }); const cur=o[k]; s.value=String(cur); if(s.selectedIndex<0&&norm.length) s.selectedIndex=0; s.onchange=()=>{ const raw=s.value; const m=norm.find(x=>String(x.v)===raw); o[k]=m?m.v:raw; touch(); opts.change&&opts.change(o[k]); }; return s; };
F.chk=(o,k,label,opts)=>{ const c=E('input',{type:'checkbox',onchange:()=>{ o[k]=c.checked; touch(); opts&&opts.change&&opts.change(c.checked); }}); c.checked=!!o[k]; return E('label',{style:{display:'inline-flex',gap:'5px',alignItems:'center',cursor:'pointer'}},c,label||''); };
F.color=(o,k)=>{ const c=E('input',{type:'color',value:o[k]||'#ffffff',oninput:()=>{ o[k]=c.value; touch(); }}); return c; };
F.area=(o,k,rows,opts)=>{ const t=E('textarea',{rows:rows||4,oninput:()=>{ o[k]=t.value; touch(); opts&&opts.change&&opts.change(t.value); }}); t.value=o[k]||''; return t; };
F.row=(label,...ctrls)=>E('div',{class:'row'},E('label',{text:label}),...ctrls);
F.list=(db,key)=>db[key].map((x,i)=>({v:i+1,t:String(i+1).padStart(3,'0')+': '+(x&&x.name||'')}));
F.ref=(o,k,list,opts)=>{ opts=opts||{}; const options=(opts.none!==false?[{v:0,t:opts.noneLabel||'(None)'}]:[]).concat(list.map((x,i)=>({v:i+1,t:String(i+1).padStart(3,'0')+': '+(x&&x.name||'')}))); return F.sel(o,k,options,opts); };
/* ---- picker ikon ---- */
UIx.iconCanvas=(idx,size)=>{ const c=E('canvas',{width:size||32,height:size||32,class:'thumb',style:{width:(size||32)+'px',height:(size||32)+'px'}}); const g=c.getContext('2d'); g.clearRect(0,0,c.width,c.height); if(idx) R.drawIcon(g,idx,0,0,size||32); return c; };
UIx.pickIcon=(cur,fn)=>{ const body=E('div'); const grid=E('div',{class:'icongrid'}); const mine=E('div',{class:'icongrid'}); let sel=cur; let d;
  const clear=()=>{ body.querySelectorAll('.on').forEach(x=>x.classList.remove('on')); };
  const pick=(v,el,dbl)=>{ sel=v; clear(); el.classList.add('on'); if(dbl){ fn(sel); d.close(); } };
  const none=E('canvas',{width:32,height:32,title:'None',onclick:()=>pick(0,none)}); none.getContext('2d').fillStyle='#667'; none.getContext('2d').fillText('∅',12,20); grid.append(none);
  R.ICONS.forEach((ic,i)=>{ const c=E('canvas',{width:32,height:32,title:ic.name,onclick:()=>pick(i+1,c),ondblclick:()=>pick(i+1,c,true)}); R.drawIcon(c.getContext('2d'),i+1,0,0,32); if(i+1===cur) c.classList.add('on'); grid.append(c); });
  const renderMine=()=>{ mine.innerHTML=''; const list=(window.App&&App.assets&&App.assets.icons)||[]; if(!list.length){ mine.append(E('div',{class:'hint',text:'No imported icons yet. Use "Import icon…" below (PNG, square, any size).'})); return; }
    list.forEach(n=>{ const key=App.assetPrefix('icons')+n; const im=E('img',{src:R.assetUrl?R.assetUrl(key):key,title:n,style:{width:'32px',height:'32px',objectFit:'contain',imageRendering:'pixelated',background:'#0003',borderRadius:'4px',padding:'2px',cursor:'pointer',border:'2px solid transparent'},onclick:()=>pick(key,im),ondblclick:()=>pick(key,im,true)}); if(cur===key){ im.classList.add('on'); } mine.append(im); }); };
  renderMine();
  const imp=E('button',{class:'btn sm',text:'⇪ Import icon…',onclick:()=>Misc.importAssets('icons',last=>{ if(last){ sel=last; } setTimeout(()=>{ renderMine(); const k=mine.querySelector('img[title="'+String(last||'').split('/').pop()+'"]'); if(k){ clear(); k.classList.add('on'); } },300); })});
  body.append(E('div',{class:'hint',style:{margin:'0 0 4px'},text:'Built-in'}),grid,E('div',{class:'hint',style:{margin:'10px 0 4px'},text:'Your icons (imported)'}),mine,E('div',{style:{marginTop:'8px'}},imp));
  d=UIx.dialog({title:'Select Icon',width:560,body:body,buttons:[{text:'Cancel'},{text:'OK',primary:true,fn:()=>fn(sel)}]}); };
F.icon=(o,k)=>{ const holder=E('span',{style:{display:'inline-flex',gap:'6px',alignItems:'center'}}); const render=()=>{ holder.innerHTML=''; const c=UIx.iconCanvas(o[k],32); c.onclick=()=>UIx.pickIcon(o[k],v=>{ o[k]=v; touch(); render(); }); holder.append(c,E('span',{class:'mut',text:o[k]&&R.ICONS[o[k]-1]?R.ICONS[o[k]-1].name:'(none)'})); }; render(); return holder; };
/* ---- picker daftar (bgm, se, anim) ---- */
F.bgm=(o,k)=>{ const s=F.sel(o,k,R.BGM_LIST.slice().concat(editorAudio('bgm')),{}); const pb=E('button',{class:'btn sm',text:'▶',onclick:()=>{ R.Audio.init(); if(R.Audio.bgmName===o[k]) R.Audio.stopBgm(); else R.Audio.playBgm(o[k]); }}); return E('span',{style:{display:'inline-flex',gap:'4px'}},s,pb); };
F.se=(o,k)=>{ const s=F.sel(o,k,R.SE_LIST.slice().concat(editorAudio('se'))); const pb=E('button',{class:'btn sm',text:'▶',onclick:()=>{ R.Audio.init(); R.Audio.se(o[k]); }}); return E('span',{style:{display:'inline-flex',gap:'4px'}},s,pb); };
F.anim=(o,k)=>F.sel(o,k,R.ANIMS.slice());
function editorAudio(){ return (window.App&&App.assets&&App.assets.audio||[]).map(n=>'audio/'+n); }
/* ---- character picker ---- */
UIx.charThumb=(img,size)=>{ size=size||48; const c=E('canvas',{width:size,height:size,class:'thumb',style:{width:size+'px',height:size+'px'}}); const g=c.getContext('2d'); g.imageSmoothingEnabled=false; if(img&&img.kind==='tile'){ const t=R.tileCanvas(img.tile,0); if(t) g.drawImage(t,0,0,size,size); } else { const sh=R.charSheet(img); if(sh){ if(sh.width>144){ const cw=sh.width/3,ch=sh.height/4; g.drawImage(sh,cw,0,cw,ch,0,0,size,size); } else g.drawImage(sh,48,0,48,48,0,0,size,size); } } return c; };
F.char=(o,k,opts)=>{ const holder=E('span',{style:{display:'inline-flex',gap:'6px',alignItems:'center'}}); const render=()=>{ holder.innerHTML=''; const c=UIx.charThumb(o[k],48); c.onclick=()=>CharPick.open(o[k],v=>{ o[k]=v; touch(); render(); opts&&opts.change&&opts.change(v); },opts); holder.append(c); }; render(); return holder; };
window.CharPick = window.CharPick||{};
UIx.fmt3=n=>String(n).padStart(3,'0');
})();
