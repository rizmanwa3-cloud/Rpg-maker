/* Palet tile (tab A-E) dengan pemilihan multi-tile */
(function(){
'use strict';
const R = window.RPG;
const P = window.Palette = { tab:'A', cell:44, cols:6, sel:{w:1,h:1,cells:[1]}, drag:null, hover:-1 };
P.tiles = ()=>[{id:0}].concat(R.TILES.filter(t=>t.tab===P.tab&&!t.removed));
P.init = function(){
  const tabs=document.getElementById('pal-tabs'); tabs.innerHTML='';
  R.TILE_TABS.forEach(([k,n])=>{ tabs.append(E('div',{class:'ptab'+(k===P.tab?' on':''),text:k,title:n,onclick:()=>{ P.tab=k; P.init(); const f=P.tiles()[1]; P.sel={w:1,h:1,cells:[f?f.id:0]}; P.draw(); }})); });
  const cv=document.getElementById('palette'); P.cv=cv;
  const n=P.tiles().length, rows=Math.ceil(n/P.cols); cv.width=P.cols*P.cell; cv.height=rows*P.cell; cv.style.width=cv.width+'px'; cv.style.height=cv.height+'px';
  const idxAt=e=>{ const r=cv.getBoundingClientRect(); const x=Math.floor((e.clientX-r.left)/P.cell), y=Math.floor((e.clientY-r.top)/P.cell); return {x:x,y:y}; };
  cv.onmousedown=e=>{ const p=idxAt(e); P.drag={x0:p.x,y0:p.y,x1:p.x,y1:p.y}; P.applyDrag(); P.draw(); };
  cv.onmousemove=e=>{ const p=idxAt(e); const i=p.y*P.cols+p.x; const t=P.tiles()[i]; const info=document.getElementById('pal-info'); if(t&&t.id){ const d=R.TILES[t.id-1]; info.textContent='#'+t.id+' '+d.name+'  | layer '+(d.layer+1)+(d.pass?' | passable':' | blocked')+(d.star?' | ★':''); } else info.textContent=t?'(Eraser / empty)':''; if(P.drag&&e.buttons){ P.drag.x1=Math.max(0,Math.min(P.cols-1,p.x)); P.drag.y1=Math.max(0,p.y); P.applyDrag(); P.draw(); } };
  window.addEventListener('mouseup',()=>{ P.drag=null; });
  P.draw();
};
P.applyDrag=function(){ const d=P.drag; if(!d) return; const x0=Math.min(d.x0,d.x1),x1=Math.max(d.x0,d.x1),y0=Math.min(d.y0,d.y1),y1=Math.max(d.y0,d.y1); const list=P.tiles(); const cells=[]; for(let y=y0;y<=y1;y++) for(let x=x0;x<=x1;x++){ const t=list[y*P.cols+x]; cells.push(t?t.id:0); } P.sel={w:x1-x0+1,h:y1-y0+1,cells:cells,tab:P.tab,x0:x0,y0:y0}; };
P.draw=function(){ const cv=P.cv, g=cv.getContext('2d'); g.fillStyle='#10131c'; g.fillRect(0,0,cv.width,cv.height); const list=P.tiles(); const c=P.cell;
  list.forEach((t,i)=>{ const x=(i%P.cols)*c, y=Math.floor(i/P.cols)*c; if(!t.id){ g.fillStyle='#1b1f2c'; g.fillRect(x,y,c,c); g.strokeStyle='#ff6b6b'; g.lineWidth=2; g.beginPath(); g.moveTo(x+10,y+10); g.lineTo(x+c-10,y+c-10); g.moveTo(x+c-10,y+10); g.lineTo(x+10,y+c-10); g.stroke(); return; } g.fillStyle='#2a2f44'; g.fillRect(x,y,c,c); g.fillStyle='#232838'; g.fillRect(x,y,c/2,c/2); g.fillRect(x+c/2,y+c/2,c/2,c/2); const cvT=R.tileCanvas(t.id,0); g.drawImage(cvT,x,y,c,c); const d=R.TILES[t.id-1]; if(!d.pass){ g.fillStyle='rgba(255,60,60,.9)'; g.fillRect(x+2,y+2,6,6); } });
  g.strokeStyle='rgba(255,255,255,.07)'; g.lineWidth=1; for(let x=0;x<=P.cols;x++){ g.beginPath(); g.moveTo(x*c+.5,0); g.lineTo(x*c+.5,cv.height); g.stroke(); } for(let y=0;y<=Math.ceil(list.length/P.cols);y++){ g.beginPath(); g.moveTo(0,y*c+.5); g.lineTo(cv.width,y*c+.5); g.stroke(); }
  const s=P.sel; if(s.tab===P.tab||s.tab===undefined){ g.strokeStyle='#4f8cff'; g.lineWidth=3; if(s.x0!==undefined) g.strokeRect(s.x0*c+1.5,s.y0*c+1.5,s.w*c-3,s.h*c-3); else { const i=list.findIndex(t=>t.id===s.cells[0]); if(i>=0) g.strokeRect((i%P.cols)*c+1.5,Math.floor(i/P.cols)*c+1.5,c-3,c-3); } } };
P.selectTile=function(id){ if(!id) return; const d=R.TILES[id-1]; if(!d) return; P.tab=d.tab; P.init(); const list=P.tiles(); const i=list.findIndex(t=>t.id===id); P.sel={w:1,h:1,cells:[id],tab:P.tab,x0:i%P.cols,y0:Math.floor(i/P.cols)}; P.draw(); };
/* picker tile modal (dipakai event untuk grafik tile) */
P.pick=function(cur,fn){ let tab=cur&&R.TILES[cur-1]?R.TILES[cur-1].tab:'A'; let sel=cur||0; const wrap=E('div'); const tabs=E('div',{class:'tabs'}); const cv=E('canvas'); const scroll=E('div',{style:{height:'420px',overflow:'auto',background:'#10131c'}},cv); const info=E('div',{class:'hint',style:{marginTop:'6px'}});
  const draw=()=>{ const list=R.TILES.filter(t=>t.tab===tab&&!t.removed); const cols=10,c=48,rows=Math.ceil(list.length/cols); cv.width=cols*c; cv.height=rows*c; const g=cv.getContext('2d'); g.fillStyle='#10131c'; g.fillRect(0,0,cv.width,cv.height); list.forEach((t,i)=>{ const x=(i%cols)*c,y=Math.floor(i/cols)*c; g.fillStyle='#232838'; g.fillRect(x,y,c/2,c/2); g.fillRect(x+c/2,y+c/2,c/2,c/2); g.drawImage(R.tileCanvas(t.id,0),x,y); if(t.id===sel){ g.strokeStyle='#4f8cff'; g.lineWidth=3; g.strokeRect(x+1.5,y+1.5,c-3,c-3); } }); cv.onmousedown=e=>{ const r=cv.getBoundingClientRect(); const i=Math.floor((e.clientY-r.top)/c)*cols+Math.floor((e.clientX-r.left)/c); const t=list[i]; if(t){ sel=t.id; info.textContent='#'+t.id+' '+t.name; draw(); } }; cv.ondblclick=()=>{ if(sel){ fn(sel); d.close(); } }; };
  const drawTabs=()=>{ tabs.innerHTML=''; R.TILE_TABS.forEach(([k,n])=>tabs.append(E('div',{class:'tab'+(k===tab?' on':''),text:k+' '+n,onclick:()=>{ tab=k; drawTabs(); draw(); }}))); }; drawTabs(); draw(); wrap.append(tabs,scroll,info);
  const d=UIx.dialog({title:'Select Tile',width:540,body:wrap,buttons:[{text:'Cancel'},{text:'OK',primary:true,fn:()=>{ if(sel) fn(sel); }}]}); };
})();
