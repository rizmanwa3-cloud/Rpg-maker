/* Platform: penyimpanan proyek di perangkat (Android APK / browser), ekspor game HTML5 / ZIP, playtest di dalam editor */
(function(){
'use strict';
const P = window.Plat = {};
let JF = null;                                   // _JSFiles_ tersedia di APK (AppBuilder WebView) bila includeApi files = true
const detect = ()=>{ JF = window._JSFiles_ || null; P.android = !!JF; };
detect(); window.addEventListener('load',detect);
P.ifaces = ()=>Object.keys(window).filter(k=>/^_[A-Za-z]+_$/.test(k));
P.isWebView = ()=>/; wv\)|Version\/[\d.]+ Chrome.*Mobile.*wv/.test(navigator.userAgent) || P.ifaces().length>0;
P.safe = n => String(n||'project').replace(/[^\w\- ]+/g,'').trim().replace(/\s+/g,'_').slice(0,60) || 'project';
const jf = (m, ...a) => { try{ return JF[m](...a); }catch(e){ console.error('_JSFiles_.'+m, e); return null; } };

/* ---------- folder di perangkat ---------- */
P.dirs = function(){ if(P._d) return P._d; if(!P.android) return null;
  const internal = jf('getFilesDir'); let ext=null; try{ ext = jf('getExternalFilesDir'); }catch(e){}
  const base = (ext||internal)+'/RPGStudio'; P._d = { base:base, projects:base+'/projects', exports:base+'/exports', external:!!ext };
  jf('mkdirs',P._d.projects); jf('mkdirs',P._d.exports); return P._d; };

/* ---------- penyimpanan proyek ---------- */
const lsIndex = ()=>{ try{ return JSON.parse(localStorage.getItem('rpgstudio.index')||'{}'); }catch(e){ return {}; } };
P.projList = function(){ const out=[]; if(P.android){ const d=P.dirs(); let names=[]; try{ names=JSON.parse(jf('list',d.projects)||'[]'); }catch(e){} names.filter(n=>/\.json$/.test(n)).forEach(n=>out.push({name:n.replace(/\.json$/,''),mtime:+jf('lastModified',d.projects+'/'+n)||0,size:+jf('length',d.projects+'/'+n)||0,src:'device'})); }
  const idx=lsIndex(); Object.keys(idx).forEach(n=>{ if(!out.find(o=>o.name===n)) out.push({name:n,mtime:idx[n].mtime||0,size:idx[n].size||0,src:'browser'}); }); out.sort((a,b)=>b.mtime-a.mtime); return out; };
P.projSave = function(name,json){ name=P.safe(name); const where=[];
  if(P.android){ const d=P.dirs(); if(jf('write',d.projects+'/'+name+'.json',json)===true) where.push('device'); }
  try{ localStorage.setItem('rpgstudio.proj.'+name,json); const idx=lsIndex(); idx[name]={mtime:Date.now(),size:json.length}; localStorage.setItem('rpgstudio.index',JSON.stringify(idx)); where.push('browser'); }catch(e){ /* kuota penuh: tidak apa jika file di perangkat berhasil */ }
  try{ localStorage.setItem('rpgstudio.last',name); }catch(e){}
  return { ok:where.length>0, where:where, name:name }; };
P.projLoad = function(name){ name=P.safe(name); if(P.android){ const d=P.dirs(); const p=d.projects+'/'+name+'.json'; if(jf('exists',p)===true){ const s=jf('read',p); if(s){ try{ return JSON.parse(s); }catch(e){ console.error(e); } } } }
  try{ const s=localStorage.getItem('rpgstudio.proj.'+name); if(s) return JSON.parse(s); }catch(e){} return null; };
P.projDelete = function(name){ name=P.safe(name); if(P.android){ const d=P.dirs(); jf('delete',d.projects+'/'+name+'.json'); } try{ localStorage.removeItem('rpgstudio.proj.'+name); const idx=lsIndex(); delete idx[name]; localStorage.setItem('rpgstudio.index',JSON.stringify(idx)); }catch(e){} };
P.restoreLast = function(){ const l=P.projList(); if(!l.length) return null; let last=null; try{ last=localStorage.getItem('rpgstudio.last'); }catch(e){} const pick=(last&&l.find(x=>x.name===last))||l[0]; const db=P.projLoad(pick.name); return db?{name:pick.name,db:db}:null; };

/* ---------- simpan / bagikan file ---------- */
const b64 = u8=>{ let s=''; const ch=0x8000; for(let i=0;i<u8.length;i+=ch) s+=String.fromCharCode.apply(null,u8.subarray(i,i+ch)); return btoa(s); };
P.saveFile = function(name,mime,data){ // data: string atau Uint8Array
  detect();
  if(!P.android && P.isWebView()){ // WebView tanpa _JSFiles_: unduhan blob ditolak, pakai jendela salin
    if(typeof data==='string'){ P.copyDialog(name,data); return { path:name, manual:true }; }
    UIx.alert('File ZIP tidak bisa disimpan di APK ini karena API "files" belum aktif.\n\nSolusi: di AppBuilder aktifkan WebView | includeApi | files = true lalu build ulang APK. Sementara itu pakai "Export Game (HTML5 file)" atau "Export Project File" (keduanya lewat Salin).'); return { path:name, manual:true }; }
  if(P.android){ const d=P.dirs(); const path=d.exports+'/'+name; const ok = typeof data==='string' ? jf('write',path,data)===true : jf('writeBase64',path,b64(data))===true;
    if(!ok){ UIx.alert('Gagal menulis file:\n'+path); return null; }
    let shared=false; try{ JF.share(path,mime); shared=true; }catch(e){ console.error(e); }
    return { path:path, shared:shared }; }
  const blob=new Blob([data],{type:mime}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=name; document.body.append(a); a.click(); setTimeout(()=>{ URL.revokeObjectURL(a.href); a.remove(); },5000); return { path:name, shared:false, download:true }; };
P.reportSaved = function(r,what){ if(!r||r.manual) return; if(r.download) UIx.toast(what+' diunduh: '+r.path,3000);
  else UIx.alert(what+' tersimpan di perangkat:\n'+r.path+'\n\n'+(r.shared?'Jendela "Bagikan" terbuka: pilih Files / Drive / WhatsApp / dll. untuk menyimpannya di tempat yang kamu mau.':'Buka file itu lewat aplikasi pengelola file.')); };

/* ---------- cadangan: jendela salin teks (WebView tanpa API file) ---------- */
P.copyDialog = function(name,text){ const ov=document.createElement('div'); ov.style.cssText='position:fixed;inset:0;z-index:99998;background:rgba(0,0,0,.85);display:flex;flex-direction:column;padding:10px;gap:8px;font:14px sans-serif;color:#fff';
  const info=document.createElement('div'); info.innerHTML='<b>'+name+'</b> ('+(text.length/1048576).toFixed(2)+' MB)<br>Tekan <b>Salin semua</b>, lalu tempel ke aplikasi catatan / pengelola file dan simpan dengan nama <b>'+name+'</b>.';
  const ta=document.createElement('textarea'); ta.readOnly=true; ta.value=text; ta.style.cssText='flex:1;width:100%;background:#0d1320;color:#9fb0cc;border:1px solid #4f8cff;border-radius:6px;font:11px monospace;box-sizing:border-box';
  const row=document.createElement('div'); row.style.cssText='display:flex;gap:8px';
  const mk=(t,fn)=>{ const b=document.createElement('button'); b.textContent=t; b.style.cssText='flex:1;padding:12px;background:#1b2438;color:#fff;border:1px solid #4f8cff;border-radius:6px;font:15px sans-serif'; b.onclick=fn; row.append(b); return b; };
  const cp=mk('Salin semua',()=>{ let ok=false; try{ ta.focus(); ta.select(); ta.setSelectionRange(0,text.length); ok=document.execCommand('copy'); }catch(e){} if(!ok){ try{ navigator.clipboard.writeText(text); ok=true; }catch(e){} } cp.textContent=ok?'✓ Tersalin':'Gagal — tahan lama lalu pilih Salin'; });
  mk('Tutup',()=>ov.remove()); ov.append(info,ta,row); document.body.append(ov); };

/* ---------- build game HTML5 satu file ---------- */
const esc = s=>s.replace(/<\/script/gi,'<\\/script');
P.buildHtml = function(db,opts){ const B=window.RPG_BUNDLE; if(!B) throw new Error('runtime_bundle.js tidak ditemukan. Jalankan: node tools/make-bundle.js');
  const title=String((db.system&&db.system.title)||'RPG Game').replace(/[<>&"]/g,'');
  const json=JSON.stringify(db).replace(/</g,'\\u003c').replace(/\u2028/g,'\\u2028').replace(/\u2029/g,'\\u2029');
  let h='<!doctype html>\n<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no"><meta name="mobile-web-app-capable" content="yes"><title>'+title+'</title><style>'+B.style+'</style></head><body>\n<canvas id="screen" width="816" height="624"></canvas>\n';
  for(const s of B.scripts) h+='<script>/* '+s.name+' */\n'+esc(s.src)+'\n</script>\n';
  h+='<script>window.PROJECT='+json+';</script>\n<script>/* boot.js */\n'+esc(B.boot)+'\n</script>\n<script>RPG.boot('+JSON.stringify(opts||{})+');</script>\n</body></html>\n';
  return h; };

/* ---------- ZIP (tanpa kompresi) ---------- */
let CRC=null; const crc32 = u8=>{ if(!CRC){ CRC=new Uint32Array(256); for(let n=0;n<256;n++){ let c=n; for(let k=0;k<8;k++) c=c&1?0xEDB88320^(c>>>1):c>>>1; CRC[n]=c>>>0; } } let c=0xFFFFFFFF; for(let i=0;i<u8.length;i++) c=CRC[(c^u8[i])&255]^(c>>>8); return (c^0xFFFFFFFF)>>>0; };
P.zip = function(files){ const enc=new TextEncoder(); const parts=[], cen=[]; let off=0; const d=new Date(); const dt=((d.getHours()<<11)|(d.getMinutes()<<5)|(d.getSeconds()>>1))&0xFFFF, dd=(((d.getFullYear()-1980)<<9)|((d.getMonth()+1)<<5)|d.getDate())&0xFFFF;
  for(const f of files){ const name=enc.encode(f.name), data=typeof f.data==='string'?enc.encode(f.data):f.data, crc=crc32(data);
    const lh=new DataView(new ArrayBuffer(30)); lh.setUint32(0,0x04034b50,true); lh.setUint16(4,20,true); lh.setUint16(6,0x0800,true); lh.setUint16(8,0,true); lh.setUint16(10,dt,true); lh.setUint16(12,dd,true); lh.setUint32(14,crc,true); lh.setUint32(18,data.length,true); lh.setUint32(22,data.length,true); lh.setUint16(26,name.length,true); lh.setUint16(28,0,true);
    parts.push(new Uint8Array(lh.buffer),name,data);
    const ch=new DataView(new ArrayBuffer(46)); ch.setUint32(0,0x02014b50,true); ch.setUint16(4,20,true); ch.setUint16(6,20,true); ch.setUint16(8,0x0800,true); ch.setUint16(10,0,true); ch.setUint16(12,dt,true); ch.setUint16(14,dd,true); ch.setUint32(16,crc,true); ch.setUint32(20,data.length,true); ch.setUint32(24,data.length,true); ch.setUint16(28,name.length,true); ch.setUint32(42,off,true);
    cen.push(new Uint8Array(ch.buffer),name); off+=30+name.length+data.length; }
  let csz=0; cen.forEach(c=>csz+=c.length); const end=new DataView(new ArrayBuffer(22)); end.setUint32(0,0x06054b50,true); end.setUint16(8,files.length,true); end.setUint16(10,files.length,true); end.setUint32(12,csz,true); end.setUint32(16,off,true);
  const all=parts.concat(cen,[new Uint8Array(end.buffer)]); let total=0; all.forEach(a=>total+=a.length); const out=new Uint8Array(total); let p=0; all.forEach(a=>{ out.set(a,p); p+=a.length; }); return out; };

/* ---------- playtest di dalam editor (overlay iframe) ---------- */
P.playOverlay = function(html){ const ov=document.createElement('div'); ov.style.cssText='position:fixed;left:0;top:0;right:0;bottom:0;z-index:99999;background:#000';
  const fr=document.createElement('iframe'); fr.style.cssText='border:0;width:100%;height:100%;display:block;background:#000'; fr.setAttribute('allow','autoplay; fullscreen'); fr.srcdoc=html;
  const x=document.createElement('button'); x.textContent='✕ Close playtest'; x.style.cssText='position:absolute;top:6px;right:6px;z-index:2;opacity:.6;background:#1b2438;color:#fff;border:1px solid #4f8cff;border-radius:6px;padding:6px 10px;font:13px sans-serif;cursor:pointer';
  x.onclick=()=>{ try{ fr.srcdoc=''; }catch(e){} ov.remove(); document.removeEventListener('keydown',kd,true); };
  const kd=e=>{ if(e.key==='F12'||(e.ctrlKey&&e.key==='q')){ x.onclick(); } };
  document.addEventListener('keydown',kd,true); ov.append(fr,x); document.body.append(ov); fr.addEventListener('load',()=>{ try{ fr.contentWindow.focus(); }catch(e){} }); };
})();
