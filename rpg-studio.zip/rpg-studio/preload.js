const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('api', {
  pickDir: (t) => ipcRenderer.invoke('dlg:pick-dir', t),
  openProject: (dir) => ipcRenderer.invoke('project:open', dir),
  saveProject: (dir, data) => ipcRenderer.invoke('project:save', dir, data),
  importAssets: (dir, kind) => ipcRenderer.invoke('asset:import', dir, kind),
  listAssets: (dir, kind) => ipcRenderer.invoke('asset:list', dir, kind),
  deleteAsset: (dir, kind, name) => ipcRenderer.invoke('asset:delete', dir, kind, name),
  play: (db, dir) => ipcRenderer.invoke('game:play', db, dir),
  deploy: (db, dir, standalone) => ipcRenderer.invoke('game:deploy', db, dir, standalone),
  confirmClose: () => ipcRenderer.invoke('app:confirm-close'),
  onBeforeClose: (fn) => ipcRenderer.on('app:before-close', fn),
  version: () => ipcRenderer.invoke('app:version'),
  isElectron: true
});
